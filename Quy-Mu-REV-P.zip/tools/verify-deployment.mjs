import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {dependency} from './deps.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const stage=process.argv[2],commit=process.argv[3];
assert.ok(stage&&commit,'Provide staging folder and deployed commit');
const base='https://dam-truong.github.io/quy-mu-rev-p/';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name.startsWith('.'))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else files.push(p);}}
walk(stage);
const checked=[],queue=[...files];
await Promise.all(Array.from({length:6},async()=>{while(queue.length){const p=queue.shift(),name=path.relative(stage,p).replaceAll('\\','/'),r=await fetch(base+name+'?rev='+commit);assert.equal(r.status,200,name);const b=Buffer.from(await r.arrayBuffer()),expected=hash(fs.readFileSync(p));assert.equal(hash(b),expected,'Deployed bytes differ: '+name);checked.push({file:name,bytes:b.length,sha256:expected});}}));
const {chromium}=await dependency('playwright'),browser=await chromium.launch({channel:'msedge',headless:true});
const page=await browser.newPage({viewport:{width:1800,height:1200},acceptDownloads:true}),errors=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto(base+'?rev='+commit,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.MAZE_API);
assert.equal(await page.locator('#run option').count(),24);
assert.match(await page.locator('#result').innerText(),/ĐẠT 24\/24/);
const phases=[];
for(let s=0;s<4;s++){
 await page.locator(`[data-stage="${s}"]`).click();
 const v=await page.evaluate(()=>({active:document.querySelector('[data-stage].on').dataset.stage,closures:window.MAZE_API.groups.dynamic.children.map(m=>m.name)}));
 assert.equal(v.active,String(s));assert.equal(v.closures.includes('C06'),s<3);phases.push(v);
}
await page.locator('[data-stage="0"]').click();await page.locator('#sweep').click();
await page.waitForFunction(()=>window.MAZE_API.groups.dynamic.children.some(m=>m.userData.sweepFraction>0));
assert.ok(await page.evaluate(()=>[...window.MAZE_API.emergencyMeshes,...window.MAZE_API.onewayMeshes].every(m=>!m.visible)));
await page.waitForFunction(()=>document.querySelector('[data-stage="1"]').classList.contains('on'),{},{timeout:10000});
await page.locator('#eye').click();assert.ok(Math.abs(await page.evaluate(()=>window.MAZE_API.camera.position.y)-1.6)<1e-9);
await page.screenshot({path:root+'previews/deployed-eye.png'});
await page.locator('#orbit').click();await page.locator('#cut').click();
await page.screenshot({path:root+'previews/deployed-viewer.png'});
for(const [selector,extension] of [['#capture','.png'],['#export','.glb']]){
 const pending=page.waitForEvent('download');await page.locator(selector).click();const d=await pending;assert.ok(d.suggestedFilename().endsWith(extension));assert.equal(await d.failure(),null);const bytes=fs.readFileSync(await d.path());assert.ok(bytes.length>10000);if(extension==='.glb')assert.equal(bytes.toString('ascii',0,4),'glTF');
}
await page.locator('a[href="HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.tex"]').count().then(n=>assert.equal(n,1));
for(const sub of ['HUONG-DAN.html','blueprint/index.html']){
 await page.goto(base+sub+'?rev='+commit,{waitUntil:'networkidle'});
 assert.ok(await page.locator('img').evaluateAll(imgs=>imgs.length>0&&imgs.every(i=>i.complete&&i.naturalWidth>0)),sub+' images');
}
await page.setViewportSize({width:390,height:844});await page.goto(base+'?rev='+commit,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.MAZE_API);assert.ok(await page.locator('#view canvas').isVisible());
await page.screenshot({path:root+'previews/deployed-mobile.png'});
await browser.close();assert.deepEqual(errors,[]);
const report={status:'PASS_LIVE_GITHUB_PAGES',url:base,commit,verifiedAt:new Date().toISOString(),assetsChecked:checked.length,allBytesMatch:true,phases,animatedEmergencyRelease:true,pngAndGlbDownloads:true,guideAvailable:true,mobileViewport:[390,844],javascriptErrors:errors,files:checked.sort((a,b)=>a.file.localeCompare(b.file))};
fs.writeFileSync(root+'deployment-validation.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({status:report.status,url:base,commit,assetsChecked:checked.length,errors}));
