import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const icon='<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 32 32%27%3E%3Crect width=%2732%27 height=%2732%27 fill=%27%231b3037%27/%3E%3Cpath d=%27M6 6h20v20H6zm6 6h14M12 12v14%27 fill=%27none%27 stroke=%27%23bddcc5%27 stroke-width=%273%27/%3E%3C/svg%3E">';
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['baseline','node_modules','.git'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(p.endsWith('.html')){let s=fs.readFileSync(p,'utf8');if(!s.includes('rel="icon"')){s=s.replace(/(<meta charset=["']?utf-8["']?\s*\/?>)/i,'$1'+icon);fs.writeFileSync(p,s);}}}}
walk(root);
const deliveryPath=path.join(root,'DELIVERY.json');
if(fs.existsSync(deliveryPath)){const d=JSON.parse(fs.readFileSync(deliveryPath,'utf8'));for(const p of Object.keys(d.hashes??{}))d.hashes[p]=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex');fs.writeFileSync(deliveryPath,JSON.stringify(d,null,2)+'\n');}
