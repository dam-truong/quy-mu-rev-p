import fs from 'node:fs';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {dependency} from './deps.mjs';
import * as L from '../src/layout.js';
const root=fileURLToPath(new URL('../',import.meta.url));
const {chromium}=await dependency('playwright'),THREE=await dependency('three');
const browser=await chromium.launch({channel:'msedge',headless:true}),page=await browser.newPage({viewport:{width:1800,height:1200}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto(pathToFileURL(root+'model-360.html').href);await page.waitForFunction(()=>window.MAZE_API);
const phaseEvidence=[];
for(let s=0;s<4;s++){
 await page.evaluate(s=>{const a=window.MAZE_API;a.setCut(false);a.setPhase(s);},s);
 const items=await page.evaluate(()=>window.MAZE_API.groups.dynamic.children.map(m=>({name:m.name,role:m.userData.role,segment:m.userData.segmentMeters})));
 assert.equal(items.filter(i=>i.role==='rotating-wall').length,4);
 assert.equal(items.some(i=>i.name==='C06'),s<3);
 assert.equal(items.filter(i=>i.role==='lock').length,L.LOCKS.filter(l=>!L.STAGES[s].open.includes(l.id)).length);
 phaseEvidence.push({phase:s,closures:items});
}
const sweeps=[];
for(const from of [0,1])for(const t of [0,.5,1]){
 const v=await page.evaluate(({from,t})=>{const a=window.MAZE_API;a.sweepAt(from,from+1,t);return {released:a.emergencyMeshes.every(m=>!m.visible)&&a.onewayMeshes.every(m=>!m.visible),rotations:a.groups.dynamic.children.filter(m=>m.userData.sweepFraction!==undefined).map(m=>({id:m.name,angle:m.rotation.y,position:m.position.toArray()}))};},{from,t});
 assert.ok(v.released);assert.equal(v.rotations.length,2);sweeps.push({from,t,...v});
}
for(const from of [0,1]){const a=sweeps.find(v=>v.from===from&&v.t===0),b=sweeps.find(v=>v.from===from&&v.t===1);for(let i=0;i<2;i++)assert.ok(Math.abs(Math.abs(a.rotations[i].angle-b.rotations[i].angle)-Math.PI/2)<1e-9);}
await page.evaluate(()=>{const a=window.MAZE_API;a.setPhase(0);a.setView('eye');});await page.waitForTimeout(250);await page.screenshot({path:root+'previews/ra-lang-ngang-mat.png'});
await page.evaluate(()=>{const a=window.MAZE_API;a.setView('orbit');a.setCut(true);a.camera.position.set(6,10,11);a.controls.target.set(5.5,0,6.2);});await page.waitForTimeout(250);await page.screenshot({path:root+'previews/khu-ba-tuong-sau-3d.png'});
// Use the untouched REV O viewer, with the same camera, to provide honest before imagery.
const before=await browser.newPage({viewport:{width:1800,height:1200}});await before.goto(pathToFileURL(root+'baseline/viewer-O.html').href);await before.waitForFunction(()=>window.MAZE_API);
await before.evaluate(()=>{const a=window.MAZE_API;a.setPhase(0);a.setView('plan');});await before.waitForTimeout(200);await before.screenshot({path:root+'previews/REV-O-mat-bang.png'});
// REV O API does not expose its camera: the source comparison below uses identical SVG framing.
await before.close();
await page.setViewportSize({width:390,height:844});await page.evaluate(()=>window.MAZE_API.setView('orbit'));await page.waitForTimeout(150);assert.ok(await page.locator('#view canvas').isVisible());await page.screenshot({path:root+'previews/mobile.png'});
assert.deepEqual(errors,[]);await browser.close();
// Parse exported GLB transforms and POSITION accessor bounds. Compare actual
// wall boxes against the source segment dimensions (not only node metadata).
const glbs=[];
for(let s=0;s<4;s++){
 const raw=fs.readFileSync(root+`Quy-Mu-REV-P-S${s}.glb`);assert.equal(raw.toString('ascii',0,4),'glTF');assert.equal(raw.readUInt32LE(4),2);assert.equal(raw.readUInt32LE(8),raw.length);
 const len=raw.readUInt32LE(12),g=JSON.parse(raw.toString('utf8',20,20+len));let checked=0;const fixed=[],mechanisms=[];
 const visit=(id,parent)=>{const n=g.nodes[id],local=n.matrix?new THREE.Matrix4().fromArray(n.matrix):new THREE.Matrix4().compose(new THREE.Vector3(...(n.translation??[0,0,0])),new THREE.Quaternion(...(n.rotation??[0,0,0,1])),new THREE.Vector3(...(n.scale??[1,1,1]))),world=parent.clone().multiply(local);
  if(n.mesh!==undefined&&n.extras?.segmentMeters){const seg=n.extras.segmentMeters,[x,z,a,b]=seg,primitive=g.meshes[n.mesh].primitives[0],accessor=g.accessors[primitive.attributes.POSITION],box=new THREE.Box3(new THREE.Vector3(...accessor.min),new THREE.Vector3(...accessor.max)).applyMatrix4(world),expected=new THREE.Box3(new THREE.Vector3(Math.min(x,a)-L.WALL_THICKNESS/2,0,Math.min(z,b)-L.WALL_THICKNESS/2),new THREE.Vector3(Math.max(x,a)+L.WALL_THICKNESS/2,n.extras.height,Math.max(z,b)+L.WALL_THICKNESS/2));assert.ok(box.min.distanceTo(expected.min)<.002&&box.max.distanceTo(expected.max)<.002,`GLB wall mismatch ${n.name}`);checked++;if(n.extras.role==='fixed-wall')fixed.push(seg);else if(['lock','rotating-wall','exit-closure'].includes(n.extras.role))mechanisms.push(seg);}
  for(const child of n.children??[])visit(child,world);
 };for(const id of g.scenes[g.scene??0].nodes)visit(id,new THREE.Matrix4());
 const near=(p,q)=>p.every((v,i)=>Math.abs(v-q[i])<.001),covered=(p,w)=>Math.abs(p[0]-w[0])<.001&&Math.abs(w[0]-w[2])<.001&&p[1]>=w[1]-.001&&p[1]<=w[3]+.001||Math.abs(p[1]-w[1])<.001&&Math.abs(w[1]-w[3])<.001&&p[0]>=w[0]-.001&&p[0]<=w[2]+.001;
 for(const src of L.WALLS)for(let j=0;j<=10;j++)assert.ok(fixed.some(w=>covered([src[0]+(src[2]-src[0])*j/10,src[1]+(src[3]-src[1])*j/10],w)),'Missing fixed GLB wall');
 for(const w of fixed)for(let j=0;j<=10;j++)assert.ok(L.WALLS.some(src=>covered([w[0]+(w[2]-w[0])*j/10,w[1]+(w[3]-w[1])*j/10],src)),'Extra fixed GLB wall');
 assert.equal(mechanisms.length,L.STAGES[s].closed.length+(s<3?1:0));for(const e of phaseEvidence[s].closures)assert.ok(mechanisms.some(m=>near(m,e.segment)),'GLB closure differs from viewer');
 glbs.push({phase:s,bytes:raw.length,checkedWallBoxes:checked,fixedCoverageMatches:true,closureGeometryMatches:true});
}
const out={status:'PASS_RENDER_GEOMETRY',stages:phaseEvidence,sweeps,glbs,javascriptErrors:errors,mobileViewport:[390,844],eyeHeightMeters:1.6};fs.writeFileSync(root+'render-validation.json',JSON.stringify(out,null,2));console.log(JSON.stringify({status:out.status,glbs,errors}));
