import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);
export const dependencyPaths=[fileURLToPath(new URL('../node_modules',import.meta.url)),fileURLToPath(new URL('../../quy-mu-rev-L/node_modules',import.meta.url))];
export async function dependency(name){const m=await import(pathToFileURL(require.resolve(name,{paths:dependencyPaths})).href);return m.default??m;}
