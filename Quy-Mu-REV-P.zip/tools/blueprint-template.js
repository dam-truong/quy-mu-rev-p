// Bộ blueprint REV L vẽ từ src/layout.js. Mở blueprint/?sheet=K-01 … K-07 (2560 × 2100 px).
// Tọa độ vẽ tính bằng mét (P, Q); dữ liệu đồ thị (ô) đổi ra mét bằng CELL.
import { WALLS, ROOMS, DOORS, ZONE_AREA, MAZE, LABEL_POS, WALL_THICKNESS, LOCKS, ONEWAY, SHIFTS, STAGES, STAGE_REACH, ROUTE_LEN, POI, CELL, GRID, ROOM_SIZE, JULIUS_REPORT as JR } from '../src/layout.js';
import { isMaze, deadEndBranches, key, stateOut, pathIn } from './analysis.js';

const SHEET = new URLSearchParams(location.search).get('sheet') || 'K-01';
const W = 2560, H = 2100, OX = 218, OY = 490, S = 1300 / ROOM_SIZE; // mặt bằng luôn rộng 1300 px
const P = x => OX + x * S, Q = z => OY + z * S, SC = S * CELL;
const C = { bg: '#082b50', grid: '#0c3561', frame: '#3f6d94', plan: '#0c355b', corr: '#103d62', room: '#194a70', hall: '#14456c',
  wall: '#1b4b70', wallLine: '#b0cfe4', text: '#d7ecfa', sub: '#b9d6ea', cyan: '#5cc8f2', yellow: '#ffcc80' };
const FONT = `'Helvetica Neue', Arial, sans-serif`;
const DATE = '14.10.2026', REV = 'REV N';
const fmt2 = v => v.toFixed(2).replace('.', ',');
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const mmss = t => `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

const parts = [];
const add = s => parts.push(s);
const text = (x, y, s, size, fill = C.text, opt = '') => add(`<text x="${x}" y="${y}" font-size="${size}" fill="${fill}" font-family="${FONT}" ${opt}>${esc(s)}</text>`);
const line = (x1, y1, x2, y2, stroke, w = 2, opt = '') => add(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${w}" ${opt}/>`);
const rect = (x, y, w, h, fill, opt = '') => add(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" ${opt}/>`);
const poly = (pts, stroke, w, opt = '') => add(`<polyline points="${pts.map(([x, z]) => `${P(x)},${Q(z)}`).join(' ')}" fill="none" stroke="${stroke}" stroke-width="${w}" stroke-linejoin="round" stroke-linecap="round" ${opt}/>`);

const deadEnds = deadEndBranches();
const center = ([x, z]) => [(x + 0.5) * CELL, (z + 0.5) * CELL];        // ô -> tâm (mét)
const GATE_DOOR = DOORS.find(d => d.id === 'C02');
const EXIT_DOOR = DOORS.find(d => d.kind === 'exit');
const RED = '#ff6b5a', ORANGE = '#ff9f43', VIOLET = '#c995ff', SILVER = '#e8f4ff', STAGE_COL = { giam: '#ffcc80', canh: '#ff9f43', te: '#ff7a9a', exit: '#7ee0a8' };
// mã ô cho thợ: hàng chữ A–L theo z (A = sát tường trên), cột số 1–12 theo x
const ROWN = 'ABCDEFGHIJKL';
const cellName = ([x, z]) => `${ROWN[z]}${x + 1}`;
const pairName = (a, b) => `${cellName(a)}–${cellName(b)}`;
const GOAL_NAME = { giam: 'Giam Vọng Âm', canh: 'Người canh ấn', te: 'Tế thần', exit: `cửa thoát ${EXIT_DOOR.id}` };
const START_OF = st => st.from === 'gate' ? MAZE.gate : MAZE.rooms[st.from];
const GOAL_OF = st => st.goal === 'exit' ? MAZE.exit : MAZE.rooms[st.goal];
const firstStage = new Map();
for (const s of ['s2', 's1', 's0']) for (const c of STAGE_REACH[s]) firstStage.set(key(c), Number(s[1]));
const LEG = ['Cổng → Giam', 'Giam → Người canh', 'Người canh → Tế', 'Tế → cửa thoát'];

// ---------------- khung trang chung
function frame(subtitle) {
  rect(0, 0, W, H, C.bg);
  for (let x = 0; x <= W; x += 26) line(x, 0, x, H, C.grid, 1);
  for (let y = 0; y <= H; y += 26) line(0, y, W, y, C.grid, 1);
  rect(50, 50, W - 100, H - 100, 'none', `stroke="${C.frame}" stroke-width="1.5"`);
  text(110, 125, 'ESCAPE ROOM BIÊN HÒA / BỐ CỤC KHÔNG GIAN CHƠI', 22);
  text(110, 240, `QUỶ MÙ / ${ROOM_SIZE} × ${ROOM_SIZE} m`, 76);
  text(110, 300, subtitle, 31);
  text(2440, 130, `QM / ${SHEET}`, 46, C.text, 'text-anchor="end"');
  text(2440, 192, `${REV} / ${DATE}`, 23, C.cyan, 'text-anchor="end"');
}
function footer() {
  text(2440, 1930, 'CHỈ TƯỜNG + KHÔNG GIAN CHƠI', 40, C.text, 'text-anchor="end"');
  text(2440, 1985, `${REV} · Chưa phải hồ sơ thi công`, 23, C.text, 'text-anchor="end"');
}
function areaHeader() {
  text(1650, 520, `${ROOM_SIZE * ROOM_SIZE} m²`, 76);
  text(1650, 575, `Kích thước tổng theo yêu cầu · ô lưới ${fmt2(CELL)} m`, 26);
  line(1650, 615, 2440, 615, C.frame, 1.5);
}

// ---------------- mặt bằng
function dims() {
  const y = 425, x = 150, mm = `${(ROOM_SIZE * 1000).toLocaleString('vi-VN').replace(/\./g, ' ')} mm`;
  line(P(0), y, P(ROOM_SIZE), y, C.cyan, 2); line(P(0) - 12, y + 12, P(0) + 12, y - 12, C.cyan, 2); line(P(ROOM_SIZE) - 12, y + 12, P(ROOM_SIZE) + 12, y - 12, C.cyan, 2);
  text((P(0) + P(ROOM_SIZE)) / 2, y - 18, mm, 26, C.cyan, 'text-anchor="middle"');
  line(x, Q(0), x, Q(ROOM_SIZE), C.cyan, 2); line(x - 12, Q(0) - 12, x + 12, Q(0) + 12, C.cyan, 2); line(x - 12, Q(ROOM_SIZE) - 12, x + 12, Q(ROOM_SIZE) + 12, C.cyan, 2);
  text(x - 22, (Q(0) + Q(ROOM_SIZE)) / 2, mm, 26, C.cyan, `text-anchor="middle" transform="rotate(-90 ${x - 22} ${(Q(0) + Q(ROOM_SIZE)) / 2})"`);
}
function gridNames() {
  for (let x = 0; x < GRID.cols; x++) text(P((x + 0.5) * CELL), Q(0) - 14, String(x + 1), 18, C.sub, 'text-anchor="middle"');
  for (let z = 0; z < GRID.rows; z++) text(P(0) - 24, Q((z + 0.5) * CELL) + 6, ROWN[z], 18, C.sub, 'text-anchor="middle"');
}
const cellRect = ([x, z], fill, opt = '') => rect(P(x * CELL), Q(z * CELL), SC, SC, fill, opt);
// tint: tô ô theo giai đoạn sớm nhất tới được (s0 sáng nhất)
function floors(tint) {
  rect(P(0), Q(0), ROOM_SIZE * S, ROOM_SIZE * S, C.plan);
  for (let z = 0; z < MAZE.depth; z++) for (let x = 0; x < GRID.cols; x++) {
    if (!isMaze([x, z])) continue;
    const s = firstStage.get(key([x, z]));
    cellRect([x, z], tint && s !== undefined ? ['#1a4f7c', '#163f6a', '#122f57'][s] : C.corr);
  }
  for (const r of ROOMS) rect(P(r[0]), Q(r[1]), (r[2] - r[0]) * S, (r[3] - r[1]) * S, C.room);
}
function walls() {
  const t = WALL_THICKNESS;
  for (const [x1, z1, x2, z2] of WALLS) {
    const hz = Math.abs(z1 - z2) < 1e-9;
    const x = P(x1) - t / 2 * S, y = Q(z1) - t / 2 * S;
    const w = hz ? (x2 - x1 + t) * S : t * S, h = hz ? t * S : (z2 - z1 + t) * S;
    rect(x, y, w, h, C.wall, `stroke="${C.wallLine}" stroke-width="1.4"`);
  }
}
function doors(labels = true) {
  for (const d of DOORS) {
    if (d.kind === 'exit') continue;                    // cửa thoát ẩn: vẽ ở security()
    if (d.axis === 'x') line(P(d.x - CELL / 2), Q(d.z), P(d.x + CELL / 2), Q(d.z), C.cyan, 4);
    else line(P(d.x), Q(d.z - CELL / 2), P(d.x), Q(d.z + CELL / 2), C.cyan, 4);
    if (!labels) continue;
    const off = d.x === 0 ? [-62, 8] : d.axis === 'x' ? [16, -12] : [10, -20];
    text(P(d.x) + off[0], Q(d.z) + off[1], d.id, 20, C.cyan);
  }
}
const openingOf = (a, b) => a[0] !== b[0] ? { x: Math.max(a[0], b[0]) * CELL, z: (a[1] + 0.5) * CELL, axis: 'z' } : { x: (a[0] + 0.5) * CELL, z: Math.max(a[1], b[1]) * CELL, axis: 'x' };
const openLine = (o, stroke, w, opt = '') => o.axis === 'x' ? line(P(o.x - CELL / 2), Q(o.z), P(o.x + CELL / 2), Q(o.z), stroke, w, opt) : line(P(o.x), Q(o.z - CELL / 2), P(o.x), Q(o.z + CELL / 2), stroke, w, opt);
const segLine = ([x1, z1, x2, z2], stroke, w, opt = '') => line(P(x1 * CELL), Q(z1 * CELL), P(x2 * CELL), Q(z2 * CELL), stroke, w, opt);
// stage: null = vẽ cả hai vị trí tường xoay (đặc = lúc đầu, đứt + cung = sau khi xoay); số = chỉ vị trí ở giai đoạn đó
function security(labels = true, stage = null) {
  for (const l of LOCKS) {
    if (stage !== null && STAGES[stage].open.includes(l.id)) continue;
    const o = openingOf(l.a, l.b); openLine(o, RED, 7, 'stroke-dasharray="10 7"');
    if (labels) text(P(o.x) + (o.axis === 'z' ? 10 : 0), Q(o.z) + (o.axis === 'x' ? -12 : 6), `${l.id} ẩn`, 20, RED, o.axis === 'x' ? 'text-anchor="middle"' : '');
  }
  if (stage === null || stage < 3) {                    // cửa thoát C06: tường trượt ẩn tới khi xong Tế
    line(P(EXIT_DOOR.x), Q(EXIT_DOOR.z - CELL / 2), P(EXIT_DOOR.x), Q(EXIT_DOOR.z + CELL / 2), '#7ee0a8', 7, 'stroke-dasharray="10 7"');
    if (labels) text(P(EXIT_DOOR.x) + 16, Q(EXIT_DOOR.z) + 8, `${EXIT_DOOR.id} ẩn`, 20, '#7ee0a8');
  }
  for (const s of SHIFTS) {
    const k = Number(s.at.slice(1)), [px, pz] = s.post;
    if (stage === null) {
      const far = seg => seg[0] === px && seg[1] === pz ? [seg[2], seg[3]] : [seg[0], seg[1]];
      const [bx, bz] = far(s.before), [ax, az] = far(s.after);
      segLine(s.after, VIOLET, 6, 'stroke-dasharray="9 7" opacity="0.85"');
      const sweep = ((bx - px) * (az - pz) - (bz - pz) * (ax - px)) > 0 ? 1 : 0;
      add(`<path d="M ${P(bx * CELL)} ${Q(bz * CELL)} A ${SC} ${SC} 0 0 ${sweep} ${P(ax * CELL)} ${Q(az * CELL)}" fill="none" stroke="${VIOLET}" stroke-width="2" stroke-dasharray="4 6"/>`);
      segLine(s.before, VIOLET, 9);
      if (labels) text(P(((bx + ax) / 4 + px / 2) * CELL), Q(((bz + az) / 4 + pz / 2) * CELL) + 7, s.id, 20, VIOLET, 'text-anchor="middle"');
    } else segLine(stage < k ? s.before : s.after, VIOLET, 9);
    add(`<circle cx="${P(px * CELL)}" cy="${Q(pz * CELL)}" r="7" fill="${VIOLET}"/>`);
  }
  for (const w of ONEWAY) {
    const o = openingOf(w.from, w.to), d = [w.to[0] - w.from[0], w.to[1] - w.from[1]], cx = P(o.x), cy = Q(o.z), L = 22;
    const tip = [cx + d[0] * L, cy + d[1] * L], b1 = [cx - d[0] * 7 + d[1] * 15, cy - d[1] * 7 + d[0] * 15], b2 = [cx - d[0] * 7 - d[1] * 15, cy - d[1] * 7 - d[0] * 15];
    add(`<polygon points="${tip.join(',')} ${b1.join(',')} ${b2.join(',')}" fill="${ORANGE}" stroke="${C.bg}" stroke-width="2"/>`);
  }
}
// gương: vạch bạc trên mặt tường; cửa giả: vạch vàng đứt
function illusions() {
  const onWall = (p, stroke, w, opt = '') => {
    const h = CELL * 0.38, along = Math.abs(Math.sin(p.ry)) > 0.5 ? [0, h] : [h, 0];
    line(P(p.x - along[0]), Q(p.z - along[1]), P(p.x + along[0]), Q(p.z + along[1]), stroke, w, opt);
  };
  for (const m of POI.mirrors) onWall(m, SILVER, 7);
  for (const f of POI.fakeDoors) onWall(f, C.yellow, 7, 'stroke-dasharray="6 5"');
}
function withGroup(transform, fn) { const start = parts.length; fn(); const inner = parts.splice(start).join(''); add(`<g transform="${transform}">${inner}</g>`); }

function zoneLabels(withDims = true) {
  const box = (name, sub, r) => {
    const cx = P((r[0] + r[2]) / 2), cy = Q((r[1] + r[3]) / 2);
    text(cx, cy - (sub ? 8 : -8), name, 24, C.text, 'text-anchor="middle"');
    if (sub) text(cx, cy + 28, sub, 21, C.cyan, 'text-anchor="middle"');
  };
  const dimOf = r => withDims ? `${fmt2(r[2] - r[0])} × ${fmt2(r[3] - r[1])} m` : '';
  { const [x, z] = LABEL_POS[1]; text(P(x), Q(z) - 8, '01 / Làng / xin đường', 26, C.text, 'text-anchor="middle"'); if (withDims) text(P(x), Q(z) + 30, dimOf(ROOMS[0]), 22, C.cyan, 'text-anchor="middle"'); }
  box('07 / Tế thần', dimOf(ROOMS[1]), ROOMS[1]);
  box('04 / Giam Vọng Âm', dimOf(ROOMS[2]), ROOMS[2]);
  box('05 / Người canh ấn', dimOf(ROOMS[3]), ROOMS[3]);
  { const [x, z] = LABEL_POS[2]; text(P(x), Q(z) + 30, '02 / Cổng', 22, C.text, 'text-anchor="middle"'); }
}
function plan({ tint = false, labels = true, dimsOn = true, secLabels = labels } = {}) {
  dims(); floors(tint); walls(); illusions(); doors(labels); security(secLabels); zoneLabels(dimsOn);
  text(P(0), 1868, `C01: CỬA VÀO LÀNG / ${GATE_DOOR.id}: CỔNG MÊ CUNG / ${EXIT_DOOR.id}: CỬA THOÁT (ẨN)`, 22, C.cyan);
}
function marker([x, z], label, stroke = C.yellow, r = 19) {
  add(`<circle cx="${P(x)}" cy="${Q(z)}" r="${r}" fill="${C.bg}" stroke="${stroke}" stroke-width="2"/>`);
  text(P(x), Q(z) + 5, label, 14, stroke, 'text-anchor="middle"');
}

// ---------------- danh sách khu bên phải
const ZONE_ROWS = [[1, '01 / Làng / xin đường'], [2, '02 / Cổng mê cung'], [3, '03 / Mê cung ngoài'], [4, '04 / Giam Vọng Âm'], [5, '05 / Người canh ấn'], [6, '06 / Mê cung trong'], [7, '07 / Tế thần']];
function zoneList(y0 = 690, step = 100, withArea = true) {
  ZONE_ROWS.forEach(([id, name], i) => {
    text(1650, y0 + i * step, name, 29);
    if (withArea) text(1650, y0 + i * step + 40, `${fmt2(ZONE_AREA[id])} m²`, 22, C.cyan);
  });
}
function notes(y, lines) {
  line(1650, y - 60, 2440, y - 60, C.frame, 1.5);
  text(1650, y, lines[0], 26, C.cyan);
  lines.slice(1).forEach((l, i) => text(1650, y + 50 + i * 40, l, 21));
}

// ---------------- chú thích từng cơ chế (K-06): mã, vị trí, giải thích ngắn
const out2 = stateOut(STAGES[2]);
const detour = (a, b) => { const p = pathIn(a, b, out2); return p ? p.length - 1 : null; };
const cellAt = (x, z) => [Math.floor(x / CELL), Math.floor(z / CELL)];
const wallCell = p => cellAt(p.x + Math.sin(p.ry) * 0.25, p.z + Math.cos(p.ry) * 0.25); // lùi từ mặt tường vào ô
const midOf = (a, b) => center(a).map((v, i) => (v + center(b)[i]) / 2);
const ITEMS = [
  ...LOCKS.map(l => ({ code: l.id, at: midOf(l.a, l.b), col: RED, text: `${pairName(l.a, l.b)}: tường đá trượt ẩn, trông như tường thường; mở khi xong ${GOAL_NAME[l.after]}.` })),
  { code: EXIT_DOOR.id, at: [EXIT_DOOR.x - 0.25, EXIT_DOOR.z], col: '#7ee0a8', text: `${cellName(MAZE.exit)}: cửa thoát ẩn trong tường, chỉ lộ ra khi xong Tế thần.` },
  ...SHIFTS.map(s => ({ code: s.id, at: s.post.map(v => v * CELL), col: VIOLET, text: `trụ góc ${cellName(s.freed[0])}: khi ${s.at} mở, tấm quay 90° — mở lối ${pairName(...s.freed)}, chặn lối ${pairName(...s.shut)}.` })),
  ...ONEWAY.map((o, i) => ({ code: `W${i + 1}`, at: midOf(o.from, o.to), col: ORANGE, text: `${cellName(o.from)} → ${cellName(o.to)}: cánh lò xo một chiều; quay lại phải đi vòng ${detour(o.to, o.from) ?? '?'} ô.` })),
  ...POI.mirrors.map((m, i) => ({ code: `M${i + 1}`, at: [m.x, m.z], col: SILVER, text: `${cellName(wallCell(m))}: gương mica cuối ngõ cụt — nhìn từ xa như hành lang chạy tiếp.` })),
  ...POI.fakeDoors.map((f, i) => ({ code: `F${i + 1}`, at: [f.x, f.z], col: C.yellow, text: `${cellName(wallCell(f))}: cửa gỗ giả đóng chết cuối ngõ cụt.` })),
  ...POI.peeps.map((p, i) => {
    const [a, b] = p.ry ? [cellAt(p.x - 0.3, p.z), cellAt(p.x + 0.3, p.z)] : [cellAt(p.x, p.z - 0.3), cellAt(p.x, p.z + 0.3)];
    return { code: `K${i + 1}`, at: [p.x, p.z], col: C.cyan, text: `${pairName(a, b)}: khe nhìn — thấy ô bên kia sát vách nhưng phải đi ${detour(a, b) ?? '?'} ô.` };
  }),
];

// ---------------- 7 tờ
async function sheet() {
  if (SHEET === 'K-01') {
    frame('Mặt bằng tường và các khu chơi / mê cung đã qua thanh tra Julius (K-07)');
    plan(); areaHeader(); zoneList();
    notes(1460, ['CHÚ GIẢI / CHI TIẾT TỪNG CƠ CHẾ Ở K-06', 'Đỏ đứt: L1, L2 tường trượt ẩn · xanh lá đứt: cửa thoát ẩn.',
      `Tím: ${SHIFTS.length} tường xoay — đặc = lúc đầu, đứt + cung = sau khi xoay.`, `Cam: ${ONEWAY.length} cửa một chiều (mũi tên = chiều đi được).`,
      `Bạc: ${POI.mirrors.length} gương mica · vàng đứt: ${POI.fakeDoors.length} cửa giả.`, `Hành lang ${fmt2(CELL)} m tim tường (thông thủy ${fmt2(CELL - WALL_THICKNESS)} m).`]);
    footer();
  } else if (SHEET === 'K-03') {
    frame('Tuyến truyện / đường đúng từng chặng và mã ký hiệu ở ngã rẽ');
    plan({ tint: true });
    for (const st of STAGES) {
      const p = pathIn(START_OF(st), GOAL_OF(st), stateOut(st));
      const tail = st.goal === 'exit' ? [[ROOM_SIZE + 0.4, EXIT_DOOR.z]] : (() => { const d = DOORS.find(dd => dd.id === MAZE.roomDoors[st.goal]), [cx, cz] = center(MAZE.rooms[st.goal]); return [[d.x, d.z], [d.x + (d.x - cx), d.z + (d.z - cz)]]; })();
      poly([...p.map(center), ...tail], STAGE_COL[st.goal], 4, st.goal === 'exit' ? 'stroke-dasharray="14 10"' : '');
    }
    poly([[-0.5, DOORS[0].z], [GATE_DOOR.x, DOORS[0].z], [GATE_DOOR.x, (MAZE.gate[1] + 0.5) * CELL]], C.yellow, 4);
    for (const sy of POI.symbols) {
      const [x, y] = [P(sy.x), Q(sy.z)];
      rect(x - 13, y - 13, 26, 26, C.bg, `stroke="${sy.ok ? C.yellow : C.sub}" stroke-width="2" opacity="0.95"`);
      text(x, y + 6, { gieng: 'G', lua: 'R', kho: 'K', mieu: 'M' }[sy.sym], 16, sy.ok ? C.yellow : C.sub, 'text-anchor="middle"');
    }
    for (const [px, pz] of POI.plates) rect(P(px) - 19, Q(pz) - 19, 38, 38, 'none', `stroke="${ORANGE}" stroke-width="2" stroke-dasharray="4 4"`);
    marker(center(MAZE.gate), 'G', C.cyan, 18);
    areaHeader();
    text(1650, 690, 'ĐƯỜNG ĐÚNG / THANH TRA JULIUS (TRUNG VỊ)', 26, C.cyan);
    STAGES.forEach((st, i) => {
      const y = 750 + i * 115, k = st.goal;
      text(1650, y, `${i + 1}. ${LEG[i]}`, 26, STAGE_COL[k]);
      text(1650, y + 38, `${ROUTE_LEN[k]} ô đúng (${fmt2(ROUTE_LEN[k] * CELL)} m) · Julius mất ~${mmss(JR.legMed[i])}`, 22);
    });
    notes(1340, ['ĐỌC MÃ Ở NGÃ RẼ', 'Ô vuông G/R/K/M: ký hiệu khắc sàn. Vàng = đúng thứ tự', 'Giếng → Ruộng → Kho → Miếu; xám = ký hiệu mồi lệch thứ tự.',
      'Người chơi đọc được mã thì đi đúng; Julius (không biết mã)', 'phải dò mò. Ô đứt cam: sàn chuông.', 'Nền ô: sáng = vào được ngay, tối dần = mở sau L1, L2.']);
    footer();
  } else if (SHEET === 'K-04') {
    frame('Lối giả / chiều dài tính từ ngã rẽ tới đầu cụt');
    plan({ labels: true, dimsOn: false });
    deadEnds.forEach((d, i) => {
      const long = d.length >= 3;
      poly(d.cells.map(center).reverse(), long ? C.yellow : C.sub, 4, long ? '' : 'opacity="0.75"');
      marker(center(d.cells[0]), `N${String(i + 1).padStart(2, '0')}`, long ? C.yellow : C.sub);
    });
    areaHeader();
    text(1650, 690, 'MÃ / Ô / CHIỀU DÀI / SỐ LẦN RẼ', 26, C.cyan);
    const step = Math.min(46, 900 / deadEnds.length);
    deadEnds.forEach((d, i) => text(1650, 740 + i * step, `N${String(i + 1).padStart(2, '0')}  ${cellName(d.cells[0])}  ${fmt2(d.length * CELL)} m  ${d.turns} lần rẽ`, Math.min(24, step - 4), d.length >= 3 ? C.yellow : C.text));
    const longest = Math.max(...deadEnds.map(d => d.length));
    const y = 740 + deadEnds.length * step + 60;
    text(1650, y, `${deadEnds.length} ngõ cụt; dài nhất ${fmt2(longest * CELL)} m (${longest} ô).`, 25, C.cyan);
    text(1650, y + 45, 'Mỗi ngõ cụt dài là một lần Julius phải đi vào rồi quay ra.', 22);
    text(1650, y + 85, 'Cuối ngõ thẳng dán gương, ngõ cong dựng cửa giả.', 22);
    footer();
  } else if (SHEET === 'K-05') {
    frame('Hệ thống khóa + tường xoay / vùng đi tới được theo tiến độ giải đố');
    const k = 0.5, panels = [[110, 400], [820, 400], [110, 1200], [820, 1200]];
    const reachSets = [STAGE_REACH.s0, STAGE_REACH.s1, STAGE_REACH.s2, STAGE_REACH.s2];
    STAGES.forEach((st, i) => {
      const [gx, gy] = panels[i], reach = new Set(reachSets[i].map(key));
      text(gx, gy - 22, `${i}. ${st.label.toUpperCase()}`, 24, C.cyan);
      withGroup(`translate(${gx},${gy}) scale(${k}) translate(${-P(0)},${-Q(0)})`, () => {
        rect(P(0), Q(0), ROOM_SIZE * S, ROOM_SIZE * S, C.plan);
        for (let z = 0; z < MAZE.depth; z++) for (let x = 0; x < GRID.cols; x++) if (isMaze([x, z])) cellRect([x, z], reach.has(key([x, z])) ? '#24628f' : '#081e36');
        for (const r of ROOMS) rect(P(r[0]), Q(r[1]), (r[2] - r[0]) * S, (r[3] - r[1]) * S, C.room);
        walls(); doors(false); security(false, i);
        const [x, z] = st.goal === 'exit' ? [EXIT_DOOR.x - CELL / 2, EXIT_DOOR.z] : center(GOAL_OF(st));
        add(`<circle cx="${P(x)}" cy="${Q(z)}" r="30" fill="none" stroke="${C.yellow}" stroke-width="7"/>`);
      });
      text(gx, gy + ROOM_SIZE * S * k + 34, `Mục tiêu: ${GOAL_NAME[st.goal]} · đường đúng ${ROUTE_LEN[st.goal]} ô`, 22, C.text);
      text(gx, gy + ROOM_SIZE * S * k + 64, `Julius (trung vị) mất ${mmss(JR.legMed[i])} cho chặng này`, 20, C.sub);
    });
    const x0 = 1560;
    text(x0, 440, '7 LỚP NHỐT NGƯỜI', 30, C.cyan);
    const Lr = [
      ['1. Mê cung dày đặc kiểu mẫu', `Lưới ${GRID.cols} × ${GRID.rows} ô ${fmt2(CELL)} m, dạng cây: hành lang rẽ liên tục,`, `${deadEnds.length} ngõ cụt; mỗi ngõ phải đi vào rồi quay ra.`],
      ['2. Khóa ẩn tuần tự', 'L1, L2 và cửa thoát đều là tường trượt trông như tường thường.', 'Giải xong phòng không biết cái gì vừa mở → phải soát lại.'],
      [`3. Tường xoay ×${SHIFTS.length}`, 'X1, X2 quay khi mở L1; X3, X4 quay khi mở L2:', 'bản đồ đã thuộc sai đi, lối cũ bị chặn, lối mới mở ra.'],
      [`4. Cửa một chiều ×${ONEWAY.length}`, 'Cánh lò xo chỉ đẩy một phía; đi qua là không lội ngược,', 'phải đi vòng — phá chiến thuật đánh dấu lùi.'],
      [`5. Gương ×${POI.mirrors.length} + cửa giả ×${POI.fakeDoors.length}`, 'Gương cuối ngõ thẳng: nhìn từ xa như hành lang chạy tiếp,', 'phải đi tới sát mới biết. Cửa giả đóng chết cuối ngõ cong.'],
      ['6. Mã ở ngã rẽ', 'Ký hiệu khắc sàn Giếng → Ruộng → Kho → Miếu (học ở Làng)', 'là đường đúng. Thanh tra Julius không dùng mã.'],
      [`7. Khe nhìn ×${POI.peeps.length}, sàn chuông ×${POI.plates.length}, quỷ`, 'Thấy chỗ cần tới sát bên mà phải đi vòng xa; giẫm sàn chuông', 'là chuông kêu, quỷ quay về hướng đó.'],
    ];
    Lr.forEach(([h, a, b], i) => { const y = 500 + i * 128; text(x0, y, h, 25, C.text); text(x0, y + 35, a, 20, C.sub); if (b) text(x0, y + 64, b, 20, C.sub); });
    line(x0, 1420, 2440, 1420, C.frame, 1.5);
    text(x0, 1470, 'AN TOÀN VẬN HÀNH', 26, RED);
    [ 'Ở mọi trạng thái, kể cả lúc khóa mở / tường xoay khi người đang', 'ở trong, mọi ô đi tới được đều có đường về cổng (test tự động).',
      'Ngoài đời: tường xoay chạy chậm (≥ 4 s/90°), có cảm biến kẹt và', 'đèn báo; mọi tường trượt, tường xoay, cửa một chiều có nút nhả',
      'khẩn cấp, mở tay được từ phía nhân viên; mất điện thì tự nhả.', 'Lối thoát hiểm PCCC riêng, không ẩn. Gương dùng mica, không kính.',
    ].forEach((s, i) => text(x0, 1512 + i * 33, s, 20, C.text));
    footer();
  } else if (SHEET === 'K-06') {
    frame('Chú thích cơ chế tại chỗ / mã trên mặt bằng ↔ giải thích ngắn bên phải');
    plan({ dimsOn: false, secLabels: false }); gridNames();
    for (const it of ITEMS) {
      const [x, z] = it.at;
      add(`<circle cx="${P(x)}" cy="${Q(z)}" r="16" fill="${C.bg}" stroke="${it.col}" stroke-width="2.5"/>`);
      text(P(x), Q(z) + 5, it.code, 13, it.col, 'text-anchor="middle"');
    }
    const x0 = 1590;
    text(x0, 430, `MÃ / VỊ TRÍ (HÀNG A–${ROWN[GRID.rows - 1]}, CỘT 1–${GRID.cols}) / TÁC DỤNG`, 24, C.cyan);
    const wrap = (s, n) => { const out = []; let cur = ''; for (const w of s.split(' ')) { if ((cur + ' ' + w).trim().length > n) { out.push(cur.trim()); cur = w; } else cur += ' ' + w; } out.push(cur.trim()); return out; };
    const lines = ITEMS.map(it => wrap(it.text, 66)), total = lines.reduce((s, l) => s + l.length, 0);
    const lh = Math.min(24, 1380 / (total + ITEMS.length * 0.4)), fs = Math.min(19, lh - 3);
    let y = 470;
    ITEMS.forEach((it, i) => {
      text(x0, y, it.code, fs + 1, it.col);
      lines[i].forEach((l, j) => text(x0 + 56, y + j * lh, l, fs, C.text));
      y += lines[i].length * lh + lh * 0.4;
    });
    footer();
  } else if (SHEET === 'K-07') {
    frame('Báo cáo thanh tra Julius / đi thử 100 lượt, không biết cốt truyện, không đọc ký hiệu');
    dims(); rect(P(0), Q(0), ROOM_SIZE * S, ROOM_SIZE * S, C.plan);
    const maxH = Math.max(...JR.heat.map(h => h[2]));
    for (const [x, z, h] of JR.heat) { const t = Math.pow(h / maxH, 0.6); cellRect([x, z], `rgb(${Math.round(16 + t * 220)},${Math.round(61 + t * 60)},${Math.round(98 - t * 60)})`); }
    for (const r of ROOMS) rect(P(r[0]), Q(r[1]), (r[2] - r[0]) * S, (r[3] - r[1]) * S, C.room);
    walls(); doors(false); security(false); zoneLabels(false);
    poly(JR.sampleRoute, '#ffffff', 2, 'opacity="0.55"');
    text(P(0), 1868, `Màu ô: số lần Julius đi qua trung bình (đỏ = nhiều nhất, ${maxH.toFixed(1)} lần). Vạch trắng: lượt trung vị (${mmss(JR.sampleTime)}).`, 22, C.cyan);
    const x0 = 1600, P_ = JR.params;
    text(x0, 440, JR.pass ? 'ĐẠT — ĐỘ KHÓ ≥ 9/10' : 'CHƯA ĐẠT', 40, JR.pass ? '#7ee0a8' : RED);
    text(x0, 490, `Mốc: cả 100 lượt (kể cả lượt nhanh nhất) phải ≥ ${mmss(JR.target)}`, 22, C.sub);
    [[`Nhanh nhất`, JR.best], [`p10`, JR.p10], [`Trung vị`, JR.median], [`Chậm nhất`, JR.worst]].forEach(([k, v], i) => { text(x0 + i * 205, 560, k, 20, C.sub); text(x0 + i * 205, 600, mmss(v), 34, C.text); });
    text(x0, 670, 'TRUNG VỊ TỪNG CHẶNG', 24, C.cyan);
    JR.legMed.forEach((v, i) => text(x0, 712 + i * 36, `${LEG[i]}: ${mmss(v)}`, 21, Object.values(STAGE_COL)[i]));
    text(x0, 880, 'GIẢ ĐỊNH VỀ JULIUS', 24, C.cyan);
    [`Đi ${P_.speed} m/s (hành lang tối, đèn pin), nhìn thẳng xa ${P_.los} ô.`, `Dừng ${P_.junction} s ở ngã rẽ mới, ${P_.deadEnd} s ở ngõ cụt, ${P_.blocked} s khi đẩy cửa kẹt.`,
      'Nhớ hết mọi thứ đã thấy; luôn đi tới chỗ chưa khám phá gần nhất.', 'Không biết trước cửa một chiều, tường ẩn, tường xoay; bị gương lừa', 'tới khi đứng sát. Giải đố trong phòng tính 0 s.']
      .forEach((s, i) => text(x0, 920 + i * 32, s, 19, C.text));
    text(x0, 1110, 'LỊCH SỬ NÂNG CẤP (CHẶNG DỄ NHẤT → SỬA GÌ)', 24, C.cyan);
    const R = JR.rounds, shown = R.length > 22 ? [...R.slice(0, 11), null, ...R.slice(-10)] : R;
    shown.forEach((r, i) => {
      const y = 1148 + i * 28;
      if (!r) { text(x0, y, '…', 18, C.sub); return; }
      const ch = r.changes ? (r.reverted ? 'Julius nhanh hơn → bỏ' : `${r.changes.walls} tường, ${r.changes.ow} một chiều, ${r.changes.doors + r.changes.locks + r.changes.shifts} khóa/cửa/xoay`) : 'đạt';
      text(x0, y, `V${r.round}  nhanh nhất ${mmss(r.best)}  dễ: chặng ${r.easyLeg + 1}  → ${ch}`, 18, r.reverted ? C.sub : C.text);
    });
    footer();
  } else if (SHEET === 'K-02') {
    frame('Phối cảnh khối tường / không gian chơi — cùng mặt bằng K-01');
    ZONE_ROWS.forEach(([, name], i) => text(1740, 650 + i * 120, name, 30));
    text(1740, 1560, `${ROOM_SIZE} × ${ROOM_SIZE} m`, 76);
    text(1740, 1620, `${ROOM_SIZE * ROOM_SIZE} m² tổng`, 30, C.cyan);
    text(110, 1890, 'Chiều cao cắt khối 1,2 m chỉ để đọc bố cục; tường thật cao 3,0 m. Tím: tường xoay ở vị trí lúc đầu.', 30);
    text(110, 1960, `${REV} / ${DATE} · Phạm vi: tường, cửa nối và các khu chơi theo cốt truyện.`, 23);
  }
  const sheetEl = document.getElementById('sheet');
  sheetEl.insertAdjacentHTML('beforeend', `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${parts.join('')}</svg>`);
  if (SHEET === 'K-02') await iso(sheetEl);
  window.__done = true;
}

// ---------------- phối cảnh khối (Three.js, chiếu trực giao)
async function iso(sheetEl) {
  const THREE = await import('three');
  const { mergeGeometries } = await import('three/addons/utils/BufferGeometryUtils.js');
  const cw = 1520, ch = 1440, cl = 110, ct = 380, mid = ROOM_SIZE / 2;
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1); renderer.setSize(cw, ch);
  Object.assign(renderer.domElement.style, { left: cl + 'px', top: ct + 'px' });
  sheetEl.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const half = 7.6 * ROOM_SIZE / 10, aspect = cw / ch;
  const cam = new THREE.OrthographicCamera(-half * aspect, half * aspect, half, -half, 0.1, 100);
  cam.position.set(mid - 12, 13, mid + 12); cam.lookAt(mid, 0, mid);
  scene.add(new THREE.HemisphereLight(0xcfe6ff, 0x0a2440, 1.4));
  const sun = new THREE.DirectionalLight(0xffffff, 1.1); sun.position.set(-4, 10, 8); scene.add(sun);
  const HT = 1.2, t = WALL_THICKNESS;
  scene.add(new THREE.Mesh(new THREE.BoxGeometry(ROOM_SIZE, 0.08, ROOM_SIZE).translate(mid, -0.04, mid), new THREE.MeshLambertMaterial({ color: 0x0c355b })));
  const roomMat = new THREE.MeshLambertMaterial({ color: 0x1d5682 });
  for (const r of ROOMS) scene.add(new THREE.Mesh(new THREE.BoxGeometry(r[2] - r[0], 0.02, r[3] - r[1]).translate((r[0] + r[2]) / 2, 0.011, (r[1] + r[3]) / 2), roomMat));
  const box = ([x1, z1, x2, z2]) => { const hz = Math.abs(z1 - z2) < 1e-9; return new THREE.BoxGeometry(hz ? x2 - x1 + t : t, HT, hz ? t : z2 - z1 + t).translate((x1 + x2) / 2, HT / 2, (z1 + z2) / 2); };
  const geos = WALLS.map(box);
  scene.add(new THREE.Mesh(mergeGeometries(geos), new THREE.MeshLambertMaterial({ color: 0x2a6390, transparent: true, opacity: 0.92 })));
  for (const g of geos) scene.add(new THREE.LineSegments(new THREE.EdgesGeometry(g), new THREE.LineBasicMaterial({ color: 0xb8d8ee })));
  for (const s of SHIFTS) scene.add(new THREE.Mesh(box(s.before.map(v => v * CELL)), new THREE.MeshLambertMaterial({ color: 0x8a5ad0 })));
  renderer.render(scene, cam);
  const marks = [];
  for (const [id] of ZONE_ROWS) {
    const [x, z] = LABEL_POS[id];
    const v = new THREE.Vector3(x, 0.05, z).project(cam);
    const px = cl + (v.x + 1) / 2 * cw, py = ct + (1 - v.y) / 2 * ch;
    marks.push(`<circle cx="${px}" cy="${py}" r="26" fill="${C.bg}" stroke="${C.cyan}" stroke-width="2"/><text x="${px}" y="${py + 7}" font-size="19" fill="${C.cyan}" font-family="${FONT}" text-anchor="middle">${String(id).padStart(2, '0')}</text>`);
  }
  sheetEl.insertAdjacentHTML('beforeend', `<svg id="overlay" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${marks.join('')}</svg>`);
}

sheet();
