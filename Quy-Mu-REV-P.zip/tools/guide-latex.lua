local base = 'https://dam-truong.github.io/quy-mu-rev-p/'
function Link(el)
  if not el.target:match('^https?://') and not el.target:match('^#') then
    el.target = base .. el.target
  end
  return el
end
function Header(el)
  if el.level == 1 then return {} end
  el.level = el.level - 1
  return el
end
function CodeBlock(el)
  -- ASCII linework is portable across TeX distributions; preserve all labels.
  el.text = el.text:gsub('─', '-'):gsub('│', '|'):gsub('●', 'O')
  return el
end
function Code(el)
  if #el.text == 64 and el.text:match('^[0-9a-f]+$') then
    return pandoc.RawInline('latex', '\\nolinkurl{' .. el.text .. '}')
  end
end
function Table(el)
  local n = #el.colspecs
  local label = pandoc.utils.stringify(el.head.rows[1].cells[1].contents)
  local widths
  if n == 2 then widths = {0.30, 0.70}
  elseif n == 3 then widths = {0.23, 0.18, 0.59}
  elseif n == 7 then widths = {0.06, 0.22, 0.08, 0.08, 0.16, 0.16, 0.24}
  elseif n == 5 then widths = {0.07, 0.10, 0.19, 0.32, 0.32}
  elseif n == 4 then
    local header = pandoc.utils.stringify(el.head)
    if header:match('Chiều dài tim') then widths = {0.08, 0.46, 0.15, 0.31}
    elseif header:match('Đi từ ô') then widths = {0.10, 0.14, 0.14, 0.62}
    elseif header:match('Hai ô') then widths = {0.08, 0.19, 0.46, 0.27}
    else widths = {0.10, 0.29, 0.22, 0.39} end
  end
  if widths then for i=1,n do el.colspecs[i] = {pandoc.AlignLeft, widths[i]} end end
  return el
end
