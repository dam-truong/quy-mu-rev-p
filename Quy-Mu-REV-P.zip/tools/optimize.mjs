import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as C from './core.mjs';
import * as L from '../src/baseline-N.js';
const root=new URL('../',import.meta.url);
const n=C.CORR.length;
const ids=C.CORR.map(c=>c.join(','));
const dirs=C.CORR.map(([x,z])=>C.CORR.map(([a,b])=>a>x?1:a<x?3:b>z?2:0));
const permutations=a=>a.length?a.flatMap((v,i)=>permutations(a.filter((_,j)=>j!==i)).map(p=>[v,...p])):[[]];
export const ranks=[[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2],...permutations([0,1,2,3]).filter(p=>![[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2]].some(q=>q.join()===p.join()))];
export function baseline(){
 const st=new Int8Array(C.EDGES.length).fill(1);
 for(let e=0;e<C.EDGES.length;e++){
  const seg=C.segOf(e).map(v=>v*C.CELL),[x,z,a,b]=seg;
  if(L.WALLS.some(([u,v,w,t])=>Math.abs(x-a)<1e-5?Math.abs(u-w)<1e-5&&Math.abs(u-x)<1e-3&&z>=v-1e-3&&b<=t+1e-3:Math.abs(v-t)<1e-5&&Math.abs(v-z)<1e-3&&x>=u-1e-3&&a<=w+1e-3))st[e]=0;
 }
 for(const o of L.ONEWAY){const e=C.EIDX.get([o.from.join(','),o.to.join(',')].sort().join('|'));st[e]=ids[C.EDGES[e][0]]===o.from.join(',')?2:3;}
 const locks=L.LOCKS.map(o=>C.EIDX.get([o.a.join(','),o.b.join(',')].sort().join('|')));
 const shifts=L.SHIFTS.map(o=>C.SHIFT_OPTS.findIndex(p=>p.post.join()===o.post.join()&&C.segOf(p.e1).join()===o.before.join()&&C.segOf(p.e2).join()===o.after.join()));
 const doors=Object.fromEntries(C.ORDER.map(k=>{const d=L.DOORS.find(d=>d.id===L.MAZE.roomDoors[k]);return[k,C.CANDIDATES[k].find(a=>Math.hypot(a.x-d.x,a.z-d.z)<.001)];}));
 const cfg={st,doors,locks,shifts};assert.ok(C.check(cfg));return cfg;
}
export function simulate(cfg,rankIndex=0,preparedGraphs=null){
 const rank=ranks[rankIndex],rr=Array(4);rank.forEach((v,i)=>rr[v]=i);
 const graphs=preparedGraphs??[0,1,2,3].map(s=>C.adjOf(cfg,s));
 const targets=[...C.ORDER.map(k=>cfg.doors[k].cell),C.EX];
 const known=Array.from({length:n},()=>[]),observed=new Uint8Array(n),confirmed=new Int8Array(n).fill(-1),remembered=new Uint8Array(4);
 let current=C.G,phase=0,steps=0,last=0;const legs=[];
 const route=(pred)=>{const prev=new Int16Array(n).fill(-2),q=[current];prev[current]=-1;
  for(let i=0;i<q.length;i++){const u=q[i];if(pred(u)){let v=u;if(v===current)return current;while(prev[v]!==current)v=prev[v];return v;}
   for(const v of known[u])if(prev[v]===-2){prev[v]=u;q.push(v);}}
  return -1;};
 while(phase<4&&steps<10000){
  const ns=graphs[phase][current];
  for(let t=0;t<4;t++)if((t!==3||phase===3)&&(targets[t]===current||ns.includes(targets[t])))remembered[t]=1;
  known[current]=ns.slice().sort((a,b)=>rr[dirs[current][a]]-rr[dirs[current][b]]);
  observed[current]=1;confirmed[current]=phase;
  if(current===targets[phase]){legs.push(steps-last);last=steps;phase++;continue;}
  let next=remembered[phase]?route(u=>u===targets[phase]):-1;
  if(next<0)next=route(u=>!observed[u]);
  if(next<0)next=route(u=>confirmed[u]!==phase);
  if(next<0||next===current||!ns.includes(next))return {steps:0,legs:[],error:true};
  current=next;steps++;
 }
 return {steps:phase===4?steps:0,legs,error:phase!==4};
}
export const serialize=cfg=>({...cfg,st:[...cfg.st]});
export const restore=obj=>({...obj,st:Int8Array.from(obj.st)});
// Search entry points: search-local.mjs and refine-local.mjs.
