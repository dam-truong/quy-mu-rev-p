import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as C from './core.mjs';
import {simulate,serialize,restore} from './optimize.mjs';
const root=new URL('../',import.meta.url),settings=JSON.parse(fs.readFileSync(new URL('config.json',root)));
const baseline=restore(JSON.parse(fs.readFileSync(new URL('baseline/config-O.json',root))).cfg);
const emergency=JSON.parse(fs.readFileSync(new URL('baseline/emergency-O.json',root)));
const emergencyEdges=emergency.panels.map(p=>C.EIDX.get([p.a.join(','),p.b.join(',')].sort().join('|')));
const countOW=c=>[...c.st].filter(t=>t>=2).length,cap=countOW(baseline);
const special=c=>new Set([...c.locks,...c.shifts.flatMap(i=>[C.SHIFT_OPTS[i].e1,C.SHIFT_OPTS[i].e2])]);
const distance=([x,z])=>Math.max(4-x,0,x-7)+Math.max(5-z,0,z-8);
const ringOf=C.EDGES.map(([a,b])=>Math.max(distance(C.CORR[a]),distance(C.CORR[b])));
const threeWalls=[5,6,7].map(x=>C.EDGES.findIndex((_,e)=>C.segOf(e).join(',')===[x,6,x,7].join(',')));
const shape=c=>({removed:threeWalls.filter(e=>c.st[e]!==0).length,added:C.EDGES.filter((_,e)=>ringOf[e]===0&&C.segOf(e)[1]===C.segOf(e)[3]&&baseline.st[e]!==0&&c.st[e]===0).length});
const redesigned=c=>{const s=shape(c);return s.removed>=2&&s.added>=1;};
function emergencyOK(c){for(let s=0;s<3;s++){
 const closed=new Set([...C.closedAt(c,s),...C.closedAt(c,s+1)]),adj=C.CORR.map(()=>[]);
 C.EDGES.forEach(([a,b],e)=>{if((c.st[e]&&!closed.has(e))||emergencyEdges.includes(e)){adj[a].push(b);adj[b].push(a);}});
 const seen=new Set([C.G]),q=[C.G];for(let i=0;i<q.length;i++)for(const v of adj[q[i]])if(!seen.has(v)){seen.add(v);q.push(v);}
 const old=C.adjOf(c,s),prev=new Set([C.G]),p=[C.G];for(let i=0;i<p.length;i++)for(const v of old[p[i]])if(!prev.has(v)){prev.add(v);p.push(v);}
 if([...prev].some(v=>!seen.has(v)))return false;
 }return true;}
export function evaluate(c){const graphs=[0,1,2,3].map(s=>C.adjOf(c,s));const values=Array.from({length:24},(_,i)=>simulate(c,i,graphs).steps);const min=Math.min(...values),mean=values.reduce((a,b)=>a+b)/24,s=shape(c);return {values,min,mean,score:min+.035*mean+40*Math.min(s.removed,2)+40*Math.min(s.added,1),minSeconds:min*C.CELL/settings.speedMetersPerSecond,shape:s};}
const diff=c=>[...c.st].flatMap((v,e)=>v!==baseline.st[e]?[e]:[]);
const rng=C.mulberry32(settings.searchSeed),pick=a=>a[Math.floor(rng()*a.length)];
let best=baseline,be=evaluate(best);assert.ok(C.check(best));assert.ok(emergencyOK(best));
let foundRedesign=false;
assert.equal(be.min,803,'Optimizer must reproduce REV O independent result');
const summary={settings,baseline:be,oneWayDoors:cap,rotatingWalls:baseline.shifts.length,emergencyPanels:emergency.panels.length,coreCellBounds:[4,5,8,9],rings:[],method:'Seeded simulated annealing; expand by Manhattan cell rings, fixed room doors, unchanged counts and fixed emergency panel. Finite heuristic search, not an infeasibility proof.'};
const save=(ring,it)=>{fs.writeFileSync(new URL('iterations/final-selected.json',root),JSON.stringify({seed:settings.searchSeed,ring,iteration:it,cfg:serialize(best),evaluation:be,changedEdges:diff(best),changedCells:[...new Set(diff(best).flatMap(e=>C.cellsOf(e).map(c=>c.join(','))))]},null,2));fs.writeFileSync(new URL('iterations/search-report.json',root),JSON.stringify(summary,null,2));};
save(-1,0);console.log(JSON.stringify({baseline:be.minSeconds,cap}));
const start=Date.now();
for(let ring=0;ring<=settings.maxRing;ring++){
 const allowed=C.EDGES.map((_,i)=>i).filter(e=>ringOf[e]<=ring&&!emergencyEdges.includes(e)),allowedSet=new Set(allowed);
 const movableShifts=baseline.shifts.map((o,i)=>({o,i})).filter(({o})=>[C.SHIFT_OPTS[o].e1,C.SHIFT_OPTS[o].e2].every(e=>allowedSet.has(e))).map(({i})=>i);
 const shiftOptions=C.SHIFT_OPTS.map((_,i)=>i).filter(i=>[C.SHIFT_OPTS[i].e1,C.SHIFT_OPTS[i].e2].every(e=>allowedSet.has(e)));
 const movableLocks=baseline.locks.map((e,i)=>({e,i})).filter(({e})=>allowedSet.has(e)).map(({i})=>i);
 let cur=best,ev=be,valid=0,evaluated=0;const before=be.minSeconds,ringStart=Date.now();
 const cache=new Map();
 const budgetSeconds=ring<3?40:90;
 const info={ring,allowedEdges:allowed.length,allowedCells:C.CORR.filter(c=>distance(c)<=ring).length,iterations:0,valid:0,evaluated:0,startMinimumSeconds:before,bestMinimumSeconds:before,budgetSeconds};summary.rings.push(info);
 for(let it=1;it<=settings.iterationsPerRing;it++){
  info.iterations=it;if((Date.now()-ringStart)/1000>budgetSeconds)break;
  const c={...cur,st:cur.st.slice(),locks:cur.locks.slice(),shifts:cur.shifts.slice()},sp=special(c),r=rng(),a=pick(allowed),b=pick(allowed);
  if(r<.55){if(sp.has(a)||sp.has(b))continue;[c.st[a],c.st[b]]=[c.st[b],c.st[a]];if(c.st[a]>=2&&rng()<.4)c.st[a]=5-c.st[a];}
  else if(r<.75){if(sp.has(a))continue;c.st[a]=c.st[a]>=2?5-c.st[a]:1-c.st[a];}
  else if(r<.84&&movableLocks.length){const i=pick(movableLocks);if(sp.has(a)||c.st[a]!==1)continue;c.locks[i]=a;}
  else if(movableShifts.length){const i=pick(movableShifts),o=pick(shiftOptions),p=C.SHIFT_OPTS[o],old=C.SHIFT_OPTS[c.shifts[i]];sp.delete(old.e1);sp.delete(old.e2);if(sp.has(p.e1)||sp.has(p.e2)||c.st[p.e1]>1||c.st[p.e2]>1)continue;c.shifts[i]=o;c.st[p.e1]=c.st[p.e2]=1;if(rng()<.5&&!special(c).has(old.e1))c.st[old.e1]=0;}
  else continue;
  if(countOW(c)!==cap||!C.check(c)||!emergencyOK(c))continue;valid++;
  const key=[...c.st,...c.locks,...c.shifts].join(',');let v=cache.get(key);if(!v){v=evaluate(c);cache.set(key,v);evaluated++;}if(!v.min)continue;
  const cycle=it%10000,T=1+30*(1-cycle/10000);
  if(v.score>=ev.score||rng()<Math.exp((v.score-ev.score)/T)){cur=c;ev=v;}
  if(redesigned(c)&&(!foundRedesign||v.min>be.min||(v.min===be.min&&v.mean>be.mean))){foundRedesign=true;best=c;be=v;info.bestMinimumSeconds=be.minSeconds;save(ring,it);console.log(JSON.stringify({ring,it,minSeconds:be.minSeconds,changedEdges:diff(best).length,shape:shape(best),elapsed:Math.round((Date.now()-start)/1000)}));}
  if(it%10000===0){cur=best;ev=be;}
  info.iterations=it;info.valid=valid;info.evaluated=evaluated;
  if(be.minSeconds>=settings.thresholdSeconds)break;
 }
 info.elapsedSeconds=(Date.now()-ringStart)/1000;info.bestMinimumSeconds=be.minSeconds;save(ring,info.iterations);console.log(JSON.stringify({ringComplete:info}));
 if(be.minSeconds>=settings.thresholdSeconds)break;
}
summary.status=be.minSeconds>=settings.thresholdSeconds?'CANDIDATE_REQUIRES_INDEPENDENT_AUDIT':'BEST_FOUND_BELOW_TARGET';summary.redesigned=foundRedesign;summary.shape=shape(best);summary.shortfallSeconds=Math.max(0,settings.thresholdSeconds-be.minSeconds);summary.elapsedSeconds=(Date.now()-start)/1000;save(summary.rings.at(-1).ring,summary.rings.at(-1).iterations);
