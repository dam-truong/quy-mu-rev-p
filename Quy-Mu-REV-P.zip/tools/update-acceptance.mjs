import fs from 'node:fs';
const root=new URL('../',import.meta.url),edit=(p,f)=>{const u=new URL(p,root);fs.writeFileSync(u,f(fs.readFileSync(u,'utf8')));};
edit('tools/finish-artifacts.mjs',s=>s.replace("passed?'ĐẠT NGƯỠNG MÔ PHỎNG 900 GIÂY':'BẢN THỬ — CHƯA ĐẠT 900 GIÂY'","passed?'ĐẠT NGƯỠNG MÔ PHỎNG '+r.thresholdSeconds+' GIÂY':'BẢN THỬ — CHƯA ĐẠT '+r.thresholdSeconds+' GIÂY'").replaceAll('Cloudflare','GitHub Pages'));
edit('viewer-template.html',s=>s.replace('Mục tiêu 15 phút','Mốc /*THRESHOLD_MINUTES*/ phút'));
edit('viewer-template.html',s=>s.includes('Quy-Mu-REV-P.zip')?s:s.replace('<h3>Xuất mô hình</h3>','<h3>Xuất mô hình</h3><p><a href="Quy-Mu-REV-P.zip" download>Tải toàn bộ REV P (.zip)</a></p>'));
edit('tools/build-render.mjs',s=>s.replace(".replace('/*BUNDLE*/'",".replace('/*THRESHOLD_MINUTES*/',String(report.thresholdSeconds/60)).replace('/*BUNDLE*/'"));
console.log('All presentation thresholds now derive from the independent audit report.');
