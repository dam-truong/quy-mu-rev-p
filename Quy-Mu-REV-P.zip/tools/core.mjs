// Sinh mê cung Quỷ Mù (REV N) và ghi thẳng src/layout.js.
// Chạy: node quy-mu-3d/tools/gen-maze.mjs [seed]
//
// Bố cục: sàn 11 × 11 m. Lưới 12 × 12 ô vuông CELL = 11/12 ≈ 0,917 m (>= 0,9 m để đi thoải mái; hành lang thông thủy ≈ 0,76 m).
//   Làng 9 × 3 ô (8,25 × 2,75 m — gần nhất với 8 × 2,5 m mà vẫn khớp lưới) ở góc dưới bên trái; phòng Người canh ấn
//   3 × 3 ô (2,75 × 2,75 m) ở góc dưới bên phải, sát Làng (không cửa thông), cửa mở lên mê cung. Cổng mê cung C02 trên tường trên của Làng, cửa vào Làng C01 ở tường trái.
//   Tế thần (5 × 3 ô) và Giam Vọng Âm (4 × 2 ô) dính nhau áp tường trên; chỗ dưới Giam (trước là phòng Người canh) giờ là
//   mê cung. Mê cung bao 3 phía cụm trên và chạy xuống tận cửa phòng Người canh. Cửa thoát C06 ở góc trên bên phải.
//   (Đã thử cụm ở giữa phòng: dải hành lang quanh cụm chỉ rộng 2 ô nên ra hành lang thẳng, Julius nhanh hơn ~3 phút.)
//
// Cách sinh:
//   1. Nền là mê cung hoàn hảo kiểu "growing tree" (80% nhánh mới nhất): hành lang dài, rẽ liên tục, nhánh cụt sâu — như mẫu.
//   2. Đặt cửa phòng, khóa tuần tự L1 / L2, 2 tường xoay X1 / X2 sao cho hợp lệ.
//   3. Thanh tra Julius (tools/julius.mjs) đi thử 100 lượt. Cả 100 lượt (kể cả lượt nhanh nhất) phải >= 15 phút mới đạt.
//      Chưa đạt: đọc log của Julius, tìm chặng hắn đi nhanh nhất và các ô hắn đi qua ở chặng đó, rồi sửa tường / thêm cửa
//      một chiều / dời khóa, tường xoay, cửa phòng tập trung ở khúc đó (hill climbing có mục tiêu là thời gian của Julius).
//      Lặp lại tới khi đạt. Lịch sử từng vòng ghi vào JULIUS_REPORT trong layout.js và log mẫu vào julius-log.txt.
// Luật cứng: mọi ô đi tới được (kể cả lúc khóa mở / tường xoay khi người đang ở trong) luôn có đường về cổng;
// chưa xong phòng trước thì không có đường tới phòng sau; mọi ô hành lang đều dùng tới; không có khoảng sân 2 × 2.
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { runJulius, juliusStats, LOOK, JULIUS, mmss } from './julius.mjs';

const SIZE = 11, COLS = 12, ROWS = 12, CELL = SIZE / COLS;
const VILLAGE = [0, 9, 9, 12], GZ = VILLAGE[1] * CELL;          // Làng (ô); GZ: tường cổng giữa mê cung và Làng (mét)
const ROOM_BOX = { te: [2, 0, 7, 3], giam: [7, 0, 11, 2], canh: [9, 9, 12, 12] }; // ô [x1, z1, x2, z2), x2/z2 không gồm
const ORDER = ['giam', 'canh', 'te'];
const ROOM_DOOR = { giam: { id: 'C03', kind: 'bars' }, canh: { id: 'C04', kind: 'sealed' }, te: { id: 'C05', kind: 'gate' } };
const LOCK_DEFS = [{ id: 'L1', after: 'giam', room: 'canh', kind: 'hidden' }, { id: 'L2', after: 'canh', room: 'te', kind: 'hidden' }];
const GATE = [4, 8], EXIT = [11, 0], C01_CELL = [0, 10];
const TARGET = Number(process.env.TARGET || 900);          // giây: lượt Julius nhanh nhất phải vượt mốc này
const MAX_ROUNDS = Number(process.env.ROUNDS || 60), ITERS = Number(process.env.ITERS || 800);
const MAX_OW = 40, MAX_LOOPS = 16, EVAL_RUNS = 20;
const SYMS = ['gieng', 'lua', 'kho', 'mieu'];

const key = (x, z) => `${x},${z}`;
const K = c => key(...c);
const DIRV = [[0, -1], [1, 0], [0, 1], [-1, 0]];                // B, Đ, N, T
const inBox = (x, z, [a, b, c, d]) => x >= a && x < c && z >= b && z < d;
const roomOfCell = (x, z) => ORDER.find(k => inBox(x, z, ROOM_BOX[k])) || (inBox(x, z, VILLAGE) ? 'lang' : undefined);
const isCorr = (x, z) => x >= 0 && z >= 0 && x < COLS && z < ROWS && !roomOfCell(x, z);
const CORR = []; for (let z = 0; z < ROWS; z++) for (let x = 0; x < COLS; x++) if (isCorr(x, z)) CORR.push([x, z]);
const CI = new Map(CORR.map((c, i) => [K(c), i]));
const edgeKey = (a, b) => [K(a), K(b)].sort().join('|');
const NB = new Int16Array(CORR.length * 4).fill(-1);
CORR.forEach(([x, z], i) => DIRV.forEach(([dx, dz], d) => { const j = CI.get(key(x + dx, z + dz)); if (j !== undefined) NB[i * 4 + d] = j; }));
const EDGES = [], EIDX = new Map();
for (const [x, z] of CORR) for (const [dx, dz] of [[1, 0], [0, 1]]) {
  const n = [x + dx, z + dz]; if (!isCorr(...n)) continue;
  EIDX.set(edgeKey([x, z], n), EDGES.length); EDGES.push([CI.get(key(x, z)), CI.get(K(n))]);
}
const edgeOf = (i, d) => EIDX.get(edgeKey(CORR[i], CORR[NB[i * 4 + d]]));
const cellsOf = e => EDGES[e].map(i => CORR[i]);
const segOf = e => { const [a, b] = cellsOf(e); return a[0] !== b[0] ? [b[0], a[1], b[0], a[1] + 1] : [a[0], b[1], a[0] + 1, b[1]]; };
const G = CI.get(K(GATE)), EX = CI.get(K(EXIT));
const segEdge = new Map(EDGES.map((_, e) => [segOf(e).join(','), e]));
const SHIFT_OPTS = [];
for (let vx = 1; vx < COLS; vx++) for (let vz = 1; vz < ROWS; vz++) {
  const vert = [[vx, vz - 1, vx, vz], [vx, vz, vx, vz + 1]].map(s => segEdge.get(s.join(',')));
  const hor = [[vx - 1, vz, vx, vz], [vx, vz, vx + 1, vz]].map(s => segEdge.get(s.join(',')));
  for (const e1 of vert) for (const e2 of hor) if (e1 !== undefined && e2 !== undefined) SHIFT_OPTS.push({ post: [vx, vz], e1, e2 }, { post: [vx, vz], e1: e2, e2: e1 });
}
const BLOCKS = [];
for (let z = 0; z < ROWS - 1; z++) for (let x = 0; x < COLS - 1; x++) {
  const c = [[x, z], [x + 1, z], [x, z + 1], [x + 1, z + 1]]; if (!c.every(p => isCorr(...p))) continue;
  BLOCKS.push([[c[0], c[1]], [c[0], c[2]], [c[1], c[3]], [c[2], c[3]]].map(([p, q]) => EIDX.get(edgeKey(p, q))));
}
// cửa phòng có thể đặt: mặt d của ô hành lang i giáp phòng k. Tọa độ cửa tính bằng mét.
const CANDIDATES = Object.fromEntries(ORDER.map(k => [k, []]));
CORR.forEach(([x, z], i) => DIRV.forEach(([dx, dz], d) => {
  const k = roomOfCell(x + dx, z + dz); if (!k || k === 'lang') return;
  const door = d === 1 ? { x: (x + 1) * CELL, z: (z + 0.5) * CELL, axis: 'z' } : d === 3 ? { x: x * CELL, z: (z + 0.5) * CELL, axis: 'z' }
    : d === 2 ? { x: (x + 0.5) * CELL, z: (z + 1) * CELL, axis: 'x' } : { x: (x + 0.5) * CELL, z: z * CELL, axis: 'x' };
  CANDIDATES[k].push({ ...door, cell: i, dir: d, swing: d === 3 || d === 0 ? 1 : -1 });
}));

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- đồ thị theo giai đoạn
const specialsOf = cfg => [...cfg.locks, ...cfg.shifts.flatMap(o => [SHIFT_OPTS[o].e1, SHIFT_OPTS[o].e2])];
const SHIFT_AT = [1, 1, 2, 2];      // X1, X2 xoay khi mở L1 (vào s1); X3, X4 khi mở L2 (vào s2)
function closedAt(cfg, s) {        // s = 0..3
  const c = new Set();
  if (s < 1) c.add(cfg.locks[0]);
  if (s < 2) c.add(cfg.locks[1]);
  cfg.shifts.forEach((o, i) => c.add(s < SHIFT_AT[i] ? SHIFT_OPTS[o].e1 : SHIFT_OPTS[o].e2));
  return c;
}
function adjOf(cfg, s) {
  const closed = closedAt(cfg, s), adj = CORR.map(() => []);
  EDGES.forEach(([a, b], e) => { const t = cfg.st[e]; if (!t || closed.has(e)) return; if (t !== 3) adj[a].push(b); if (t !== 2) adj[b].push(a); });
  return adj;
}
const reverseAdj = adj => { const r = CORR.map(() => []); adj.forEach((ns, c) => ns.forEach(n => r[n].push(c))); return r; };
function bfsFrom(adj, srcs) {
  const seen = new Uint8Array(CORR.length), q = [...srcs];
  for (const s of srcs) seen[s] = 1;
  while (q.length) { const c = q.pop(); for (const n of adj[c]) if (!seen[n]) { seen[n] = 1; q.push(n); } }
  return seen;
}
function shortest(adj, src, dst) {
  const prev = new Int16Array(CORR.length).fill(-2), q = [src]; prev[src] = -1;
  for (let i = 0; i < q.length; i++) for (const n of adj[q[i]]) if (prev[n] === -2) { prev[n] = q[i]; q.push(n); }
  if (prev[dst] === -2) return null;
  const p = []; for (let c = dst; c >= 0; c = prev[c]) p.unshift(c);
  return p;
}
const idxs = mask => { const r = []; for (let i = 0; i < mask.length; i++) if (mask[i]) r.push(i); return r; };

function check(cfg) {
  const T = Object.fromEntries(ORDER.map(k => [k, cfg.doors[k].cell]));
  if (new Set([T.giam, T.canh, T.te, G]).size !== 4) return null;
  const sp = specialsOf(cfg);
  if (new Set(sp).size !== sp.length || sp.some(e => cfg.st[e] !== 1)) return null;
  let ow = 0, open = 0; for (const t of cfg.st) { if (t >= 2) ow++; if (t) open++; }
  if (ow > MAX_OW || open - cfg.shifts.length - (CORR.length - 1) > MAX_LOOPS) return null;
  for (const b of BLOCKS) if (b.every(e => cfg.st[e])) return null;
  if (straightPenalty(cfg, true) > MAX_STRAIGHT) return null;
  const adj = [0, 1, 2].map(s => adjOf(cfg, s));
  const R = [];
  for (let s = 0; s < 3; s++) {
    const r = bfsFrom(adj[s], s ? idxs(R[s - 1]) : [G]);
    const back = bfsFrom(reverseAdj(adj[s]), [G]);
    for (let i = 0; i < r.length; i++) if (r[i] && !back[i]) return null;    // chống kẹt
    R.push(r);
  }
  if (!R[0][T.giam] || R[0][T.canh] || R[0][T.te] || !R[1][T.canh] || R[1][T.te] || !R[2][T.te] || !R[2][EX]) return null;
  if (!R[2].every(v => v)) return null;
  const from = [G, T.giam, T.canh, T.te], to = [T.giam, T.canh, T.te, EX];
  for (let l = 0; l < 3; l++) if (!shortest(adj[l], G, to[l])) return null;
  const paths = from.map((f, l) => shortest(adj[Math.min(l, 2)], f, to[l]));
  if (paths.some(p => !p)) return null;
  return { adj, R, T, from, to, paths, lens: paths.map(p => p.length - 1) };
}

// gương mica: ô cụt (1 mặt mở) đi vào bằng đoạn thẳng >= 2 ô, không phải cổng / cửa thoát / ô trước cửa phòng.
// Gương dán ở mặt tường cuối, đối diện lối vào. Trả về [ô, hướng tới tường gương], tối đa 8.
function mirrorsOf(cfg) {
  const keep = new Set([G, EX, ...ORDER.map(k => cfg.doors[k].cell)]), out = [];
  for (let i = 0; i < CORR.length && out.length < 8; i++) {
    if (keep.has(i)) continue;
    const open = [0, 1, 2, 3].filter(d => NB[i * 4 + d] >= 0 && cfg.st[edgeOf(i, d)]);
    if (open.length !== 1) continue;
    const back = open[0], far = (back + 2) % 4, p = NB[i * 4 + back];
    if (NB[p * 4 + back] < 0 || !cfg.st[edgeOf(p, back)]) continue;   // ô trước đó cũng thẳng hàng
    out.push([i, far]);
  }
  return out;
}

// ---- mê cung cho Julius: hình dạng và khả năng đi qua từng mặt ô theo giai đoạn
const cellName = i => `${'ABCDEFGHIJKL'[CORR[i][1]]}${CORR[i][0] + 1}`;
function mazeFor(cfg) {
  const n = CORR.length, look = [], pass = [];
  const doorAt = new Map(ORDER.map(k => [cfg.doors[k].cell * 4 + cfg.doors[k].dir, k]));
  for (let s = 0; s < 4; s++) {
    const closed = closedAt(cfg, Math.min(s, 3)), lk = new Uint8Array(n * 4), ps = new Uint8Array(n * 4);
    for (let i = 0; i < n; i++) for (let d = 0; d < 4; d++) {
      const j = i * 4 + d, m = NB[j];
      if (m >= 0) {
        const e = edgeOf(i, d), t = cfg.st[e];
        if (!t) lk[j] = LOOK.WALL;
        else if (closed.has(e)) lk[j] = LOOK.WALL;               // L1, L2 và tường xoay đóng đều trông như tường đá
        else { lk[j] = LOOK.OPEN; ps[j] = t === 1 || (t === 2 ? EDGES[e][0] === i : EDGES[e][1] === i) ? 1 : 0; }
      } else if (doorAt.has(j)) lk[j] = LOOK.ROOM;
      else if (i === EX && d === 1) { lk[j] = s === 3 ? LOOK.EXIT : LOOK.WALL; ps[j] = s === 3 ? 1 : 0; } // cửa thoát ẩn tới khi xong Tế
      else lk[j] = LOOK.WALL;
    }
    look.push(lk); pass.push(ps);
  }
  const roomAt = new Array(n).fill(null); for (const k of ORDER) roomAt[cfg.doors[k].cell] = k;
  const mirror = new Uint8Array(n * 4); for (const [i, d] of mirrorsOf(cfg)) mirror[i * 4 + d] = 1;
  return { n, nb: NB, look, pass, mirror, gate: G, exit: EX, exitDir: 1, roomAt, order: ORDER, cell: CELL, name: cellName,
    rooms: Object.fromEntries(ORDER.map(k => [k, { cell: cfg.doors[k].cell, dir: cfg.doors[k].dir }])) };
}

// hành lang thẳng dài = dễ nhìn xuyên, không ngoằn ngoèo -> phạt đoạn thẳng >= 4 ô (maxRun: đoạn dài nhất)
function straightPenalty(cfg, maxRun = false) {
  let p = 0, best = 0;
  for (const d of [1, 2]) for (let i = 0; i < CORR.length; i++) {
    const back = NB[i * 4 + (d + 2) % 4]; if (back >= 0 && cfg.st[edgeOf(i, (d + 2) % 4)]) continue;
    let run = 1, c = i, hot = inBox(...CORR[i], HOT_BOX); while (NB[c * 4 + d] >= 0 && cfg.st[edgeOf(c, d)]) { run++; c = NB[c * 4 + d]; hot ||= inBox(...CORR[c], HOT_BOX); }
    if (run >= 4) p += run - 3;
    best = Math.max(best, run > HOT_MAX && hot ? Infinity : run);   // vùng siêu khó: đoạn thẳng chạm vùng không quá HOT_MAX ô
  }
  return maxRun ? best : p;
}
// chỗ cũ của phòng Người canh (dưới Giam): mê cung siêu khó, đoạn thẳng nào chạm vùng này dài tối đa 2 ô
const HOT_BOX = [7, 2, 11, 4], HOT_MAX = 2;
const MAX_STRAIGHT = Number(process.env.MAX_STRAIGHT || 7);    // cấm hành lang thẳng dài hơn 7 ô (~6,4 m)
// điểm = trung bình 4 lượt nhanh nhất trong EVAL_RUNS lượt Julius (phút) — tối ưu cho người giỏi nhất, không phải trung bình
function score(cfg) {
  const mz = mazeFor(cfg), times = [];
  for (let r = 0; r < EVAL_RUNS; r++) times.push(runJulius(mz, 7 + r).time);
  times.sort((a, b) => a - b);
  return (times[0] + times[1] + times[2] + times[3]) / 240 - 0.3 * straightPenalty(cfg);
}

function perfectMaze(rnd) {
  const st = new Int8Array(EDGES.length), inT = new Uint8Array(CORR.length), act = [G]; inT[G] = 1;
  while (act.length) {
    const idx = rnd() < 0.8 ? act.length - 1 : Math.floor(rnd() * act.length), c = act[idx];
    const opts = [0, 1, 2, 3].map(d => NB[c * 4 + d]).filter(m => m >= 0 && !inT[m]);
    if (!opts.length) { act.splice(idx, 1); continue; }
    const m = opts[Math.floor(rnd() * opts.length)]; st[EIDX.get(edgeKey(CORR[c], CORR[m]))] = 1; inT[m] = 1; act.push(m);
  }
  return st;
}
function initial(seed) {
  const rnd = mulberry32(seed), pick = a => a[Math.floor(rnd() * a.length)];
  for (let tries = 0; tries < 400; tries++) {
    const st = perfectMaze(rnd), doors = Object.fromEntries(ORDER.map(k => [k, pick(CANDIDATES[k])]));
    const base = { st, doors, locks: [], shifts: [] }, adj = adjOf({ ...base, locks: [-1, -1], shifts: [] }, 3);
    const pe = k => { const p = shortest(adj, G, doors[k].cell); return new Set(p.slice(1).map((c, i) => EIDX.get(edgeKey(CORR[p[i]], CORR[c])))); };
    const [pg, pc, pt] = ORDER.map(pe);
    const l1 = [...pc].filter(e => !pg.has(e)), l2 = [...pt].filter(e => !pg.has(e) && !pc.has(e));
    if (!l1.length || !l2.length) continue;
    const locks = [pick(l1), pick(l2)];
    for (let t = 0; t < 300; t++) {
      const shifts = SHIFT_AT.map(() => Math.floor(rnd() * SHIFT_OPTS.length));
      if (shifts.some(o => st[SHIFT_OPTS[o].e1] !== 0 || st[SHIFT_OPTS[o].e2] !== 1)) continue;
      const cfg = { st: st.slice(), doors: { ...doors }, locks: locks.slice(), shifts };
      for (const o of shifts) cfg.st[SHIFT_OPTS[o].e1] = 1;
      if (check(cfg)) return cfg;
    }
  }
  return null;
}

// khúc dễ: các cạnh quanh những ô Julius đi qua ở chặng hắn đi nhanh nhất, trong các lượt nhanh nhất
function easyFocus(stats) {
  const fast = stats.res.slice().sort((a, b) => a.time - b.time).slice(0, 10);
  const leg = stats.legMed.indexOf(Math.min(...stats.legMed)), w = new Float64Array(EDGES.length);
  for (const r of fast) for (const [s, c] of r.trace) if (s === leg) for (let d = 0; d < 4; d++) if (NB[c * 4 + d] >= 0) w[edgeOf(c, d)] += 1;
  const list = []; let tot = 0; w.forEach((v, e) => { if (v > 0) { tot += v; list.push([e, tot]); } });
  return { leg, pick: rnd => { if (!list.length || rnd() < 0.25) return Math.floor(rnd() * EDGES.length); const x = rnd() * tot; return list.find(([, c]) => c >= x)[0]; }, cells: new Set(fast.flatMap(r => r.trace.filter(([s]) => s === leg).map(([, c]) => c))) };
}
function mutate(cfg, rnd, focus) {
  const c = { st: cfg.st.slice(), doors: { ...cfg.doors }, locks: cfg.locks.slice(), shifts: cfg.shifts.slice() };
  const sp = new Set(specialsOf(c)), r = rnd(), pickN = n => Math.floor(rnd() * n);
  const toggle = e => { if (sp.has(e)) return; const t = c.st[e], q = rnd(); c.st[e] = t === 0 ? (q < 0.7 ? 1 : q < 0.85 ? 2 : 3) : t === 1 ? (q < 0.7 ? 0 : q < 0.85 ? 2 : 3) : (q < 0.4 ? 0 : q < 0.7 ? 1 : 5 - t); };
  if (r < 0.4) { toggle(focus.pick(rnd)); if (rnd() < 0.4) toggle(focus.pick(rnd)); }
  else if (r < 0.65) {                        // nối lại nhánh: đóng một lối, mở một lối khác gần đó (giữ dạng cây)
    const e1 = focus.pick(rnd), e2 = focus.pick(rnd);
    if (!sp.has(e1) && !sp.has(e2) && c.st[e1] && !c.st[e2]) { c.st[e1] = 0; c.st[e2] = 1; }
  } else if (r < 0.75) { const i = pickN(2), e = focus.pick(rnd); if (!sp.has(e)) { c.locks[i] = e; c.st[e] = 1; } }
  else if (r < 0.87) {
    const i = pickN(SHIFT_AT.length), o = pickN(SHIFT_OPTS.length), { e1, e2 } = SHIFT_OPTS[o];
    sp.delete(SHIFT_OPTS[c.shifts[i]].e1); sp.delete(SHIFT_OPTS[c.shifts[i]].e2);
    if (!sp.has(e1) && !sp.has(e2)) { c.shifts[i] = o; c.st[e1] = c.st[e2] = 1; }
  } else { const k = ORDER[pickN(3)], cand = CANDIDATES[k]; c.doors[k] = cand[pickN(cand.length)]; }
  return c;
}
function diffOf(a, b) {
  let walls = 0, ow = 0; a.st.forEach((t, e) => { if (t !== b.st[e]) { if (t >= 2 || b.st[e] >= 2) ow++; else walls++; } });
  const doors = ORDER.filter(k => a.doors[k] !== b.doors[k]).length;
  return { walls, ow, doors, locks: a.locks.filter((e, i) => e !== b.locks[i]).length, shifts: a.shifts.filter((o, i) => o !== b.shifts[i]).length };
}


export {SIZE,COLS,ROWS,CELL,VILLAGE,ROOM_BOX,ORDER,GATE,EXIT,CORR,CI,EDGES,EIDX,NB,G,EX,SHIFT_OPTS,SHIFT_AT,CANDIDATES,check,adjOf,closedAt,mutate,mulberry32,shortest,straightPenalty,initial,mazeFor,segOf,cellsOf};
