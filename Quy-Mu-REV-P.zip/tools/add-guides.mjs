import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as L from '../src/layout.js';
import {buildEnvironment} from '../julius/audit-layout.mjs';
const root=new URL('../',import.meta.url),env=buildEnvironment(L),syms=['gieng','lua','kho','mieu'];
const guides=env.graphs.map((g,phase)=>{const start=env.starts[phase],end=env.targets[phase],prev=new Map([[start,null]]),q=[start];for(let i=0;i<q.length;i++)for(const n of g.get(q[i]))if(!prev.has(n)){prev.set(n,q[i]);q.push(n);}const route=[];for(let k=end;k!==null;k=prev.get(k))route.unshift(k);
 const marks=[],decisions=[];let index=0;
 for(let i=0;i<route.length-1;i++){const at=route[i],next=route[i+1],incoming=route[i-1],options=g.get(at).filter(k=>k!==incoming);if(options.length<2)continue;const expected=syms[index%4];const order=[next,...options.filter(k=>k!==next)];
  const [x,z]=at.split(',').map(Number);const choices=order.map((k,j)=>{const[a,b]=k.split(',').map(Number);return {from:at,to:k,x:(x+.5+.28*(a-x))*L.CELL,z:(z+.5+.28*(b-z))*L.CELL,sym:syms[(index+j)%4],ok:j===0,row:phase+1};});
  assert.equal(choices.filter(c=>c.sym===expected).length,1);assert.equal(choices.find(c=>c.sym===expected).to,next);marks.push(...choices);decisions.push({at,expected,correctNext:next,choices});index++;
 }
 return {phase,row:phase+1,route,marks,decisions,rule:'Read only the row for the current stage. At decision junctions follow Giếng → Ruộng → Kho → Miếu cyclically; restart at Giếng after each room. Reverse entry is not a new decision.'};});
const file=new URL('src/layout.js',root);let source=fs.readFileSync(file,'utf8').split('\n// REV P VERIFIED FLOOR GUIDES')[0];
source+='\n// REV P VERIFIED FLOOR GUIDES\nexport const GUIDE_STAGES = '+JSON.stringify(guides)+';\nPOI.symbols=GUIDE_STAGES[0].marks;\n';
fs.writeFileSync(file,source);fs.writeFileSync(new URL('guide-validation.json',root),JSON.stringify({status:'PASS',stages:guides.map(g=>({phase:g.phase,decisionJunctions:g.decisions.length,routeSteps:g.route.length-1,oneCorrectExpectedSymbolPerDecision:true})),physicalDesign:'Four numbered rows on fixed floor plaques, one row per stage; viewer isolates selected row for clarity.'},null,2));console.log('Four stage-specific floor-symbol rows verified against legal routes.');
