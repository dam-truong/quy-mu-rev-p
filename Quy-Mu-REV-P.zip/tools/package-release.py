"""Create a portable REV P archive, including sources and the construction guide."""
from pathlib import Path
import json, hashlib, zipfile, shutil, re

root = Path(__file__).resolve().parents[1]
guide = root / 'HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.md'
text = guide.read_text(encoding='utf-8')
assert '<!-- GENERATED_COORDINATES -->' in text
assert len(re.findall(r'^\| OW\d\d \|', text, re.M)) == 22
assert len(re.findall(r'^\| X[1-4] \|', text, re.M)) == 4
assert len(re.findall(r'^\| W\d\d \|', text, re.M)) == 51
for link in re.findall(r'\]\(([^)]+)\)', text):
    if not link.startswith('https://'):
        assert (root / link).exists(), f'Missing guide link: {link}'
delivery = json.loads((root / 'DELIVERY.json').read_text(encoding='utf-8'))
for name in list(delivery['hashes']) + [guide.name, 'index.html', 'HUONG-DAN.html']:
    delivery['hashes'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
# Packaging does not publish; preserve the publication metadata set after deployment.
delivery.update(constructionGuide=guide.name)
(root / 'DELIVERY.json').write_text(json.dumps(delivery, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
archive = root / 'Quy-Mu-REV-P.zip'
files = sorted(p for p in root.rglob('*') if p.is_file() and not any(part in {'.git', 'node_modules', '__pycache__'} for part in p.relative_to(root).parts) and p.suffix not in {'.zip', '.log'} and p.name != 'julius-log.txt')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert z.read(guide.name) == guide.read_bytes()
shutil.copyfile(archive, root.parent / archive.name)
print(json.dumps({'archive': str(archive), 'files': len(files), 'bytes': archive.stat().st_size, 'guideBytes': guide.stat().st_size, 'guideTables': 'PASS'}))
