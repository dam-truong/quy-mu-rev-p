"""Switch public links to the standalone LaTeX guide, retaining the editorial source."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
stem='HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P'
for name in ['viewer-template.html','index.html','model-360.html','HUONG-DAN.html','README.md',
             'tools/finish-artifacts.mjs','tools/stage-pages.mjs','tools/add-construction-links.mjs','tools/verify-deployment.mjs']:
    p=root/name
    text=p.read_text(encoding='utf-8').replace(stem+'.md',stem+'.tex').replace('cơ chế cửa (.md)','cơ chế cửa (.tex)')
    p.write_text(text,encoding='utf-8')
p=root/'README.md'
text=p.read_text(encoding='utf-8')
note='\nLaTeX: mở '+stem+'.tex trên Overleaf, chọn XeLaTeX và biên dịch hai lần. File tự chứa, dùng font TeX Gyre. Nguồn Markdown được giữ để sinh lại nội dung; chạy python tools/build-guide-latex.py (cần Pandoc) sau khi cập nhật bảng tọa độ.\n'
if 'LaTeX: mở' not in text:p.write_text(text+note,encoding='utf-8')
