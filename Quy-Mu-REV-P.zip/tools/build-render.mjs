import fs from 'node:fs';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {dependency,dependencyPaths} from './deps.mjs';
import * as L from '../src/layout.js';
const root=fileURLToPath(new URL('../',import.meta.url));
const report=JSON.parse(fs.readFileSync(root+'julius/final/report.json','utf8'));
assert.ok(['PASS_SIMULATION_GATE','REJECT_UNDER_THRESHOLD'].includes(report.status));
if(report.status!=='PASS_SIMULATION_GATE'&&!process.argv.includes('--draft'))throw Error('Below threshold: use --draft for clearly labelled local render only.');assert.equal(report.permutations,24);
const runs=report.runs.map(r=>({...r,log:fs.readFileSync(root+'julius/final/'+r.strategy+'.jsonl','utf8').trim().split('\n').map(JSON.parse)}));
const emergency=JSON.parse(fs.readFileSync(root+'emergency-plan.json','utf8'));
fs.writeFileSync(root+'src/presentation-data.json',JSON.stringify({report,runs,emergency}));
const {build}=await dependency('esbuild'),{chromium}=await dependency('playwright');
const bundle=await build({entryPoints:[root+'src/viewer.js'],bundle:true,write:false,format:'iife',minify:true,target:'es2020',legalComments:'none',nodePaths:dependencyPaths});
const html=fs.readFileSync(root+'viewer-template.html','utf8').replace('/*THRESHOLD_MINUTES*/',String(report.thresholdSeconds/60)).replace('/*THRESHOLD_MINUTES*/',String(report.thresholdSeconds/60)).replace('/*THRESHOLD_MINUTES*/',String(report.thresholdSeconds/60)).replace('/*BUNDLE*/',()=>bundle.outputFiles[0].text.replaceAll('</script','<\\/script'));
fs.writeFileSync(root+'model-360.html',html);fs.writeFileSync(root+'index.html',html);
// Adapt the existing N drawing system, replacing its original timing claims.
let draw=fs.readFileSync(new URL('./blueprint-template.js',import.meta.url),'utf8');
draw=draw.replace("REV = 'REV N'","REV = 'REV P'").replace('JULIUS_REPORT as JR','JULIUS_REPORT as ORIGINAL_JR');
const sorted=runs.slice().sort((a,b)=>a.seconds-b.seconds),med=sorted[12];
const heat=new Map();for(const r of runs)for(const s of r.log)heat.set(s.to,(heat.get(s.to)??0)+1/runs.length);
const jr={params:{speed:1.2,los:1,junction:0,deadEnd:0,blocked:0},runs:24,target:report.thresholdSeconds,pass:report.minimumSeconds>=report.thresholdSeconds,best:report.minimumSeconds,p10:sorted[2].seconds,median:med.seconds,worst:report.maximumSeconds,legMed:[0,1,2,3].map(i=>runs.map(r=>r.stages[i].secondsAt1_2).sort((a,b)=>a-b)[12]),rounds:[],heat:[...heat].map(([k,v])=>[...k.split(',').map(Number),v]),sampleTime:med.seconds,sampleRoute:med.log.map(s=>s.toXZ.map(v=>(v+.5)*L.CELL))};
draw='const JR='+JSON.stringify(jr)+';\n'+draw;
draw=draw.replaceAll('100 lượt','24 lượt').replace('ĐẠT — ĐỘ KHÓ ≥ 9/10','PASS — MỐC '+(report.thresholdSeconds/60)+' PHÚT').replace('Báo cáo thanh tra Julius / đi thử 24 lượt, không biết cốt truyện, không đọc ký hiệu','Julius / 24 thứ tự hướng / không cộng thời gian đố, suy nghĩ hoặc đứng chờ');
draw=draw.replace('Đi ${P_.speed} m/s (hành lang tối, đèn pin), nhìn thẳng xa ${P_.los} ô.','Đi ${P_.speed} m/s; chỉ quan sát ô hiện tại và lối kề.');
draw=draw.replace("'Không biết trước cửa một chiều, tường ẩn, tường xoay; bị gương lừa', 'tới khi đứng sát. Giải đố trong phòng tính 0 s.'","'Biết lối đi được tại ô hiện tại; không biết toàn bản đồ.', 'Giữ trí nhớ qua 4 pha. Giải đố và dừng suy nghĩ = 0 s.'");
draw=draw.replace('LỊCH SỬ NÂNG CẤP (CHẶNG DỄ NHẤT → SỬA GÌ)','TỐI ƯU MIN–MAX / XEM LOG TRONG BÁO CÁO');
draw=draw.replaceAll('REV N','REV P').replace("DATE = '14.10.2026'","DATE = '17.10.2026'");
draw=draw.replace("'Ở mọi trạng thái, kể cả lúc khóa mở / tường xoay khi người đang', 'ở trong, mọi ô đi tới được đều có đường về cổng (test tự động).'","'Đã kiểm tra đường về cổng ở đầu/cuối mỗi pha.', 'Trong lúc xoay: dùng liên động nhả khẩn và cửa E; xem hồ sơ.'");
draw=draw.replace("'Ngoài đời: tường xoay chạy chậm (≥ 4 s/90°), có cảm biến kẹt và'","'Cơ khí cần duyệt riêng: cảm biến vùng quét, cảm biến kẹt và'");
// Emergency panel remains a closed wall in normal gameplay. Annotate its exact position.
draw=draw.replace('function walls()', 'function walls()');
const panelAnnotations=emergency.panels.map(e=>{const[x,z,a,b]=e.segmentMeters;return `add('<line x1="'+P(${x})+'" y1="'+Q(${z})+'" x2="'+P(${a})+'" y2="'+Q(${b})+'" stroke="#8ceab6" stroke-width="8" stroke-dasharray="9 5"/>');text(P(${(x+a)/2})+18,Q(${(z+b)/2})-12,'${e.id}',22,'#8ceab6');`;}).join('\n');
draw=draw.replace('function footer() {','function footer() {\n'+panelAnnotations+'\n');
fs.writeFileSync(root+'blueprint/draw.js',draw);
const bpBundle=await build({entryPoints:[root+'blueprint/draw.js'],bundle:true,write:false,format:'iife',target:'es2020',nodePaths:dependencyPaths});
const browser=await chromium.launch({channel:'msedge',headless:true}),page=await browser.newPage({viewport:{width:2560,height:2100}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));
const names=['K-01-mat-bang-tuong','K-02-khoi-tuong','K-03-tuyen-truyen','K-04-loi-gia-dai','K-05-he-thong-khoa','K-06-chu-thich-co-che','K-07-thanh-tra-julius'];
for(const name of names.filter(n=>!n.startsWith('K-02'))){
 const shell='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:#082b50}#sheet{position:relative;width:2560px;height:2100px}</style><div id="sheet"></div><script>'+bpBundle.outputFiles[0].text.replace("new URLSearchParams(location.search).get('sheet') || 'K-01'",JSON.stringify(name.slice(0,4))).replaceAll('</script','<\\/script')+'</script>';
 // Set location query through a local HTML file so the original selector stays intact.
 fs.writeFileSync(root+'blueprint/render-sheet.html',shell);
 await page.goto(pathToFileURL(root+'blueprint/render-sheet.html').href+'?sheet='+name.slice(0,4));await page.locator('#sheet svg').waitFor();
 await page.screenshot({path:root+'blueprint/'+name+'.png'});fs.writeFileSync(root+'blueprint/'+name+'.svg',await page.locator('#sheet svg').evaluate(e=>e.outerHTML));
}
await page.setViewportSize({width:1800,height:1200});await page.goto(pathToFileURL(root+'model-360.html').href);await page.waitForFunction(()=>window.MAZE_API);
for(let s=0;s<4;s++){
 await page.evaluate(s=>window.MAZE_API.setPhase(s),s);await page.screenshot({path:root+'previews/S'+s+'-360.png'});
 const data=await page.evaluate(async()=>Array.from(new Uint8Array(await window.MAZE_API.glb())));fs.writeFileSync(root+`Quy-Mu-REV-P-S${s}.glb`,Buffer.from(data));
}
await page.evaluate(()=>{window.MAZE_API.setPhase(0);window.MAZE_API.setView('orbit');});
await page.waitForTimeout(150);
const perspective=await page.evaluate(()=>window.MAZE_API.renderer.domElement.toDataURL('image/png'));
const perspectiveSvg=`<svg xmlns="http://www.w3.org/2000/svg" width="2560" height="2100" viewBox="0 0 2560 2100"><rect width="2560" height="2100" fill="#14242b"/><rect x="50" y="50" width="2460" height="2000" fill="none" stroke="#567374"/><g fill="#d9e6d4" font-family="Arial"><text x="110" y="140" font-size="24">QUỶ MÙ / 11 × 11 m / REV P</text><text x="110" y="220" font-size="52">K-02 / Phối cảnh khối tường</text><text x="110" y="282" font-size="26">S0 · Tường cắt thấp để nhìn cấu trúc · ${L.ONEWAY.length} cửa một chiều · ${L.SHIFTS.length} tường xoay</text><image href="${perspective}" x="100" y="320" width="2360" height="1580"/><text x="110" y="1960" font-size="24">${report.status === "PASS_SIMULATION_GATE" ? "Đạt ngưỡng mô phỏng" : "BẢN THỬ — CHƯA ĐẠT"} ${report.thresholdSeconds/60} phút; nhanh nhất ${(report.minimumSeconds/60).toFixed(2)} phút. Đây là mô hình khái niệm, chưa phải hồ sơ thi công.</text></g></svg>`;
fs.writeFileSync(root+'blueprint/K-02-khoi-tuong.svg',perspectiveSvg);
await page.evaluate(()=>window.MAZE_API.setView('plan'));await page.screenshot({path:root+'previews/mat-bang-3D.png'});
assert.equal(await page.locator('#run option').count(),24);
await page.locator('#scrub').evaluate(e=>{e.value=e.max;e.dispatchEvent(new Event('input'));});await page.screenshot({path:root+'previews/julius-finish.png'});
const sheetPage=await browser.newPage({viewport:{width:2560,height:2100}});await sheetPage.setContent('<style>body{margin:0}</style>'+perspectiveSvg);await sheetPage.screenshot({path:root+'blueprint/K-02-khoi-tuong.png'});
assert.deepEqual(errors,[]);await browser.close();
fs.writeFileSync(root+'browser-validation.json',JSON.stringify({status:'PASS',runs:24,stages:4,offline:true,errors,GLB:4},null,2));
fs.writeFileSync(root+'blueprint/index.html','<!doctype html><html lang="vi"><meta charset="utf-8"><title>Blueprint REV P</title><style>body{margin:0;background:#082b50;color:#dfecdf;font:16px Arial}nav{padding:20px;position:sticky;top:0;background:#183b4b}a{color:#bde3cb;margin-right:25px}img{width:100%;display:block}</style><nav><a href="../model-360.html">Mô hình 360°</a><a href="../julius/final/REPORT.html">Julius</a></nav>'+names.map(n=>'<img src="'+n+'.png" alt="'+n+'">').join('')+'</html>');
console.log(report.status+': rendered 7 sheets, offline 360, 4 GLB stages.');
