// Sinh mê cung Quỷ Mù (REV N) và ghi thẳng src/layout.js.
// Chạy: node quy-mu-3d/tools/gen-maze.mjs [seed]
//
// Bố cục: sàn 11 × 11 m. Lưới 12 × 12 ô vuông CELL = 11/12 ≈ 0,917 m (>= 0,9 m để đi thoải mái; hành lang thông thủy ≈ 0,76 m).
//   Làng 9 × 3 ô (8,25 × 2,75 m — gần nhất với 8 × 2,5 m mà vẫn khớp lưới) ở góc dưới bên trái; phòng Người canh ấn
//   3 × 3 ô (2,75 × 2,75 m) ở góc dưới bên phải, sát Làng (không cửa thông), cửa mở lên mê cung. Cổng mê cung C02 trên tường trên của Làng, cửa vào Làng C01 ở tường trái.
//   Tế thần (5 × 3 ô) và Giam Vọng Âm (4 × 2 ô) dính nhau áp tường trên; chỗ dưới Giam (trước là phòng Người canh) giờ là
//   mê cung. Mê cung bao 3 phía cụm trên và chạy xuống tận cửa phòng Người canh. Cửa thoát C06 ở góc trên bên phải.
//   (Đã thử cụm ở giữa phòng: dải hành lang quanh cụm chỉ rộng 2 ô nên ra hành lang thẳng, Julius nhanh hơn ~3 phút.)
//
// Cách sinh:
//   1. Nền là mê cung hoàn hảo kiểu "growing tree" (80% nhánh mới nhất): hành lang dài, rẽ liên tục, nhánh cụt sâu — như mẫu.
//   2. Đặt cửa phòng, khóa tuần tự L1 / L2, 2 tường xoay X1 / X2 sao cho hợp lệ.
//   3. Thanh tra Julius (tools/julius.mjs) đi thử 100 lượt. Cả 100 lượt (kể cả lượt nhanh nhất) phải >= 15 phút mới đạt.
//      Chưa đạt: đọc log của Julius, tìm chặng hắn đi nhanh nhất và các ô hắn đi qua ở chặng đó, rồi sửa tường / thêm cửa
//      một chiều / dời khóa, tường xoay, cửa phòng tập trung ở khúc đó (hill climbing có mục tiêu là thời gian của Julius).
//      Lặp lại tới khi đạt. Lịch sử từng vòng ghi vào JULIUS_REPORT trong layout.js và log mẫu vào julius-log.txt.
// Luật cứng: mọi ô đi tới được (kể cả lúc khóa mở / tường xoay khi người đang ở trong) luôn có đường về cổng;
// chưa xong phòng trước thì không có đường tới phòng sau; mọi ô hành lang đều dùng tới; không có khoảng sân 2 × 2.
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { runJulius, juliusStats, LOOK, JULIUS, mmss } from './julius.mjs';

const SIZE = 11, COLS = 12, ROWS = 12, CELL = SIZE / COLS;
const VILLAGE = [0, 9, 9, 12], GZ = VILLAGE[1] * CELL;          // Làng (ô); GZ: tường cổng giữa mê cung và Làng (mét)
const ROOM_BOX = { te: [2, 0, 7, 3], giam: [7, 0, 11, 2], canh: [9, 9, 12, 12] }; // ô [x1, z1, x2, z2), x2/z2 không gồm
const ORDER = ['giam', 'canh', 'te'];
const ROOM_DOOR = { giam: { id: 'C03', kind: 'bars' }, canh: { id: 'C04', kind: 'sealed' }, te: { id: 'C05', kind: 'gate' } };
const LOCK_DEFS = [{ id: 'L1', after: 'giam', room: 'canh', kind: 'hidden' }, { id: 'L2', after: 'canh', room: 'te', kind: 'hidden' }];
const GATE = [4, 8], EXIT = [11, 0], C01_CELL = [0, 10];
const TARGET = Number(process.env.TARGET || 900);          // giây: lượt Julius nhanh nhất phải vượt mốc này
const MAX_ROUNDS = Number(process.env.ROUNDS || 60), ITERS = Number(process.env.ITERS || 800);
const MAX_OW = 14, MAX_LOOPS = 6, EVAL_RUNS = 20;
const SYMS = ['gieng', 'lua', 'kho', 'mieu'];

const key = (x, z) => `${x},${z}`;
const K = c => key(...c);
const DIRV = [[0, -1], [1, 0], [0, 1], [-1, 0]];                // B, Đ, N, T
const inBox = (x, z, [a, b, c, d]) => x >= a && x < c && z >= b && z < d;
const roomOfCell = (x, z) => ORDER.find(k => inBox(x, z, ROOM_BOX[k])) || (inBox(x, z, VILLAGE) ? 'lang' : undefined);
const isCorr = (x, z) => x >= 0 && z >= 0 && x < COLS && z < ROWS && !roomOfCell(x, z);
const CORR = []; for (let z = 0; z < ROWS; z++) for (let x = 0; x < COLS; x++) if (isCorr(x, z)) CORR.push([x, z]);
const CI = new Map(CORR.map((c, i) => [K(c), i]));
const edgeKey = (a, b) => [K(a), K(b)].sort().join('|');
const NB = new Int16Array(CORR.length * 4).fill(-1);
CORR.forEach(([x, z], i) => DIRV.forEach(([dx, dz], d) => { const j = CI.get(key(x + dx, z + dz)); if (j !== undefined) NB[i * 4 + d] = j; }));
const EDGES = [], EIDX = new Map();
for (const [x, z] of CORR) for (const [dx, dz] of [[1, 0], [0, 1]]) {
  const n = [x + dx, z + dz]; if (!isCorr(...n)) continue;
  EIDX.set(edgeKey([x, z], n), EDGES.length); EDGES.push([CI.get(key(x, z)), CI.get(K(n))]);
}
const edgeOf = (i, d) => EIDX.get(edgeKey(CORR[i], CORR[NB[i * 4 + d]]));
const cellsOf = e => EDGES[e].map(i => CORR[i]);
const segOf = e => { const [a, b] = cellsOf(e); return a[0] !== b[0] ? [b[0], a[1], b[0], a[1] + 1] : [a[0], b[1], a[0] + 1, b[1]]; };
const G = CI.get(K(GATE)), EX = CI.get(K(EXIT));
const segEdge = new Map(EDGES.map((_, e) => [segOf(e).join(','), e]));
const SHIFT_OPTS = [];
for (let vx = 1; vx < COLS; vx++) for (let vz = 1; vz < ROWS; vz++) {
  const vert = [[vx, vz - 1, vx, vz], [vx, vz, vx, vz + 1]].map(s => segEdge.get(s.join(',')));
  const hor = [[vx - 1, vz, vx, vz], [vx, vz, vx + 1, vz]].map(s => segEdge.get(s.join(',')));
  for (const e1 of vert) for (const e2 of hor) if (e1 !== undefined && e2 !== undefined) SHIFT_OPTS.push({ post: [vx, vz], e1, e2 }, { post: [vx, vz], e1: e2, e2: e1 });
}
const BLOCKS = [];
for (let z = 0; z < ROWS - 1; z++) for (let x = 0; x < COLS - 1; x++) {
  const c = [[x, z], [x + 1, z], [x, z + 1], [x + 1, z + 1]]; if (!c.every(p => isCorr(...p))) continue;
  BLOCKS.push([[c[0], c[1]], [c[0], c[2]], [c[1], c[3]], [c[2], c[3]]].map(([p, q]) => EIDX.get(edgeKey(p, q))));
}
// cửa phòng có thể đặt: mặt d của ô hành lang i giáp phòng k. Tọa độ cửa tính bằng mét.
const CANDIDATES = Object.fromEntries(ORDER.map(k => [k, []]));
CORR.forEach(([x, z], i) => DIRV.forEach(([dx, dz], d) => {
  const k = roomOfCell(x + dx, z + dz); if (!k || k === 'lang') return;
  const door = d === 1 ? { x: (x + 1) * CELL, z: (z + 0.5) * CELL, axis: 'z' } : d === 3 ? { x: x * CELL, z: (z + 0.5) * CELL, axis: 'z' }
    : d === 2 ? { x: (x + 0.5) * CELL, z: (z + 1) * CELL, axis: 'x' } : { x: (x + 0.5) * CELL, z: z * CELL, axis: 'x' };
  CANDIDATES[k].push({ ...door, cell: i, dir: d, swing: d === 3 || d === 0 ? 1 : -1 });
}));

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- đồ thị theo giai đoạn
const specialsOf = cfg => [...cfg.locks, ...cfg.shifts.flatMap(o => [SHIFT_OPTS[o].e1, SHIFT_OPTS[o].e2])];
const SHIFT_AT = [1, 1, 2, 2];      // X1, X2 xoay khi mở L1 (vào s1); X3, X4 khi mở L2 (vào s2)
function closedAt(cfg, s) {        // s = 0..3
  const c = new Set();
  if (s < 1) c.add(cfg.locks[0]);
  if (s < 2) c.add(cfg.locks[1]);
  cfg.shifts.forEach((o, i) => c.add(s < SHIFT_AT[i] ? SHIFT_OPTS[o].e1 : SHIFT_OPTS[o].e2));
  return c;
}
function adjOf(cfg, s) {
  const closed = closedAt(cfg, s), adj = CORR.map(() => []);
  EDGES.forEach(([a, b], e) => { const t = cfg.st[e]; if (!t || closed.has(e)) return; if (t !== 3) adj[a].push(b); if (t !== 2) adj[b].push(a); });
  return adj;
}
const reverseAdj = adj => { const r = CORR.map(() => []); adj.forEach((ns, c) => ns.forEach(n => r[n].push(c))); return r; };
function bfsFrom(adj, srcs) {
  const seen = new Uint8Array(CORR.length), q = [...srcs];
  for (const s of srcs) seen[s] = 1;
  while (q.length) { const c = q.pop(); for (const n of adj[c]) if (!seen[n]) { seen[n] = 1; q.push(n); } }
  return seen;
}
function shortest(adj, src, dst) {
  const prev = new Int16Array(CORR.length).fill(-2), q = [src]; prev[src] = -1;
  for (let i = 0; i < q.length; i++) for (const n of adj[q[i]]) if (prev[n] === -2) { prev[n] = q[i]; q.push(n); }
  if (prev[dst] === -2) return null;
  const p = []; for (let c = dst; c >= 0; c = prev[c]) p.unshift(c);
  return p;
}
const idxs = mask => { const r = []; for (let i = 0; i < mask.length; i++) if (mask[i]) r.push(i); return r; };

function check(cfg) {
  const T = Object.fromEntries(ORDER.map(k => [k, cfg.doors[k].cell]));
  if (new Set([T.giam, T.canh, T.te, G]).size !== 4) return null;
  const sp = specialsOf(cfg);
  if (new Set(sp).size !== sp.length || sp.some(e => cfg.st[e] !== 1)) return null;
  let ow = 0, open = 0; for (const t of cfg.st) { if (t >= 2) ow++; if (t) open++; }
  if (ow > MAX_OW || open - cfg.shifts.length - (CORR.length - 1) > MAX_LOOPS) return null;
  for (const b of BLOCKS) if (b.every(e => cfg.st[e])) return null;
  if (straightPenalty(cfg, true) > MAX_STRAIGHT) return null;
  const adj = [0, 1, 2].map(s => adjOf(cfg, s));
  const R = [];
  for (let s = 0; s < 3; s++) {
    const r = bfsFrom(adj[s], s ? idxs(R[s - 1]) : [G]);
    const back = bfsFrom(reverseAdj(adj[s]), [G]);
    for (let i = 0; i < r.length; i++) if (r[i] && !back[i]) return null;    // chống kẹt
    R.push(r);
  }
  if (!R[0][T.giam] || R[0][T.canh] || R[0][T.te] || !R[1][T.canh] || R[1][T.te] || !R[2][T.te] || !R[2][EX]) return null;
  if (!R[2].every(v => v)) return null;
  const from = [G, T.giam, T.canh, T.te], to = [T.giam, T.canh, T.te, EX];
  for (let l = 0; l < 3; l++) if (!shortest(adj[l], G, to[l])) return null;
  const paths = from.map((f, l) => shortest(adj[Math.min(l, 2)], f, to[l]));
  if (paths.some(p => !p)) return null;
  return { adj, R, T, from, to, paths, lens: paths.map(p => p.length - 1) };
}

// gương mica: ô cụt (1 mặt mở) đi vào bằng đoạn thẳng >= 2 ô, không phải cổng / cửa thoát / ô trước cửa phòng.
// Gương dán ở mặt tường cuối, đối diện lối vào. Trả về [ô, hướng tới tường gương], tối đa 8.
function mirrorsOf(cfg) {
  const keep = new Set([G, EX, ...ORDER.map(k => cfg.doors[k].cell)]), out = [];
  for (let i = 0; i < CORR.length && out.length < 8; i++) {
    if (keep.has(i)) continue;
    const open = [0, 1, 2, 3].filter(d => NB[i * 4 + d] >= 0 && cfg.st[edgeOf(i, d)]);
    if (open.length !== 1) continue;
    const back = open[0], far = (back + 2) % 4, p = NB[i * 4 + back];
    if (NB[p * 4 + back] < 0 || !cfg.st[edgeOf(p, back)]) continue;   // ô trước đó cũng thẳng hàng
    out.push([i, far]);
  }
  return out;
}

// ---- mê cung cho Julius: hình dạng và khả năng đi qua từng mặt ô theo giai đoạn
const cellName = i => `${'ABCDEFGHIJKL'[CORR[i][1]]}${CORR[i][0] + 1}`;
function mazeFor(cfg) {
  const n = CORR.length, look = [], pass = [];
  const doorAt = new Map(ORDER.map(k => [cfg.doors[k].cell * 4 + cfg.doors[k].dir, k]));
  for (let s = 0; s < 4; s++) {
    const closed = closedAt(cfg, Math.min(s, 3)), lk = new Uint8Array(n * 4), ps = new Uint8Array(n * 4);
    for (let i = 0; i < n; i++) for (let d = 0; d < 4; d++) {
      const j = i * 4 + d, m = NB[j];
      if (m >= 0) {
        const e = edgeOf(i, d), t = cfg.st[e];
        if (!t) lk[j] = LOOK.WALL;
        else if (closed.has(e)) lk[j] = LOOK.WALL;               // L1, L2 và tường xoay đóng đều trông như tường đá
        else { lk[j] = LOOK.OPEN; ps[j] = t === 1 || (t === 2 ? EDGES[e][0] === i : EDGES[e][1] === i) ? 1 : 0; }
      } else if (doorAt.has(j)) lk[j] = LOOK.ROOM;
      else if (i === EX && d === 1) { lk[j] = s === 3 ? LOOK.EXIT : LOOK.WALL; ps[j] = s === 3 ? 1 : 0; } // cửa thoát ẩn tới khi xong Tế
      else lk[j] = LOOK.WALL;
    }
    look.push(lk); pass.push(ps);
  }
  const roomAt = new Array(n).fill(null); for (const k of ORDER) roomAt[cfg.doors[k].cell] = k;
  const mirror = new Uint8Array(n * 4); for (const [i, d] of mirrorsOf(cfg)) mirror[i * 4 + d] = 1;
  return { n, nb: NB, look, pass, mirror, gate: G, exit: EX, exitDir: 1, roomAt, order: ORDER, cell: CELL, name: cellName,
    rooms: Object.fromEntries(ORDER.map(k => [k, { cell: cfg.doors[k].cell, dir: cfg.doors[k].dir }])) };
}

// hành lang thẳng dài = dễ nhìn xuyên, không ngoằn ngoèo -> phạt đoạn thẳng >= 4 ô (maxRun: đoạn dài nhất)
function straightPenalty(cfg, maxRun = false) {
  let p = 0, best = 0;
  for (const d of [1, 2]) for (let i = 0; i < CORR.length; i++) {
    const back = NB[i * 4 + (d + 2) % 4]; if (back >= 0 && cfg.st[edgeOf(i, (d + 2) % 4)]) continue;
    let run = 1, c = i, hot = inBox(...CORR[i], HOT_BOX); while (NB[c * 4 + d] >= 0 && cfg.st[edgeOf(c, d)]) { run++; c = NB[c * 4 + d]; hot ||= inBox(...CORR[c], HOT_BOX); }
    if (run >= 4) p += run - 3;
    best = Math.max(best, run > HOT_MAX && hot ? Infinity : run);   // vùng siêu khó: đoạn thẳng chạm vùng không quá HOT_MAX ô
  }
  return maxRun ? best : p;
}
// chỗ cũ của phòng Người canh (dưới Giam): mê cung siêu khó, đoạn thẳng nào chạm vùng này dài tối đa 2 ô
const HOT_BOX = [7, 2, 11, 4], HOT_MAX = 2;
const MAX_STRAIGHT = Number(process.env.MAX_STRAIGHT || 7);    // cấm hành lang thẳng dài hơn 7 ô (~6,4 m)
// điểm = trung bình 4 lượt nhanh nhất trong EVAL_RUNS lượt Julius (phút) — tối ưu cho người giỏi nhất, không phải trung bình
function score(cfg) {
  const mz = mazeFor(cfg), times = [];
  for (let r = 0; r < EVAL_RUNS; r++) times.push(runJulius(mz, 7 + r).time);
  times.sort((a, b) => a - b);
  return (times[0] + times[1] + times[2] + times[3]) / 240 - 0.3 * straightPenalty(cfg);
}

function perfectMaze(rnd) {
  const st = new Int8Array(EDGES.length), inT = new Uint8Array(CORR.length), act = [G]; inT[G] = 1;
  while (act.length) {
    const idx = rnd() < 0.8 ? act.length - 1 : Math.floor(rnd() * act.length), c = act[idx];
    const opts = [0, 1, 2, 3].map(d => NB[c * 4 + d]).filter(m => m >= 0 && !inT[m]);
    if (!opts.length) { act.splice(idx, 1); continue; }
    const m = opts[Math.floor(rnd() * opts.length)]; st[EIDX.get(edgeKey(CORR[c], CORR[m]))] = 1; inT[m] = 1; act.push(m);
  }
  return st;
}
function initial(seed) {
  const rnd = mulberry32(seed), pick = a => a[Math.floor(rnd() * a.length)];
  for (let tries = 0; tries < 400; tries++) {
    const st = perfectMaze(rnd), doors = Object.fromEntries(ORDER.map(k => [k, pick(CANDIDATES[k])]));
    const base = { st, doors, locks: [], shifts: [] }, adj = adjOf({ ...base, locks: [-1, -1], shifts: [] }, 3);
    const pe = k => { const p = shortest(adj, G, doors[k].cell); return new Set(p.slice(1).map((c, i) => EIDX.get(edgeKey(CORR[p[i]], CORR[c])))); };
    const [pg, pc, pt] = ORDER.map(pe);
    const l1 = [...pc].filter(e => !pg.has(e)), l2 = [...pt].filter(e => !pg.has(e) && !pc.has(e));
    if (!l1.length || !l2.length) continue;
    const locks = [pick(l1), pick(l2)];
    for (let t = 0; t < 300; t++) {
      const shifts = SHIFT_AT.map(() => Math.floor(rnd() * SHIFT_OPTS.length));
      if (shifts.some(o => st[SHIFT_OPTS[o].e1] !== 0 || st[SHIFT_OPTS[o].e2] !== 1)) continue;
      const cfg = { st: st.slice(), doors: { ...doors }, locks: locks.slice(), shifts };
      for (const o of shifts) cfg.st[SHIFT_OPTS[o].e1] = 1;
      if (check(cfg)) return cfg;
    }
  }
  return null;
}

// khúc dễ: các cạnh quanh những ô Julius đi qua ở chặng hắn đi nhanh nhất, trong các lượt nhanh nhất
function easyFocus(stats) {
  const fast = stats.res.slice().sort((a, b) => a.time - b.time).slice(0, 10);
  const leg = stats.legMed.indexOf(Math.min(...stats.legMed)), w = new Float64Array(EDGES.length);
  for (const r of fast) for (const [s, c] of r.trace) if (s === leg) for (let d = 0; d < 4; d++) if (NB[c * 4 + d] >= 0) w[edgeOf(c, d)] += 1;
  const list = []; let tot = 0; w.forEach((v, e) => { if (v > 0) { tot += v; list.push([e, tot]); } });
  return { leg, pick: rnd => { if (!list.length || rnd() < 0.25) return Math.floor(rnd() * EDGES.length); const x = rnd() * tot; return list.find(([, c]) => c >= x)[0]; }, cells: new Set(fast.flatMap(r => r.trace.filter(([s]) => s === leg).map(([, c]) => c))) };
}
function mutate(cfg, rnd, focus) {
  const c = { st: cfg.st.slice(), doors: { ...cfg.doors }, locks: cfg.locks.slice(), shifts: cfg.shifts.slice() };
  const sp = new Set(specialsOf(c)), r = rnd(), pickN = n => Math.floor(rnd() * n);
  const toggle = e => { if (sp.has(e)) return; const t = c.st[e], q = rnd(); c.st[e] = t === 0 ? (q < 0.7 ? 1 : q < 0.85 ? 2 : 3) : t === 1 ? (q < 0.7 ? 0 : q < 0.85 ? 2 : 3) : (q < 0.4 ? 0 : q < 0.7 ? 1 : 5 - t); };
  if (r < 0.4) { toggle(focus.pick(rnd)); if (rnd() < 0.4) toggle(focus.pick(rnd)); }
  else if (r < 0.65) {                        // nối lại nhánh: đóng một lối, mở một lối khác gần đó (giữ dạng cây)
    const e1 = focus.pick(rnd), e2 = focus.pick(rnd);
    if (!sp.has(e1) && !sp.has(e2) && c.st[e1] && !c.st[e2]) { c.st[e1] = 0; c.st[e2] = 1; }
  } else if (r < 0.75) { const i = pickN(2), e = focus.pick(rnd); if (!sp.has(e)) { c.locks[i] = e; c.st[e] = 1; } }
  else if (r < 0.87) {
    const i = pickN(SHIFT_AT.length), o = pickN(SHIFT_OPTS.length), { e1, e2 } = SHIFT_OPTS[o];
    sp.delete(SHIFT_OPTS[c.shifts[i]].e1); sp.delete(SHIFT_OPTS[c.shifts[i]].e2);
    if (!sp.has(e1) && !sp.has(e2)) { c.shifts[i] = o; c.st[e1] = c.st[e2] = 1; }
  } else { const k = ORDER[pickN(3)], cand = CANDIDATES[k]; c.doors[k] = cand[pickN(cand.length)]; }
  return c;
}
function diffOf(a, b) {
  let walls = 0, ow = 0; a.st.forEach((t, e) => { if (t !== b.st[e]) { if (t >= 2 || b.st[e] >= 2) ow++; else walls++; } });
  const doors = ORDER.filter(k => a.doors[k] !== b.doors[k]).length;
  return { walls, ow, doors, locks: a.locks.filter((e, i) => e !== b.locks[i]).length, shifts: a.shifts.filter((o, i) => o !== b.shifts[i]).length };
}

// ---- chọn mê cung khởi đầu, rồi vòng lặp thanh tra Julius
const argSeed = process.argv[2] ? Number(process.argv[2]) : null;
let cfg = null, seed = argSeed ?? Number(process.env.SEED0 || 100), bestS = -Infinity;
for (let s = seed, tried = 0; tried < (argSeed !== null ? 1 : 12); s++) {
  const c0 = initial(s); if (!c0) continue; tried++;
  const sc = score(c0); if (sc > bestS) { bestS = sc; cfg = c0; seed = s; }
}
if (!cfg) { console.error('không dựng được mê cung khởi đầu'); process.exit(1); }
const rnd = mulberry32(seed * 131 + 9), rounds = [];
let stats, best = null;
for (let round = 1; ; round++) {
  stats = juliusStats(mazeFor(cfg), 100, 1000);
  if (best && stats.best + stats.p10 < best.stats.best + best.stats.p10) {   // vòng vừa rồi làm Julius nhanh hơn: bỏ, quay về bản tốt nhất
    rounds[rounds.length - 1].reverted = true;
    console.log(`   vòng ${round - 1} làm Julius nhanh hơn (nhanh nhất ${mmss(stats.best)}, p10 ${mmss(stats.p10)}): bỏ, giữ bản trước`);
    cfg = best.cfg; stats = best.stats;
  } else best = { cfg, stats };
  const focus = easyFocus(stats);
  const entry = { round, p10: Math.round(stats.p10), median: Math.round(stats.median), best: Math.round(stats.best), legMed: stats.legMed.map(Math.round), easyLeg: focus.leg, easyCells: [...focus.cells].map(cellName).slice(0, 12) };
  rounds.push(entry);
  console.log(`vòng ${round}: Julius p10 ${mmss(stats.p10)}, trung vị ${mmss(stats.median)}, nhanh nhất ${mmss(stats.best)}; chặng (trung vị) ${stats.legMed.map(mmss).join(' / ')}; dễ nhất: chặng ${focus.leg + 1}`);
  if ((stats.best >= TARGET) || round >= MAX_ROUNDS) break;            // đạt: cả 100 lượt Julius đều >= 15 phút
  let cur = cfg, curS = score(cur);
  const T0 = 0.6, T1 = 0.02;
  for (let it = 0; it < ITERS; it++) {
    const T = T0 * (T1 / T0) ** (it / ITERS);
    const cand = mutate(cur, rnd, focus); if (!check(cand)) continue;
    const s = score(cand);
    if (s >= curS || rnd() < Math.exp((s - curS) / T)) { cur = cand; curS = s; }
  }
  entry.changes = diffOf(cur, cfg);
  console.log(`   nâng cấp quanh khúc dễ (${entry.easyCells.slice(0, 6).join(', ')}…): ${entry.changes.walls} đoạn tường, ${entry.changes.ow} cửa một chiều, ${entry.changes.doors} cửa phòng, ${entry.changes.locks} khóa, ${entry.changes.shifts} tường xoay`);
  cfg = cur;
}
const chk = check(cfg), mz = mazeFor(cfg);
const pass = stats.best >= TARGET;
console.log(pass ? `ĐẠT: cả 100 lượt Julius đều >= ${mmss(TARGET)} (nhanh nhất ${mmss(stats.best)}, p10 ${mmss(stats.p10)}).` : `CHƯA ĐẠT sau ${rounds.length} vòng: nhanh nhất ${mmss(stats.best)}.`);
// log mẫu: lượt có thời gian gần trung vị nhất, và lượt nhanh nhất
const byTime = stats.res.map((r, i) => [r.time, i]).sort((a, b) => a[0] - b[0]);
const medSeed = 1000 + byTime[Math.floor(byTime.length / 2)][1], bestSeed = 1000 + byTime[0][1];
const medRun = runJulius(mz, medSeed, { log: true }), bestRun = runJulius(mz, bestSeed, { log: true });
const logFile = fileURLToPath(new URL('../julius-log.txt', import.meta.url));
writeFileSync(logFile, [
  `THANH TRA JULIUS — mê cung Quỷ Mù REV N (seed ${seed})`,
  `Giả định: đi ${JULIUS.speed} m/s trong hành lang tối, nhìn xa ${JULIUS.los} ô, dừng ${JULIUS.junction} s ở ngã rẽ mới, ${JULIUS.deadEnd} s ở ngõ cụt, ${JULIUS.blocked} s khi đẩy cửa không mở. Không biết cốt truyện, không đọc ký hiệu sàn, giải đố = 0 s.`,
  `100 lượt: nhanh nhất ${mmss(stats.best)}, p10 ${mmss(stats.p10)}, trung vị ${mmss(stats.median)}, chậm nhất ${mmss(stats.worst)}. Mốc đạt: cả 100 lượt >= ${mmss(TARGET)} → ${pass ? 'ĐẠT' : 'CHƯA ĐẠT'}.`,
  '', 'LỊCH SỬ NÂNG CẤP',
  ...rounds.map(r => `vòng ${r.round}: p10 ${mmss(r.p10)}, trung vị ${mmss(r.median)}; chặng dễ nhất ${r.easyLeg + 1} (${r.easyCells.slice(0, 6).join(', ')})` + (r.changes ? ` → sửa ${r.changes.walls} tường, ${r.changes.ow} cửa một chiều, ${r.changes.doors} cửa phòng, ${r.changes.locks} khóa, ${r.changes.shifts} tường xoay${r.reverted ? ' (Julius nhanh hơn → bỏ)' : ''}` : '')),
  '', `LƯỢT NHANH NHẤT (${mmss(bestRun.time)})`, ...bestRun.lines,
  '', `LƯỢT TRUNG VỊ (${mmss(medRun.time)})`, ...medRun.lines, '',
].join('\n'));
console.log(`đã ghi ${logFile}`);

// ---- quy về dữ liệu xuất (mét). Ô (x, z) -> mét: nhân CELL.
const TARGETC = Object.fromEntries(ORDER.map(k => [k, CORR[cfg.doors[k].cell]]));
const r4 = v => Math.round(v * 1e4) / 1e4, r2 = v => Math.round(v * 100) / 100;
const center = ([x, z]) => [r4((x + 0.5) * CELL), r4((z + 0.5) * CELL)];
const d2 = (p, q) => (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2;
// tường cố định theo ô: H "x,z" = đoạn ngang trên đường z từ x tới x+1; V "x,z" = đoạn dọc trên đường x từ z tới z+1
const Hs = new Set(), Vs = new Set();
const doorSide = new Set(ORDER.map(k => cfg.doors[k].cell * 4 + cfg.doors[k].dir));
const wallBetween = (p, q) => {                    // p, q: hai ô kề (có thể ngoài lưới / trong phòng)
  const cp = CI.get(K(p)), cq = CI.get(K(q));
  if (cp !== undefined && cq !== undefined) return cfg.st[EIDX.get(edgeKey(p, q))] === 0;
  const rp = isCorr(...p) ? 'C' : roomOfCell(...p) || 'out', rq = isCorr(...q) ? 'C' : roomOfCell(...q) || 'out';
  if (rp === rq && rp !== 'C' && rp !== 'out') return false;
  if ((K(p) === K(C01_CELL) && q[0] < 0) || (K(q) === K(C01_CELL) && p[0] < 0)) return false;  // cửa vào Làng C01
  for (const [c, o] of [[cp, q], [cq, p]]) if (c !== undefined) { const d = DIRV.findIndex(([dx, dz]) => CORR[c][0] + dx === o[0] && CORR[c][1] + dz === o[1]); if (doorSide.has(c * 4 + d)) return false; if (c === EX && d === 1) return false; if (c === G && d === 2) return false; }
  return true;
};
for (let x = 0; x < COLS; x++) for (let z = 0; z <= ROWS; z++) if (wallBetween([x, z - 1], [x, z])) Hs.add(key(x, z));
for (let z = 0; z < ROWS; z++) for (let x = 0; x <= COLS; x++) if (wallBetween([x - 1, z], [x, z])) Vs.add(key(x, z));
function mergeWalls() {
  const out = [];
  for (let z = 0; z <= ROWS; z++) { let s = -1; for (let x = 0; x <= COLS; x++) { const on = x < COLS && Hs.has(key(x, z)); if (on && s < 0) s = x; if (!on && s >= 0) { out.push([s, z, x, z]); s = -1; } } }
  for (let x = 0; x <= COLS; x++) { let s = -1; for (let z = 0; z <= ROWS; z++) { const on = z < ROWS && Vs.has(key(x, z)); if (on && s < 0) s = z; if (!on && s >= 0) { out.push([x, s, x, z]); s = -1; } } }
  return out;
}
const C01_Z = r4((C01_CELL[1] + 0.5) * CELL), GATE_X = r4((GATE[0] + 0.5) * CELL);
const WALLS_M = [...mergeWalls().map(([x1, z1, x2, z2]) => [r4(x1 * CELL), r4(z1 * CELL), r4(x2 * CELL), r4(z2 * CELL)])];
const ROOMS_M = [VILLAGE.map(v => r4(v * CELL)), ...['te', 'giam', 'canh'].map(k => ROOM_BOX[k].map(v => r4(v * CELL)))];
const DOORS = [
  { id: 'C01', x: 0, z: C01_Z, axis: 'z', kind: 'gate' },
  { id: 'C02', x: GATE_X, z: r4(GZ), axis: 'x', kind: 'gate' },
  ...ORDER.map(k => ({ ...ROOM_DOOR[k], x: r4(cfg.doors[k].x), z: r4(cfg.doors[k].z), axis: cfg.doors[k].axis, swing: cfg.doors[k].swing })),
  { id: 'C06', x: SIZE, z: r4(0.5 * CELL), axis: 'z', kind: 'exit' },
];
const nbsPhys = (x, z) => {
  const r = [];
  if (z > 0 && !Hs.has(key(x, z))) r.push([x, z - 1]);
  if (z < ROWS - 1 && !Hs.has(key(x, z + 1))) r.push([x, z + 1]);
  if (x > 0 && !Vs.has(key(x, z))) r.push([x - 1, z]);
  if (x < COLS - 1 && !Vs.has(key(x + 1, z))) r.push([x + 1, z]);
  return r;
};
const corrNbs = (x, z) => nbsPhys(x, z).filter(c => isCorr(...c));
const paths = Object.fromEntries(['giam', 'canh', 'te', 'exit'].map((k, l) => [k, chk.paths[l].map(i => CORR[i])]));
const lens = Object.fromEntries(['giam', 'canh', 'te', 'exit'].map((k, l) => [k, chk.lens[l]]));
const stageOut = s => c => chk.adj[Math.min(s, 2)][CI.get(K(c))].map(i => CORR[i]);
const firstStage = c => [0, 1, 2].find(s => chk.R[s][CI.get(K(c))]);
const locks = cfg.locks.map((e, i) => { const [p, q] = cellsOf(e); return { ...LOCK_DEFS[i], a: p, b: q }; });
const oneways = []; cfg.st.forEach((t, e) => { if (t < 2) return; const [p, q] = cellsOf(e); oneways.push(t === 2 ? { from: p, to: q } : { from: q, to: p }); });
const shifts = cfg.shifts.map((o, i) => { const { post, e1, e2 } = SHIFT_OPTS[o]; return { id: `X${i + 1}`, at: `L${SHIFT_AT[i]}`, post, before: segOf(e1), after: segOf(e2), freed: cellsOf(e1), shut: cellsOf(e2) }; });
const closedList = s => [...closedAt(cfg, s)].map(cellsOf);
const isTarget = c => Object.values(TARGETC).some(t => K(t) === K(c));
const deg = new Map(CORR.map(c => [K(c), corrNbs(...c).length + (isTarget(c) || K(c) === K(GATE) || K(c) === K(EXIT) ? 1 : 0)]));
const turnsOf = p => { let t = 0; for (let i = 1; i < p.length - 1; i++) { const [q, b, c] = [p[i - 1], p[i], p[i + 1]]; if (b[0] - q[0] !== c[0] - b[0] || b[1] - q[1] !== c[1] - b[1]) t++; } return t; };
const deadBranches = [];
for (const c of CORR) {
  if (deg.get(K(c)) !== 1) continue;
  const cells = [c]; let prev = null, cur = c;
  while (cells.length < 120) {
    const next = corrNbs(...cur).filter(n => !(prev && K(n) === K(prev)));
    if (cur !== c && deg.get(K(cur)) >= 3) break;
    if (next.length !== 1) break;
    prev = cur; cur = next[0]; cells.push(cur);
  }
  deadBranches.push({ cells, length: cells.length - 1, turns: turnsOf(cells) });
}
const deadSorted = deadBranches.slice().sort((p, q) => q.length - p.length);
const mirrorCells = new Set(mirrorsOf(cfg).map(([i]) => i));
const deadAt = s => deadSorted.filter(d => firstStage(d.cells[0]) === s && !mirrorCells.has(CI.get(K(d.cells[0]))));
const deepSide = cell => { const o = corrNbs(...cell)[0]; return [cell[0] - o[0], cell[1] - o[1]]; };
const ryFacing = ([dx, dz]) => dx === 1 ? -Math.PI / 2 : dx === -1 ? Math.PI / 2 : dz === 1 ? Math.PI : 0;
const FACE = CELL / 2 - 0.08;                       // tâm ô tới mặt tường
const onWall = (cell, [dx, dz], off) => { const [cx, cz] = center(cell); return { x: r4(cx + dx * off), z: r4(cz + dz * off), ry: ryFacing([dx, dz]) }; };
const closedSides = ([x, z]) => DIRV.filter(([dx, dz]) => dx ? Vs.has(key(Math.max(x, x + dx), z)) : Hs.has(key(x, Math.max(z, z + dz))));
const relicDead1 = deadAt(0)[0] || deadSorted[0];
const relicDead3 = deadAt(2)[0] || deadAt(1)[0] || [...deadAt(0), ...deadSorted].find(d => d !== relicDead1);
const nicheOn = (cell, d) => { const p = onWall(cell, d, CELL * 0.25), q = onWall(cell, d, CELL * 0.2); return { x: p.x, z: p.z, rx: q.x, rz: q.z, ry: p.ry }; };
const relic1 = nicheOn(relicDead1.cells[0], deepSide(relicDead1.cells[0])), relic3 = nicheOn(relicDead3.cells[0], deepSide(relicDead3.cells[0]));
const straightEnd = d => d.cells.length >= 3 && d.cells[0][0] - d.cells[1][0] === d.cells[1][0] - d.cells[2][0] && d.cells[0][1] - d.cells[1][1] === d.cells[1][1] - d.cells[2][1];
const decoyDead = deadSorted.filter(d => d !== relicDead1 && d !== relicDead3);
const mirrors = mirrorsOf(cfg).map(([i, d]) => onWall(CORR[i], DIRV[d], FACE));
const fakeDoors = decoyDead.filter(d => !mirrorCells.has(CI.get(K(d.cells[0]))) && d.length >= 2).slice(0, 8).map(d => onWall(d.cells[0], deepSide(d.cells[0]), CELL / 2));
const usedWall = (x, z) => [...mirrors, ...fakeDoors, relic1, relic3].some(p => d2([p.x, p.z], [x, z]) < 0.2);
const peeps = [];
{
  const cand = [];
  for (const [x, z] of CORR) for (const [dx, dz] of [[1, 0], [0, 1]]) {
    const n = [x + dx, z + dz]; if (!isCorr(...n) || cfg.st[EIDX.get(edgeKey([x, z], n))] !== 0) continue;
    const p = shortest(chk.adj[2], CI.get(key(x, z)), CI.get(K(n))); if (!p || p.length < 25) continue;
    cand.push({ x: r4((x + 0.5 + dx * 0.5) * CELL), z: r4((z + 0.5 + dz * 0.5) * CELL), ry: dx ? Math.PI / 2 : 0, dd: p.length });
  }
  cand.sort((p, q) => q.dd - p.dd);
  for (const p of cand) if (peeps.length < 4 && !peeps.some(q => d2([q.x, q.z], [p.x, p.z]) < 4)) peeps.push({ x: p.x, z: p.z, ry: p.ry });
}
const claws = [];
for (const d of deadSorted) { if (claws.length >= 3) break; const c = d.cells[Math.min(1, d.cells.length - 1)], [cx, cz] = center(c), cs = closedSides(c).filter(([dx, dz]) => !usedWall(cx + dx * FACE, cz + dz * FACE)); if (!cs.length) continue; claws.push(onWall(c, cs[0], FACE)); }
const bonesCell = (deadAt(1)[0] || deadSorted[deadSorted.length - 1]).cells[0];
const roots = [];
while (roots.length < 3) { let bc = null, bd = -1; for (const c of CORR) { const dm = roots.length ? Math.min(...roots.map(p => d2(center(c), p))) : -d2(center(c), center(GATE)); if (dm > bd) { bd = dm; bc = c; } } roots.push(center(bc)); }
const guide = (shortest(chk.adj[2], CI.get(K(relicDead3.cells[0])), cfg.doors.te.cell) || [cfg.doors.te.cell]).map(i => center(CORR[i]));
const simplify = pts => { const s = [pts[0]]; for (let i = 1; i < pts.length - 1; i++) { const [p, b, c] = [pts[i - 1], pts[i], pts[i + 1]]; if ((b[0] - p[0]) !== (c[0] - b[0]) || (b[1] - p[1]) !== (c[1] - b[1])) s.push(b); } s.push(pts[pts.length - 1]); return s; };
const demonPath = [paths.giam, paths.canh, paths.te].map(p => simplify(p.map(center)));
const symbols = new Map();
['giam', 'canh', 'te'].forEach((k, s) => {
  const p = paths[k]; let n = 0;
  for (let i = 1; i < p.length - 1; i++) {
    const outs = stageOut(s)(p[i]).filter(c => K(c) !== K(p[i - 1]));
    if (outs.length < 2) continue;
    const right = p[i + 1]; if (!symbols.has(K(right))) symbols.set(K(right), { cell: right, sym: SYMS[n % 4], ok: true });
    outs.filter(c => K(c) !== K(right)).forEach((c, j) => { if (!symbols.has(K(c))) symbols.set(K(c), { cell: c, sym: SYMS[(n + 2 + j) % 4], ok: false }); });
    n++;
  }
});
const SYMBOLS = [...symbols.values()].map(s => { const [x, z] = center(s.cell); return { x, z, sym: s.sym, ok: s.ok }; });
const plates = [];
for (const k of ORDER) {
  const p = paths[k], free = p.slice(2, -1).filter(c => !symbols.has(K(c)) && !isTarget(c)), straight = free.filter(c => deg.get(K(c)) === 2), mids = straight.length >= 2 ? straight : free;
  for (const c of [mids[Math.floor(mids.length * 0.35)], mids[Math.floor(mids.length * 0.7)]]) if (c && !plates.some(q => K(q) === K(c))) plates.push(c);
}
function backWall(box, door) {
  const [x1, z1, x2, z2] = box, cx = (x1 + x2) / 2, cz = (z1 + z2) / 2, eq = (a, b) => Math.abs(a - b) < 1e-6;
  const side = door.axis === 'z' ? (eq(door.x, x1) ? 'W' : 'E') : (eq(door.z, z1) ? 'N' : 'S');
  const back = { W: 'E', E: 'W', N: 'S', S: 'N' }[side];
  return { N: { o: [cx, z1], n: [0, 1], len: x2 - x1 }, S: { o: [cx, z2], n: [0, -1], len: x2 - x1 }, W: { o: [x1, cz], n: [1, 0], len: z2 - z1 }, E: { o: [x2, cz], n: [-1, 0], len: z2 - z1 } }[back];
}
const onBack = (box, door, u, v) => { const f = backWall(box, door), t = [f.n[1], -f.n[0]]; return [r2(f.o[0] + t[0] * u + f.n[0] * v), r2(f.o[1] + t[1] * u + f.n[1] * v)]; };
const roomBoxM = k => ROOM_BOX[k].map(v => v * CELL);
const roomLamps = [[2, SIZE - 0.25], [6.2, SIZE - 0.25]];
for (const k of ['te', 'giam', 'canh']) { const f = backWall(roomBoxM(k), cfg.doors[k]); roomLamps.push(onBack(roomBoxM(k), cfg.doors[k], -(f.len / 2 - 0.4), 0.25)); }
const lampCells = [];
while (lampCells.length < 7) { let bc = null, bd = -1; for (const c of CORR) { const dm = Math.min(...[...lampCells.map(center), ...roomLamps].map(p => d2(center(c), p))); if (dm > bd) { bd = dm; bc = c; } } lampCells.push(bc); }
const OIL = roomLamps.map(([x, z]) => [x, z, 1.7]).concat(lampCells.map(c => { const [dx, dz] = closedSides(c)[0] || [0, -1]; const [cx, cz] = center(c); return [r2(cx + dx * 0.28), r2(cz + dz * 0.28), 1.6]; }));
const teInside = onBack(roomBoxM('te'), cfg.doors.te, 0, 1.0);
const lockMid = l => [(l.a[0] + l.b[0]) / 2 + 0.5, (l.a[1] + l.b[1]) / 2 + 0.5].map(v => v * CELL);
const GREEN = [center(GATE), center(TARGETC.giam), center(TARGETC.canh), center(TARGETC.te), teInside, lockMid(locks[0])].map(([x, z]) => [r2(x), r2(z), 2.4]);
const low = CORR.filter(([, z]) => z >= 5), high = CORR.filter(([, z]) => z < 5);
const nearest = (cells, pt) => center(cells.slice().sort((p, q) => d2(center(p), pt) - d2(center(q), pt))[0]);
const centroid = cells => cells.reduce((s, c) => { const [x, z] = center(c); return [s[0] + x / cells.length, s[1] + z / cells.length]; }, [0, 0]);
const label3 = nearest(low, centroid(low)), label6 = nearest(high, centroid(high));
const firstStep = corrNbs(...GATE)[0], exitStep = corrNbs(...EXIT)[0];
const roomSpawn = k => { const box = roomBoxM(k), d = cfg.doors[k], f = backWall(box, d), [x1, z1, x2, z2] = box, inward = [-f.n[0], -f.n[1]]; const sx = r2(Math.min(x2 - 0.45, Math.max(x1 + 0.45, d.x - inward[0] * 0.7))), sz = r2(Math.min(z2 - 0.45, Math.max(z1 + 0.45, d.z - inward[1] * 0.7))); return { spawn: [sx, sz], look: onBack(box, d, 0, 0.3) }; };
const sTe = roomSpawn('te'), sGiam = roomSpawn('giam'), sCanh = roomSpawn('canh');
const roomCenter = k => { const [a, b, c, d] = roomBoxM(k); return [r2((a + c) / 2), r2((b + d) / 2)]; };
const reachCells = s => idxs(chk.R[s]).map(i => CORR[i]);
const GATE_AREA = [r4(GATE_X - 1.5), r4(GZ), r4(GATE_X + 1.5), r4(GZ + 1)];
const area = cells => r2(cells * CELL * CELL), cellsIn = ([a, b, c, d]) => (c - a) * (d - b);
// bản đồ nhiệt: số lần trung bình Julius đi qua mỗi ô trong 100 lượt
const heat = new Float64Array(CORR.length); for (const r of stats.res) for (const [, c] of r.trace) heat[c] += 1 / stats.res.length;
const HEAT = CORR.map((c, i) => [c[0], c[1], r2(heat[i])]);
const sampleRoute = simplify(medRun.trace.map(([, c]) => center(CORR[c])));

const fmt = v => JSON.stringify(v);
const src = `// SINH TỰ ĐỘNG bởi tools/gen-maze.mjs (seed ${seed}) — sửa generator rồi chạy lại, đừng sửa tay.
// Hệ tọa độ: gốc góc trái-trên, x sang phải, z xuống dưới, mét. Lưới 12 × 12 ô vuông CELL = 11/12 m.
// Dữ liệu đồ thị (LOCKS, ONEWAY, SHIFTS, STAGES, STAGE_REACH, MAZE.gate/rooms/exit) tính bằng ô; nhân CELL ra mét.
// Thanh tra Julius 100 lượt: nhanh nhất ${mmss(stats.best)}, p10 ${mmss(stats.p10)}, trung vị ${mmss(stats.median)} (mốc: cả 100 lượt >= ${mmss(TARGET)}: ${pass ? 'ĐẠT' : 'CHƯA ĐẠT'}).
// Đường đúng: Giam ${lens.giam} ô, Người canh ${lens.canh} ô, Tế ${lens.te} ô, ra cửa thoát ${lens.exit} ô.
// ${oneways.length} cửa một chiều, 2 tường xoay, ${mirrors.length} gương, ${fakeDoors.length} cửa giả, ${deadBranches.length} ngõ cụt.
export const WALL_THICKNESS = 0.16;
export const WALL_HEIGHT = 3.0;
export const ROOM_SIZE = ${SIZE};
export const CELL = ${CELL};
export const GRID = { cols: ${COLS}, rows: ${ROWS} };
export const DOOR_WIDTH = 0.66;
export const DOOR_HEIGHT = 2.1;

// [x1, z1, x2, z2] — đoạn tường cố định (mét). Lỗ mở 1 ô tại cửa phòng, khóa, cửa một chiều và chỗ tường xoay đã chừa sẵn.
export const WALLS = [
${WALLS_M.map(w => '  ' + fmt(w) + ',').join('\n')}
];

// Phòng [x1, z1, x2, z2] (mét): 0 Làng, 1 Tế thần, 2 Giam Vọng Âm, 3 Người canh ấn
export const ROOMS = ${fmt(ROOMS_M)};

// (x, z) tâm cửa (mét); axis: trục mà khoảng mở chạy dọc ('x' = cửa trên tường ngang); swing: chiều mở cánh sắt
export const DOORS = [
${DOORS.map(d => `  { id: '${d.id}', x: ${d.x}, z: ${d.z}, axis: '${d.axis}', kind: '${d.kind}'${d.swing ? `, swing: ${d.swing}` : ''} },`).join('\n')}
];

// Khóa tuần tự giữa hai ô a–b: kind 'gate' = cổng sắt có ổ khóa, 'hidden' = tường đá trượt không khung cửa
export const LOCKS = [
${locks.map(l => `  { id: '${l.id}', a: ${fmt(l.a)}, b: ${fmt(l.b)}, after: '${l.after}', room: '${l.room}', kind: '${l.kind}' },`).join('\n')}
];

// Cửa một chiều (cánh lò xo, chỉ đẩy được từ ô 'from' sang ô 'to')
export const ONEWAY = [
${oneways.map(o => `  { from: ${fmt(o.from)}, to: ${fmt(o.to)} },`).join('\n')}
];

// Tường xoay (đơn vị ô): tấm 1 ô quay 90° quanh trụ 'post' khi khóa 'at' mở. Trước: đoạn 'before' (chặn hai ô 'freed');
// sau: đoạn 'after' (chặn hai ô 'shut').
export const SHIFTS = [
${shifts.map(s => `  { id: '${s.id}', at: '${s.at}', post: ${fmt(s.post)}, before: ${fmt(s.before)}, after: ${fmt(s.after)}, freed: ${fmt(s.freed)}, shut: ${fmt(s.shut)} },`).join('\n')}
];

// Trạng thái tiến độ: closed = các cặp ô đang bị khóa hoặc tường xoay chặn. Cửa thoát C06 mở sau khi xong Tế thần.
export const STAGES = [
  { id: 's0', open: [], label: 'Vào mê cung', goal: 'giam', from: 'gate', closed: ${fmt(closedList(0))} },
  { id: 's1', open: ['L1'], label: 'Xong Giam Vọng Âm', goal: 'canh', from: 'giam', closed: ${fmt(closedList(1))} },
  { id: 's2', open: ['L1', 'L2'], label: 'Xong Người canh ấn', goal: 'te', from: 'canh', closed: ${fmt(closedList(2))} },
  { id: 's3', open: ['L1', 'L2'], label: 'Xong Tế thần — mở cửa thoát', goal: 'exit', from: 'te', closed: ${fmt(closedList(3))} },
];
export const STAGE_REACH = { s0: ${fmt(reachCells(0))}, s1: ${fmt(reachCells(1))}, s2: ${fmt(reachCells(2))} };
export const ROUTE_LEN = ${fmt(lens)};

// Báo cáo thanh tra Julius (giây). legMed: trung vị từng chặng; rounds: lịch sử nâng cấp; heat: [x, z, lượt qua ô trung bình].
export const JULIUS_REPORT = ${fmt({ params: JULIUS, runs: stats.res.length, target: TARGET, pass, best: Math.round(stats.best), p10: Math.round(stats.p10), median: Math.round(stats.median), worst: Math.round(stats.worst), legMed: stats.legMed.map(Math.round), rounds, heat: HEAT, sampleTime: Math.round(medRun.time), sampleRoute })};

// Ô cổng mê cung, ô cửa thoát và ô hành lang trước cửa mỗi phòng (đơn vị ô)
export const MAZE = {
  gate: ${fmt(GATE)},
  exit: ${fmt(EXIT)},
  depth: ${ROWS},
  rooms: ${fmt(TARGETC)},
  roomBoxes: { te: ${fmt(roomBoxM('te').map(r4))}, giam: ${fmt(roomBoxM('giam').map(r4))}, canh: ${fmt(roomBoxM('canh').map(r4))} },
  roomCells: ${fmt({ ...ROOM_BOX, lang: VILLAGE })},
  roomDoors: { te: '${ROOM_DOOR.te.id}', giam: '${ROOM_DOOR.giam.id}', canh: '${ROOM_DOOR.canh.id}' },
};

// Thứ tự quan trọng: zoneAt trả khu đầu tiên chứa điểm. Khu 6 là khu bắt tất cả.
export const ZONES = [
  { id: 2, name: 'Cổng mê cung', boxes: [${fmt(GATE_AREA)}], spawn: [${GATE_X}, ${r2(GZ + 0.6)}], look: [${GATE_X}, ${r2(GZ - 0.5)}], desc: 'Hai gương đá của người canh giữ. Một tiếng kim loại rơi.' },
  { id: 1, name: 'Làng · Nghi thức xin đường', boxes: [${fmt(ROOMS_M[0])}], spawn: [1, ${r2(C01_Z)}], look: [5, ${r2(C01_Z)}], desc: 'Thứ tự Giếng, Ruộng, Kho, Miếu là chìa khóa đọc mê cung.' },
  { id: 7, name: 'Tế thần', boxes: [${fmt(ROOMS_M[1])}], spawn: ${fmt(sTe.spawn)}, look: ${fmt(sTe.look)}, desc: 'Vòng phong ấn, bàn tế, trống.' },
  { id: 4, name: 'Giam Vọng Âm', boxes: [${fmt(ROOMS_M[2])}], spawn: ${fmt(sGiam.spawn)}, look: ${fmt(sGiam.look)}, desc: 'Giải xong căn phòng này, cổng sắt L1 mới mở — và tường X1 xoay.' },
  { id: 5, name: 'Phòng người canh ấn', boxes: [${fmt(ROOMS_M[3])}], spawn: ${fmt(sCanh.spawn)}, look: ${fmt(sCanh.look)}, desc: 'Ghi chép ở đây mở bức tường ẩn L2 — và tường X2 xoay.' },
  { id: 3, name: 'Mê cung ngoài', boxes: ${fmt(low.map(([x, z]) => [r4(x * CELL), r4(z * CELL), r4((x + 1) * CELL), r4((z + 1) * CELL)]))}, spawn: ${fmt(center(GATE))}, look: ${fmt(center(firstStep))}, desc: 'Hành lang rẽ liên tục, ngõ cụt sâu. Chỉ ký hiệu dưới chân là thật.' },
  { id: 6, name: 'Mê cung trong', boxes: [[0, 0, ${SIZE}, ${SIZE}]], spawn: ${fmt(center(EXIT))}, look: ${fmt(center(exitStep))}, desc: 'Cửa một chiều, tường xoay. Đường đã thuộc sẽ bị chặn.' },
];

export function zoneAt(x, z) {
  return ZONES.find(zn => zn.boxes.some(([x1, z1, x2, z2]) => x >= x1 && x < x2 && z >= z1 && z < z2)) || null;
}

export const ZONE_AREA = { 1: ${r2(area(27) - 3)}, 2: 3, 7: ${area(cellsIn(ROOM_BOX.te))}, 4: ${area(cellsIn(ROOM_BOX.giam))}, 5: ${area(cellsIn(ROOM_BOX.canh))}, 3: ${area(low.length)}, 6: ${area(high.length)} };

// Ba đoạn tuần tra của quỷ (mét): theo đường đúng của từng chặng (cổng -> Giam -> Người canh -> Tế).
export const DEMON_PATH = [
${demonPath.map(p => '  ' + fmt(p) + ',').join('\n')}
];

export const LABEL_POS = { 1: [5.8, ${r2(GZ + 1.6)}], 2: [${GATE_X}, ${r2(GZ + 0.6)}], 3: ${fmt(label3)}, 4: ${fmt(roomCenter('giam'))}, 5: ${fmt(roomCenter('canh'))}, 6: ${fmt(label6)}, 7: ${fmt(roomCenter('te'))} };

// Đèn: [x, z, y]. ${OIL.length} đèn dầu + ${GREEN.length} đèn ma xanh (+ 2 nến trong props = 20).
export const OIL = ${fmt(OIL)};
export const GREEN = ${fmt(GREEN)};

// Điểm đặt đạo cụ (mét). mirrors: gương mica cuối ngõ cụt thẳng (trông như hành lang chạy tiếp).
export const POI = {
  relic1: ${fmt(relic1)},
  relic3: ${fmt(relic3)},
  fakeDoors: ${fmt(fakeDoors)},
  mirrors: ${fmt(mirrors)},
  symbols: ${fmt(SYMBOLS)},
  plates: ${fmt(plates.map(center))},
  peeps: ${fmt(peeps)},
  claws: ${fmt(claws)},
  bones: ${fmt(center(bonesCell))},
  roots: ${fmt(roots)},
  guide: ${fmt(guide)},
};
`;
const out = fileURLToPath(new URL('../src/layout.js', import.meta.url));
writeFileSync(out, src);
console.log(`đã ghi ${out} (${WALLS_M.length} đoạn tường)`);

// bản đồ ASCII (đơn vị ô): G = cổng, E = ô cửa thoát, chữ phòng t/g/c, D = ngõ cụt, # khóa, > một chiều, X tường xoay
const lockE = new Set(cfg.locks.map(e => edgeKey(...cellsOf(e)))), owE = new Set(oneways.map(o => edgeKey(o.from, o.to)));
const shE = new Set(cfg.shifts.flatMap(o => [SHIFT_OPTS[o].e1, SHIFT_OPTS[o].e2]).map(e => edgeKey(...cellsOf(e))));
const mark = (p, q, wall) => wall ? null : lockE.has(edgeKey(p, q)) ? '#' : shE.has(edgeKey(p, q)) ? 'X' : owE.has(edgeKey(p, q)) ? '>' : null;
let g = '';
for (let zz = 0; zz <= 2 * ROWS; zz++) {
  let row = '';
  for (let xx = 0; xx <= 2 * COLS; xx++) {
    const x = Math.floor(xx / 2), z = Math.floor(zz / 2);
    if (xx % 2 === 0 && zz % 2 === 0) row += '+';
    else if (zz % 2 === 0) { const mk = mark([x, z - 1], [x, z], Hs.has(key(x, z))); row += Hs.has(key(x, z)) ? '--' : mk ? mk + mk : '  '; }
    else if (xx % 2 === 0) { const mk = mark([x - 1, z], [x, z], Vs.has(key(x, z))); row += Vs.has(key(x, z)) ? '|' : mk || ' '; }
    else { const rk = roomOfCell(x, z); row += K([x, z]) === K(GATE) ? ' G' : K([x, z]) === K(EXIT) ? ' E' : rk ? ' ' + rk[0] : deg.get(key(x, z)) === 1 ? ' D' : '  '; }
  }
  g += row + '\n';
}
console.log(g);
