from pathlib import Path
import sys, re, json, unicodedata, hashlib
import pymupdf

root=Path(__file__).resolve().parents[1]
stem='HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P'
preview=Path(sys.argv[1])
document=pymupdf.open(preview/(stem+'.pdf'))
text=unicodedata.normalize('NFC','\n'.join(page.get_text() for page in document))
for prefix,count in [('OW',22),('W',51)]:
    for n in range(1,count+1):assert f'{prefix}{n:02d}' in text
compact=re.sub(r'\s+','',text)
assert 'QuỷMù' in compact and 'nhảkhẩn' in compact
assert '\ufffd' not in text
for page in document:
    for b in page.get_text('blocks'):
        assert b[0]>=35 and b[2]<=page.rect.width-35
log=(preview/(stem+'.log')).read_text(encoding='utf-8',errors='replace')
assert not re.search(r'Missing character:|Overfull \\[hv]box|^! ',log,re.M)
report={'status':'PASS_LATEX_COMPILE_AND_LAYOUT','engine':'Tectonic 0.17.0 / XeTeX',
        'pages':len(document),'coordinateCodes':{'oneWay':22,'walls':51},
        'vietnameseText':'PASS','missingGlyphs':0,'overfullBoxes':0,
        'sourceSHA256':hashlib.sha256((root/(stem+'.tex')).read_bytes()).hexdigest(),
        'note':'The Markdown remains the editorial source; the standalone .tex is the published construction guide.'}
(root/'latex-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
