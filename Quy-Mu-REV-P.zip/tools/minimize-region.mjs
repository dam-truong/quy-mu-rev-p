import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as C from './core.mjs';
import {simulate,restore,serialize} from './optimize.mjs';
const root=new URL('../',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root))),write=(p,v)=>fs.writeFileSync(new URL(p,root),JSON.stringify(v,null,2));
const selected=read('iterations/final-selected.json'),base=read('baseline/config-O.json').cfg,settings=read('config.json');let best=restore(selected.cfg);
const dist=([x,z])=>Math.max(4-x,0,x-7)+Math.max(5-z,0,z-8),radii=C.EDGES.map(([a,b])=>Math.max(dist(C.CORR[a]),dist(C.CORR[b])));
const three=[5,6,7].map(x=>C.EDGES.findIndex((_,e)=>C.segOf(e).join(',')===[x,6,x,7].join(',')));
const redesigned=c=>three.filter(e=>c.st[e]!==0).length>=2&&C.EDGES.some((_,e)=>radii[e]===0&&C.segOf(e)[1]===C.segOf(e)[3]&&base.st[e]!==0&&c.st[e]===0);
const panelEdges=read('baseline/emergency-O.json').panels.map(p=>C.EIDX.get([p.a.join(','),p.b.join(',')].sort().join('|')));
function safe(c){if(panelEdges.some(e=>c.st[e]!==0))return false;for(let s=0;s<3;s++){const closed=new Set([...C.closedAt(c,s),...C.closedAt(c,s+1)]),adj=C.CORR.map(()=>[]);C.EDGES.forEach(([a,b],e)=>{if((c.st[e]&&!closed.has(e))||panelEdges.includes(e)){adj[a].push(b);adj[b].push(a);}});const seen=new Set([C.G]),q=[C.G];for(let i=0;i<q.length;i++)for(const v of adj[q[i]])if(!seen.has(v)){seen.add(v);q.push(v);}const g=C.adjOf(c,s),old=new Set([C.G]),p=[C.G];for(let i=0;i<p.length;i++)for(const v of g[p[i]])if(!old.has(v)){old.add(v);p.push(v);}if([...old].some(v=>!seen.has(v)))return false;}return true;}
const evaluate=c=>{if([...c.st].filter(v=>v>=2).length!==22||!redesigned(c)||!C.check(c)||!safe(c))return null;const graphs=[0,1,2,3].map(s=>C.adjOf(c,s)),values=Array.from({length:24},(_,i)=>simulate(c,i,graphs).steps),min=Math.min(...values);return {min,values,mean:values.reduce((a,b)=>a+b)/24,minSeconds:min*C.CELL/1.2};};
const trials=[];
write('iterations/accepted-before-region-check.json',selected);
for(let ring=0;ring<=selected.ring;ring++){
 const c={...best,st:best.st.slice(),shifts:best.shifts.slice(),locks:best.locks.slice()};for(let e=0;e<c.st.length;e++)if(radii[e]>ring)c.st[e]=base.st[e];
 c.shifts.forEach((v,i)=>{if([v,base.shifts[i]].some(o=>[C.SHIFT_OPTS[o].e1,C.SHIFT_OPTS[o].e2].some(e=>radii[e]>ring)))c.shifts[i]=base.shifts[i];});
 c.locks.forEach((v,i)=>{if(radii[v]>ring||radii[base.locks[i]]>ring)c.locks[i]=base.locks[i];});
 const v=evaluate(c);trials.push({ring,valid:!!v,minimumSeconds:v?.minSeconds??null});
 if(v&&v.minSeconds>settings.thresholdSeconds){best=c;break;}
}
const changed=[...best.st].flatMap((v,e)=>v!==base.st[e]?[e]:[]),ring=Math.max(...changed.map(e=>radii[e])),evaluation=evaluate(best);assert.ok(evaluation.minSeconds>settings.thresholdSeconds);
write('iterations/final-selected.json',{...selected,cfg:serialize(best),ring,evaluation,changedEdges:changed,changedCells:[...new Set(changed.flatMap(e=>C.cellsOf(e).map(c=>c.join(','))))]});
write('iterations/region-at-600.json',{thresholdSeconds:settings.thresholdSeconds,method:'Restore all edges outside each smaller ring to REV O; validate unchanged mechanism count, shape, return paths and sweep release. This is a bounded subset check, not a global minimality proof.',trials,selectedRing:ring,minimumSeconds:evaluation.minSeconds});console.log({ring,minimumSeconds:evaluation.minSeconds,trials});
