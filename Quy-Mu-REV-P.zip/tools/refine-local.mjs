import fs from 'node:fs';
import * as C from './core.mjs';
import {simulate,restore,serialize} from './optimize.mjs';
const root=new URL('../',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root))),settings=read('config.json'),base=read('baseline/config-O.json').cfg;
const seed=read('iterations/final-selected.json'),rnd=C.mulberry32(170026),pick=a=>a[Math.floor(rnd()*a.length)];
let best=restore(seed.cfg);const special=new Set([...best.locks,...best.shifts.flatMap(i=>[C.SHIFT_OPTS[i].e1,C.SHIFT_OPTS[i].e2])]);
const distance=([x,z])=>Math.max(4-x,0,x-7)+Math.max(5-z,0,z-8),radii=C.EDGES.map(([a,b])=>Math.max(distance(C.CORR[a]),distance(C.CORR[b])));
const panels=read('baseline/emergency-O.json').panels,panelEdges=panels.map(p=>C.EIDX.get([p.a.join(','),p.b.join(',')].sort().join('|')));
panelEdges.forEach(e=>special.add(e));
const three=[5,6,7].map(x=>C.EDGES.findIndex((_,e)=>C.segOf(e).join(',')===[x,6,x,7].join(',')));
const shape=c=>three.filter(e=>c.st[e]!==0).length>=2&&C.EDGES.some((_,e)=>radii[e]===0&&C.segOf(e)[1]===C.segOf(e)[3]&&base.st[e]!==0&&c.st[e]===0);
const evalCfg=c=>{const graphs=[0,1,2,3].map(s=>C.adjOf(c,s)),values=Array.from({length:24},(_,i)=>simulate(c,i,graphs).steps),min=Math.min(...values),mean=values.reduce((a,b)=>a+b)/24;return {values,min,mean,score:min+.05*mean,minSeconds:min*C.CELL/1.2};};
function safe(c){for(let s=0;s<3;s++){const closed=new Set([...C.closedAt(c,s),...C.closedAt(c,s+1)]),adj=C.CORR.map(()=>[]);C.EDGES.forEach(([a,b],e)=>{if((c.st[e]&&!closed.has(e))||panelEdges.includes(e)){adj[a].push(b);adj[b].push(a);}});const seen=new Set([C.G]),q=[C.G];for(let i=0;i<q.length;i++)for(const v of adj[q[i]])if(!seen.has(v)){seen.add(v);q.push(v);}const g=C.adjOf(c,s),old=new Set([C.G]),p=[C.G];for(let i=0;i<p.length;i++)for(const v of g[p[i]])if(!old.has(v)){old.add(v);p.push(v);}if([...old].some(v=>!seen.has(v)))return false;}return true;}
let be=evalCfg(best);const report={seed:170026,initial:be,rings:[],purpose:'Additional shape-preserving search; no mechanism relocation in this pass.'};
const save=ring=>{fs.writeFileSync(new URL('iterations/refined-best.json',root),JSON.stringify({seed:170026,ring,cfg:serialize(best),evaluation:be},null,2));fs.writeFileSync(new URL('iterations/refinement-report.json',root),JSON.stringify(report,null,2));};
for(let ring=0;ring<=9;ring++){
 const allowed=C.EDGES.map((_,e)=>e).filter(e=>radii[e]<=ring&&!special.has(e)),cache=new Map(),start=Date.now();let cur=best,ev=be,it=0,evaluated=0;const r={ring,startingSeconds:be.minSeconds,bestMinimumSeconds:be.minSeconds};report.rings.push(r);
 while(Date.now()-start<30000){it++;if(it%2000===0){cur=best;ev=be;}const c={...cur,st:cur.st.slice()},a=pick(allowed),b=pick(allowed),q=rnd();
  if(q<.6)[c.st[a],c.st[b]]=[c.st[b],c.st[a]];else if(c.st[a]>=2)c.st[a]=5-c.st[a];else c.st[a]=1-c.st[a];
  if(!shape(c)||!C.check(c)||!safe(c))continue;
  const key=[...c.st].join(',');let v=cache.get(key);if(!v){v=evalCfg(c);cache.set(key,v);evaluated++;}if(!v.min)continue;
  const temp=.3+8*(1-(it%2000)/2000);if(v.score>=ev.score||rnd()<Math.exp((v.score-ev.score)/temp)){cur=c;ev=v;}
  if(v.min>be.min||(v.min===be.min&&v.mean>be.mean)){best=c;be=v;r.bestMinimumSeconds=be.minSeconds;save(ring);console.log(JSON.stringify({ring,it,minSeconds:be.minSeconds}));}
  if(be.minSeconds>=settings.thresholdSeconds)break;
 }
 r.iterations=it;r.evaluated=evaluated;r.elapsedSeconds=(Date.now()-start)/1000;save(ring);console.log(JSON.stringify({ringComplete:r}));if(be.minSeconds>=settings.thresholdSeconds)break;
}
