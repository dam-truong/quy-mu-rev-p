import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import * as L from '../src/layout.js';
import * as O from '../baseline/layout-O.js';
import * as C from './core.mjs';
import {restore} from './optimize.mjs';
import {buildEnvironment} from '../julius/audit-layout.mjs';
const root=new URL('../',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root)));
const choice=read('iterations/final-selected.json'),cfg=restore(choice.cfg),base=read('baseline/config-O.json').cfg,env=buildEnvironment(L);
for(const key of ['ROOM_SIZE','CELL','GRID','WALL_THICKNESS','WALL_HEIGHT','DOOR_WIDTH','DOOR_HEIGHT','ROOMS','DOORS'])assert.deepEqual(L[key],O[key],key+' must stay unchanged');
assert.deepEqual(L.MAZE,O.MAZE);assert.equal(L.ONEWAY.length,O.ONEWAY.length);assert.equal(L.SHIFTS.length,O.SHIFTS.length);assert.equal(L.LOCKS.length,O.LOCKS.length);
const changed=C.EDGES.flatMap((_,e)=>cfg.st[e]!==base.st[e]?[{edge:e,segment:C.segOf(e),from:base.st[e],to:cfg.st[e]}]:[]);
const distance=([x,z])=>Math.max(4-x,0,x-7)+Math.max(5-z,0,z-8);
for(const change of changed)assert.ok(C.cellsOf(change.edge).every(c=>distance(c)<=choice.ring),'Change escaped chosen search ring');
for(let i=0;i<cfg.shifts.length;i++)if(cfg.shifts[i]!==base.shifts[i])for(const o of [cfg.shifts[i],base.shifts[i]])for(const e of [C.SHIFT_OPTS[o].e1,C.SHIFT_OPTS[o].e2])assert.ok(C.cellsOf(e).every(c=>distance(c)<=choice.ring));
for(let i=0;i<cfg.locks.length;i++)if(cfg.locks[i]!==base.locks[i])for(const e of [cfg.locks[i],base.locks[i]])assert.ok(C.cellsOf(e).every(c=>distance(c)<=choice.ring));
const safety=read('emergency-plan.json');assert.deepEqual(safety.panels,read('baseline/emergency-O.json').panels);assert.ok(safety.validation.every(v=>v.duringConservativeSweep.trapped.length===0));
const pointDistance=(x,z,[a,b,c,d])=>{const dx=c-a,dz=d-b,t=Math.max(0,Math.min(1,((x-a)*dx+(z-b)*dz)/(dx*dx+dz*dz)));return Math.hypot(x-a-t*dx,z-b-t*dz);};
let marks=0,minClearance=Infinity;
for(let s=0;s<4;s++){
 const seg=([a,b])=>a[0]!==b[0]?[Math.max(a[0],b[0]),a[1],Math.max(a[0],b[0]),a[1]+1]:[a[0],Math.max(a[1],b[1]),a[0]+1,Math.max(a[1],b[1])];
 const walls=[...L.WALLS,...L.STAGES[s].closed.map(p=>seg(p).map(v=>v*L.CELL))];
 for(const m of L.GUIDE_STAGES[s].marks){marks++;assert.ok(env.graphs[s].get(m.from).includes(m.to));for(const wall of walls){const d=pointDistance(m.x,m.z,wall)-L.WALL_THICKNESS/2;minClearance=Math.min(minClearance,d);assert.ok(d>=.12-1e-4,'Floor symbol square intersects wall');}}
}
const hash=crypto.createHash('sha256').update(fs.readFileSync(new URL('src/layout.js',root))).digest('hex');
const out={status:'PASS_CONSTRAINTS',sourceSHA256:hash,retainedRoomsDoorsFootprintAndWidths:true,oneWayDoors:L.ONEWAY.length,rotatingWalls:L.SHIFTS.length,locks:L.LOCKS.length,retainedEmergencyPanels:safety.panelCount,changedEdges:changed,selectedSearchRing:choice.ring,guideMarks:marks,minimumSymbolCenterToWallFaceMeters:minClearance,allGuideSquaresClear:true};fs.writeFileSync(new URL('constraint-validation.json',root),JSON.stringify(out,null,2));console.log(JSON.stringify({status:out.status,changedEdges:changed.length,guideMarks:marks,minClearance}));
