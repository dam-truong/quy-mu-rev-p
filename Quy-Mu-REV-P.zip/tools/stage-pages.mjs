import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),destination=process.argv[2];if(!destination)throw Error('Provide a new isolated publishing folder');
const report=JSON.parse(fs.readFileSync(root+'julius/final/report.json'));assert.equal(report.status,'PASS_SIMULATION_GATE');assert.ok(report.minimumSeconds>report.thresholdSeconds);
fs.mkdirSync(destination,{recursive:true});
const top=['HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.md','index.html','model-360.html','HUONG-DAN.html','Quy-Mu-REV-P.zip','DELIVERY.json','config.json','emergency-plan.json','wall-followers.json','guide-validation.json','constraint-validation.json','render-validation.json','browser-validation.json','math-analysis.json',...[0,1,2,3].map(s=>`Quy-Mu-REV-P-S${s}.glb`)];
for(const f of top)fs.copyFileSync(root+f,path.join(destination,f));
for(const dir of ['blueprint','previews','julius/final','iterations']){
 fs.mkdirSync(path.join(destination,dir),{recursive:true});
 const copy=(relative)=>{for(const e of fs.readdirSync(root+relative,{withFileTypes:true})){const p=path.join(relative,e.name);if(e.isDirectory()){fs.mkdirSync(path.join(destination,p),{recursive:true});copy(p);}else if(/\.(png|svg|html|json|jsonl|js)$/.test(p))fs.copyFileSync(root+p,path.join(destination,p));}};copy(dir);
}
fs.mkdirSync(path.join(destination,'src'),{recursive:true});fs.copyFileSync(root+'src/layout.js',path.join(destination,'src/layout.js'));
fs.writeFileSync(path.join(destination,'.nojekyll'),'');
fs.writeFileSync(path.join(destination,'README.md'),'# Quỷ Mù — REV P\n\nStatic review and downloads. Accepted simulation threshold: 600 seconds at 1.2 m/s, with no added waiting or puzzle time. Fastest of all 24 direction orders: '+report.minimumSeconds.toFixed(2)+' seconds.\n\n[Viewer](https://dam-truong.github.io/quy-mu-rev-p/) · [Hướng dẫn thi công và cơ chế cửa](HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.md) · [Báo cáo](HUONG-DAN.html).\n');
const files=[];const walk=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else files.push(p);}};walk(destination);
const checked=[];
for(const file of files.filter(f=>f.endsWith('.html')&&!f.endsWith('render-sheet.html'))){const html=fs.readFileSync(file,'utf8').split('<script>')[0];for(const m of html.matchAll(/(?:href|src)="([^"#]+)"/g)){const link=m[1];if(/^(data:|https?:|mailto:)/.test(link))continue;const target=path.resolve(path.dirname(file),decodeURIComponent(link.split(/[?#]/)[0]));assert.ok(fs.existsSync(target),`Broken link ${file}: ${link}`);checked.push({from:path.relative(destination,file),link});}}
fs.writeFileSync(path.join(destination,'links-validation.json'),JSON.stringify({status:'PASS',checked:checked.length,links:checked},null,2));
console.log(JSON.stringify({destination,files:files.length,bytes:files.reduce((n,p)=>n+fs.statSync(p).size,0),checkedLinks:checked.length}));
