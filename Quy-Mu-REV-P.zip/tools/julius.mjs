// Julius — thanh tra mê cung. Mô phỏng một người chơi giỏi đi một mình trong mê cung tối:
//   - không biết cốt truyện, không đọc ký hiệu sàn; thời gian giải đố trong phòng tính bằng 0;
//   - nhìn được ô đang đứng và dọc hành lang thẳng tới LOS ô (đèn pin); thấy cửa phòng; tường ẩn / cửa thoát ẩn trông như tường;
//   - gương cuối ngõ cụt (mz.mirror) nhìn từ xa >= 2 ô trông như hành lang chạy tiếp; phải tới sát mới biết là gương;
//   - nhớ mọi thứ đã thấy, luôn đi tới chỗ chưa khám phá gần nhất (chiến thuật mạnh hơn người thường);
//   - không biết trước cửa một chiều (chỉ biết khi đẩy ngược bị kẹt) và tường xoay / tường ẩn (chỉ biết khi nhìn lại);
//   - giải xong phòng thì quay lại kiểm tra các cổng sắt đã thấy; hết chỗ mới thì đi soát lại chỗ nhìn lâu nhất.
// Mê cung nhận vào (mz): n ô, nb[i*4+d] ô kề theo hướng d (B, Đ, N, T) hoặc -1,
// look[s][i*4+d] hình dạng mặt d của ô i ở giai đoạn s, pass[s][i*4+d] đi qua được không,
// gate, exit, roomAt[i] (khóa phòng có cửa ở ô i), order, cell (m), name(i) tên ô.
export const LOOK = { WALL: 1, OPEN: 2, GATE: 3, BLOCKED: 4, ROOM: 5, EXIT: 6 };
export const JULIUS = { speed: 0.6, junction: 3, revisit: 1, deadEnd: 2, blocked: 3, los: 5, cap: 5400 };
const DIR_NAME = ['Bắc', 'Đông', 'Nam', 'Tây'];
const ROOM_NAME = { giam: 'Giam Vọng Âm', canh: 'Người canh ấn', te: 'Tế thần' };

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const mmss = t => `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

export function runJulius(mz, seed, { log = false } = {}) {
  const P = JULIUS, rnd = mulberry32(seed), n = mz.n;
  const near = new Uint8Array(n * 4), know = new Uint8Array(n * 4), seenAt = new Float64Array(n).fill(-1), visits = new Uint16Array(n);
  const legs = [], lines = [], trace = [];          // trace: [chặng, ô] mỗi bước — để tìm khúc dễ
  let stage = 0, cur = mz.gate, t = 0, mode = '';
  const say = msg => { if (log) lines.push(`[${mmss(t)}] ${msg}`); };
  const observeCell = (i, far = -1) => {      // far = hướng nhìn nếu đang nhìn từ xa >= 2 ô
    const base = i * 4, lk = mz.look[stage];
    for (let d = 0; d < 4; d++) {
      if (far < 0) near[base + d] = 1;                                   // đã nhìn gần: không bị gương lừa nữa
      const v = far === d && mz.mirror[base + d] && !near[base + d] ? LOOK.OPEN : lk[base + d];
      if (!(know[base + d] === LOOK.BLOCKED && v === LOOK.OPEN)) know[base + d] = v;
    }
    seenAt[i] = t;
  };
  const observe = () => {
    observeCell(cur);
    for (let d = 0; d < 4; d++) {
      let i = cur;
      for (let k = 0; k < P.los; k++) { if (mz.look[stage][i * 4 + d] !== LOOK.OPEN) break; i = mz.nb[i * 4 + d]; observeCell(i, k >= 1 ? d : -1); }
    }
  };
  const dist = new Int16Array(n), prev = new Int16Array(n), q = new Int16Array(n);
  const bfs = () => {
    dist.fill(-1); dist[cur] = 0; prev[cur] = -1; let h = 0, tl = 0; q[tl++] = cur;
    while (h < tl) {
      const c = q[h++];
      for (let d = 0; d < 4; d++) { if (know[c * 4 + d] !== LOOK.OPEN) continue; const m = mz.nb[c * 4 + d]; if (m < 0 || dist[m] >= 0) continue; dist[m] = dist[c] + 1; prev[m] = c; q[tl++] = m; }
    }
  };
  const pickMin = (ok, key) => { let best = -1, bk = Infinity, ties = 0; for (let j = 0; j < n; j++) { if (dist[j] < 0 || !ok(j)) continue; const k = key(j); if (k < bk) { bk = k; best = j; ties = 1; } else if (k === bk && rnd() * ++ties < 1) best = j; } return best; };
  const openSides = i => { let c = 0; for (let d = 0; d < 4; d++) { const v = know[i * 4 + d]; if (v === LOOK.OPEN || v === LOOK.BLOCKED) c++; } return c; };

  observe(); visits[cur] = 1;
  say(`Julius bước qua cổng mê cung, đứng ở ${mz.name(cur)}.`);
  while (t < P.cap) {
    const rk = mz.roomAt[cur];
    if (rk && rk === mz.order[stage]) {
      legs.push(t); say(`Tìm thấy cửa phòng ${ROOM_NAME[rk]} ở ${mz.name(cur)}. Giải đố (không tính giờ).`);
      stage++;
      for (let j = 0; j < n * 4; j++) if (know[j] === LOOK.GATE) know[j] = 0;   // cổng sắt đã thấy có thể đã mở: đánh dấu cần xem lại
      observe(); mode = '';
      if (stage === 3) say('Cửa thoát đã mở ở đâu đó.');
      continue;
    }
    if (stage === 3 && cur === mz.exit) { legs.push(t); say(`Ra tới cửa thoát ở ${mz.name(cur)}. Xong mê cung.`); break; }
    bfs();
    let target = -1, nextMode;
    {
      let bd = Infinity;
      for (const k of mz.order) { if (k !== mz.order[stage]) continue; const r = mz.rooms[k]; if (know[r.cell * 4 + r.dir] === LOOK.ROOM && dist[r.cell] >= 0 && dist[r.cell] < bd) { bd = dist[r.cell]; target = r.cell; } }
      if (stage === 3 && know[mz.exit * 4 + mz.exitDir] === LOOK.EXIT && dist[mz.exit] >= 0) target = mz.exit;
      if (target >= 0) nextMode = 'goal';
    }
    if (target < 0) {
      target = pickMin(j => { for (let d = 0; d < 4; d++) { const v = know[j * 4 + d]; if (v === 0) return true; if (v === LOOK.OPEN && (mz.nb[j * 4 + d] < 0 || seenAt[mz.nb[j * 4 + d]] < 0)) return true; } return false; }, j => dist[j]);
      if (target >= 0) nextMode = 'explore';
    }
    if (target < 0) { target = pickMin(j => j !== cur, j => seenAt[j]); nextMode = 'search'; }
    if (nextMode !== mode) {
      if (nextMode === 'search') say('Hết chỗ mới để khám phá. Đi soát lại những chỗ đã lâu không nhìn.');
      if (nextMode === 'goal' && mode !== 'goal') say(`Đã biết đường tới ${stage === 3 ? 'cửa thoát' : 'cửa phòng ' + ROOM_NAME[mz.order[stage]]}, đi thẳng tới đó.`);
      mode = nextMode;
    }
    if (target === cur || target < 0) { observeCell(cur); t += 1; continue; }
    let nx = target; while (prev[nx] !== cur) nx = prev[nx];
    let d = 0; while (mz.nb[cur * 4 + d] !== nx) d++;
    if (!mz.pass[stage][cur * 4 + d]) {
      know[cur * 4 + d] = LOOK.BLOCKED; t += P.blocked;
      say(`Đẩy cửa ở ${mz.name(cur)} hướng ${DIR_NAME[d]}: không mở được (cửa một chiều). Phải tìm đường khác.`);
      continue;
    }
    const was = cur;
    t += mz.cell / P.speed; cur = nx; visits[cur]++; trace.push([stage, cur]);
    const fooled = []; for (let d = 0; d < 4; d++) { const m = mz.nb[cur * 4 + d]; if (m >= 0) for (let e = 0; e < 4; e++) if (mz.mirror[m * 4 + e] && know[m * 4 + e] === LOOK.OPEN) fooled.push(m); }
    observe();
    for (const m of fooled) say(`Tới gần mới thấy cuối hành lang ở ${mz.name(m)} là một tấm gương — ngõ cụt.`);
    const sides = openSides(cur);
    if (sides >= 3) {
      t += visits[cur] === 1 ? P.junction : P.revisit;
      if (visits[cur] === 1) say(`Ngã ${sides === 3 ? 'ba' : 'tư'} ở ${mz.name(cur)} (tới từ ${mz.name(was)}).`);
    } else if (sides === 1 && visits[cur] === 1 && !mz.roomAt[cur] && cur !== mz.exit) {
      t += P.deadEnd; say(`Ngõ cụt ở ${mz.name(cur)}. Quay lại.`);
    }
  }
  if (t >= P.cap) say(`Hết ${mmss(P.cap)} mà chưa ra được. Julius bỏ cuộc.`);
  const legTimes = legs.map((v, i) => v - (i ? legs[i - 1] : 0));
  while (legTimes.length < 4) legTimes.push(P.cap);
  return { time: Math.min(t, P.cap), done: legs.length === 4, legs: legTimes, lines, trace };
}

// dựng mê cung cho Julius thẳng từ dữ liệu đã xuất (src/layout.js) — độc lập với generator, dùng cho test và blueprint
export function mazeFromLayout(L) {
  const { CELL, GRID: { cols, rows }, WALLS, MAZE, ONEWAY, STAGES, DOORS, POI } = L;
  const inBox = (x, z, [a, b, c, d]) => x >= a && x < c && z >= b && z < d;
  const isCorr = (x, z) => x >= 0 && z >= 0 && x < cols && z < rows && !Object.values(MAZE.roomCells).some(b => inBox(x, z, b));
  const cells = [], idx = new Map();
  for (let z = 0; z < rows; z++) for (let x = 0; x < cols; x++) if (isCorr(x, z)) { idx.set(`${x},${z}`, cells.length); cells.push([x, z]); }
  const H = new Set(), V = new Set(), cellOf = v => { const c = v / CELL, r = Math.round(c); return Math.abs(c - r) < 1e-3 ? r : null; };
  for (const w of WALLS) { const [x1, z1, x2, z2] = w.map(cellOf); if ([x1, z1, x2, z2].includes(null)) continue; if (z1 === z2) for (let x = x1; x < x2; x++) H.add(`${x},${z1}`); else for (let z = z1; z < z2; z++) V.add(`${x1},${z}`); }
  const DV = [[0, -1], [1, 0], [0, 1], [-1, 0]], n = cells.length, nb = new Int16Array(n * 4).fill(-1);
  const wallAt = ([x, z], d) => d === 0 ? H.has(`${x},${z}`) : d === 2 ? H.has(`${x},${z + 1}`) : d === 3 ? V.has(`${x},${z}`) : V.has(`${x + 1},${z}`);
  cells.forEach(([x, z], i) => DV.forEach(([dx, dz], d) => { const j = idx.get(`${x + dx},${z + dz}`); if (j !== undefined) nb[i * 4 + d] = j; }));
  const at = c => idx.get(c.join(',')), dirTo = (a, b) => DV.findIndex(([dx, dz]) => a[0] + dx === b[0] && a[1] + dz === b[1]);
  const doorDir = (cell, door) => { const cx = (cell[0] + 0.5) * CELL, cz = (cell[1] + 0.5) * CELL; return door.axis === 'z' ? (door.x > cx ? 1 : 3) : (door.z > cz ? 2 : 0); };
  const rooms = Object.fromEntries(Object.entries(MAZE.rooms).map(([k, c]) => [k, { cell: at(c), dir: doorDir(c, DOORS.find(d => d.id === MAZE.roomDoors[k])) }]));
  const exit = at(MAZE.exit), exitDir = doorDir(MAZE.exit, DOORS.find(d => d.kind === 'exit'));
  const owBlocked = new Set(ONEWAY.map(o => `${at(o.to)}>${at(o.from)}`));
  const look = [], pass = [];
  for (const st of STAGES) {
    const closed = new Set(st.closed.flatMap(([a, b]) => [`${at(a)}>${at(b)}`, `${at(b)}>${at(a)}`])), lk = new Uint8Array(n * 4), ps = new Uint8Array(n * 4);
    for (let i = 0; i < n; i++) for (let d = 0; d < 4; d++) {
      const j = i * 4 + d, m = nb[j];
      if (m >= 0 && !wallAt(cells[i], d)) {
        if (closed.has(`${i}>${m}`)) lk[j] = LOOK.WALL;
        else { lk[j] = LOOK.OPEN; ps[j] = owBlocked.has(`${i}>${m}`) ? 0 : 1; }
      } else if (Object.values(rooms).some(r => r.cell === i && r.dir === d)) lk[j] = LOOK.ROOM;
      else if (i === exit && d === exitDir) { lk[j] = st.goal === 'exit' ? LOOK.EXIT : LOOK.WALL; ps[j] = st.goal === 'exit' ? 1 : 0; }
      else lk[j] = LOOK.WALL;
    }
    look.push(lk); pass.push(ps);
  }
  const mirror = new Uint8Array(n * 4);
  for (const mr of POI.mirrors) {
    const d = Math.abs(mr.ry) < 1e-6 ? 0 : Math.abs(Math.abs(mr.ry) - Math.PI) < 1e-6 ? 2 : mr.ry < 0 ? 1 : 3; // ry quay mặt gương về phía người nhìn
    const c = [Math.floor(mr.x / CELL - DV[d][0] * 0.3), Math.floor(mr.z / CELL - DV[d][1] * 0.3)];
    mirror[at(c) * 4 + d] = 1;
  }
  const roomAt = new Array(n).fill(null); for (const [k, r] of Object.entries(rooms)) roomAt[r.cell] = k;
  return { n, nb, look, pass, mirror, gate: at(MAZE.gate), exit, exitDir, roomAt, order: ['giam', 'canh', 'te'], cell: CELL, rooms,
    name: i => `${'ABCDEFGHIJKL'[cells[i][1]]}${cells[i][0] + 1}`, cells, dirTo };
}

// chạy nhiều lượt Julius (mỗi lượt chọn ngẫu nhiên khác nhau khi hai hướng ngang nhau)
export function juliusStats(mz, runs = 100, seed0 = 1) {
  const res = []; for (let r = 0; r < runs; r++) res.push(runJulius(mz, seed0 + r));
  const times = res.map(r => r.time).sort((a, b) => a - b);
  const q = p => times[Math.min(times.length - 1, Math.floor(p * times.length))];
  const legMed = [0, 1, 2, 3].map(l => { const v = res.map(r => r.legs[l]).sort((a, b) => a - b); return v[Math.floor(v.length / 2)]; });
  return { res, times, p10: q(0.1), median: q(0.5), best: times[0], worst: times[times.length - 1], legMed, finished: res.filter(r => r.done).length };
}
