import fs from 'node:fs';
const root=new URL('../',import.meta.url),name='HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.tex';
const read=p=>fs.readFileSync(new URL(p,root),'utf8'),write=(p,s)=>fs.writeFileSync(new URL(p,root),s);
const link=`<p><a href="${name}">Hướng dẫn thi công và cơ chế cửa (.tex)</a></p>`;
for(const p of ['viewer-template.html','index.html','model-360.html']){const s=read(p);if(!s.includes(name))write(p,s.replace('</aside>',link+'</aside>'));}
let s=read('tools/finish-artifacts.mjs');
s=s.replace("const files=['model-360.html'",`const files=['${name}','model-360.html'`).replace('hoàn thành trên 15 phút','hoàn thành trên ngưỡng thời gian');
write('tools/finish-artifacts.mjs',s);
s=read('HUONG-DAN.html').replace('hoàn thành trên 15 phút','hoàn thành trên ngưỡng thời gian');if(!s.includes(name))s=s.replace('</h1>','</h1>'+link);write('HUONG-DAN.html',s);
const regionNote='<p>Ngưỡng nghiệm thu đã đổi từ 900 xuống 600 giây theo yêu cầu. Các vòng tìm kiếm bên dưới giữ lịch sử mục tiêu cũ; cấu hình chọn có vùng sửa thực tế đến vòng 5. Thử hoàn nguyên phần ngoài từng vòng 0–4 chưa đạt: vòng 0 đạt 552,29 giây, vòng 1 đạt 556,88 giây, vòng 2–4 không hợp lệ; vòng 5 giữ mức 616,46 giây. Đây là vùng nhỏ nhất trong các phương án thu gọn đã kiểm tra, chưa chứng minh tối ưu toàn cục. <a href="iterations/region-at-600.json">Chi tiết kiểm tra vùng ở ngưỡng 600 giây</a>.</p>';
for(const p of ['HUONG-DAN.html','tools/finish-artifacts.mjs']){let t=read(p);if(!t.includes('iterations/region-at-600.json'))t=t.replace('<h2>Tìm kiếm theo vùng</h2>','<h2>Tìm kiếm theo vùng</h2>'+regionNote);write(p,t);}
s=read('tools/stage-pages.mjs');if(!s.includes(name))s=s.replace("const top=['index.html'",`const top=['${name}','index.html'`);
s=s.replace('Open index.html for the viewer, HUONG-DAN.html for the full report.',`[Viewer](https://dam-truong.github.io/quy-mu-rev-p/) · [Hướng dẫn thi công và cơ chế cửa](${name}) · [Báo cáo](HUONG-DAN.html).`);write('tools/stage-pages.mjs',s);
s=read('tools/pipeline.mjs');if(!s.includes("run('tools/build-construction-guide.mjs')"))s=s.replace("run('tools/finish-artifacts.mjs');","run('tools/build-construction-guide.mjs');\nrun('tools/finish-artifacts.mjs');");write('tools/pipeline.mjs',s);
s=read('README.md');if(!s.includes(name))write('README.md',s+`\nHướng dẫn tự làm: [${name}](${name}). Bảng tọa độ sinh lại bằng node tools/build-construction-guide.mjs.\n\nGitHub Pages: https://dam-truong.github.io/quy-mu-rev-p/\n`);
