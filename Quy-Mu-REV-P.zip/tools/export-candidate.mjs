import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url);
const source=fs.readFileSync(new URL('tools/original-generator.mjs',root),'utf8');
let head=source.split('// ---- chọn mê cung khởi đầu')[0].replace("import { writeFileSync }", "import { writeFileSync, readFileSync }").replace('const MAX_OW = 14, MAX_LOOPS = 6','const MAX_OW = 40, MAX_LOOPS = 16');
const boot=`\nconst selected=JSON.parse(readFileSync(process.argv[2],'utf8'));const cfg={...selected.cfg,st:Int8Array.from(selected.cfg.st)},seed=selected.seed,rounds=[];const stats=juliusStats(mazeFor(cfg),100,1000);\n`;
let tail=source.slice(source.indexOf('const chk = check(cfg), mz = mazeFor(cfg);'));
tail=tail.replaceAll('REV N','REV P').replace('const src = `','let src = `');
tail=tail.replace('writeFileSync(out, src);',`src=src.split('\\n').map(line=>line.startsWith('// Thanh tra Julius 100 lượt:')?'// Kết quả chính thức: xem julius/REPORT.html; báo cáo gốc chỉ để đối chiếu.':line).join('\\n').replace('2 tường xoay',shifts.length+' tường xoay');\nwriteFileSync(out, src);`);
const file=new URL('tools/emit-layout.mjs',root);fs.writeFileSync(file,head+boot+tail);
const res=spawnSync(process.execPath,[fileURLToPath(file),process.argv[2]],{encoding:'utf8'});
if(res.status!==0){console.error(res.stderr);process.exit(res.status??1);}
console.log('Exported candidate geometry. Official independent audit required before rendering.');
