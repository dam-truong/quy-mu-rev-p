import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as L from '../src/layout.js';
import {buildEnvironment} from '../julius/audit-layout.mjs';
const env=buildEnvironment(L),root=new URL('../',import.meta.url);
function reach(g,start){const seen=new Set([start]),q=[start];for(let i=0;i<q.length;i++)for(const v of g.get(q[i]))if(!seen.has(v)){seen.add(v);q.push(v);}return [...seen];}
function solve(A,b){const n=b.length,M=A.map((r,i)=>[...r,b[i]]);for(let k=0;k<n;k++){let p=k;for(let i=k+1;i<n;i++)if(Math.abs(M[i][k])>Math.abs(M[p][k]))p=i;assert.ok(Math.abs(M[p][k])>1e-13);[M[p],M[k]]=[M[k],M[p]];const x=M[k][k];for(let j=k;j<=n;j++)M[k][j]/=x;for(let i=0;i<n;i++)if(i!==k){const f=M[i][k];for(let j=k;j<=n;j++)M[i][j]-=f*M[k][j];}}return M.map(r=>r[n]);}
const stages=env.graphs.map((g,s)=>{const target=env.targets[s],start=env.starts[s],transient=reach(g,start).filter(v=>v!==target),index=new Map(transient.map((v,i)=>[v,i])),N=transient.length;
 const A=transient.map((v,i)=>{const row=Array(N).fill(0);row[i]=1;for(const w of g.get(v))if(w!==target)row[index.get(w)]-=1/g.get(v).length;return row;});
 const h=solve(A,Array(N).fill(1));const residual=Math.max(...A.map(row=>Math.abs(row.reduce((sum,v,j)=>sum+v*h[j],0)-1)));assert.ok(residual<1e-7);
 return {phase:s,target:env.targets[s],transientStates:N,expectedSteps:h[index.get(start)],expectedMeters:h[index.get(start)]*L.CELL,expectedSecondsAt1_2:h[index.get(start)]*L.CELL/1.2,maxLinearResidual:residual};});
function distance(g,a,b){const q=[a],d=new Map([[a,0]]);for(let i=0;i<q.length;i++){const u=q[i];if(u===b)return d.get(u);for(const v of g.get(u))if(!d.has(v)){d.set(v,d.get(u)+1);q.push(v);}}return null;}
const detours=env.graphs.flatMap((g,phase)=>L.ONEWAY.map(o=>{const from=o.from.join(','),to=o.to.join(',');return {phase,from,to,returnSteps:distance(g,to,from)};})).filter(o=>o.returnSteps!==null).sort((a,b)=>b.returnSteps-a.returnSteps);
const report={method:'Numerical solution of absorbing Markov equations, not Monte Carlo.',policy:'Uniform random choice among currently legal outgoing corridor edges at each step; no memory, no clues.',equation:'h(target)=0; h(v)=1 + sum(h(w)/outdegree(v)) over legal outgoing neighbors.',stages,totalExpectedSecondsAt1_2:stages.reduce((s,p)=>s+p.expectedSecondsAt1_2,0),longestReturnDetours:detours.slice(0,12),limitations:['Random-walk expectations are not human completion times and are not the configured acceptance gate.','Gate is minimum completion time over 24 memory-based Julius direction orders.','Numerical floating-point linear solve, not symbolic exact arithmetic.']};
fs.writeFileSync(new URL('math-analysis.json',root),JSON.stringify(report,null,2));console.log(JSON.stringify({randomWalkExpectedSeconds:report.totalExpectedSecondsAt1_2,longestReturnSteps:detours[0]?.returnSteps,residual:Math.max(...stages.map(s=>s.maxLinearResidual))}));
