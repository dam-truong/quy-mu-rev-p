"""Convert the retained editorial Markdown source to a standalone LaTeX deliverable.

Usage: python tools/build-guide-latex.py --pandoc PATH_TO_PANDOC
Compile the output using XeLaTeX, LuaLaTeX, or Tectonic.
"""
from pathlib import Path
import argparse, subprocess, json, re, shutil, os

root = Path(__file__).resolve().parents[1]
stem = 'HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P'
parser = argparse.ArgumentParser()
local_pandoc = Path(os.environ.get('LOCALAPPDATA',''))/'QuyMuTools/latex/pandoc-3.12.1/pandoc.exe'
parser.add_argument('--pandoc', default=shutil.which('pandoc') or (str(local_pandoc) if local_pandoc.exists() else 'pandoc'))
args = parser.parse_args()
subprocess.run([
    args.pandoc, str(root / (stem+'.md')), '--from=markdown', '--to=latex',
    '--standalone', '--wrap=auto', '--toc',
    '--lua-filter='+str(root/'tools/guide-latex.lua'),
    '--include-in-header='+str(root/'tools/guide-latex-header.tex'),
    '--metadata=title:Quỷ Mù REV P',
    '--metadata=subtitle:Hướng dẫn dựng vách và làm cơ chế cửa',
    '--metadata=date:17/10/2026',
    '--variable=documentclass:article', '--variable=fontsize:11pt',
    '--variable=papersize:a4', '--variable=geometry:margin=20mm',
    '--variable=mainfont:texgyretermes-regular.otf',
    '--variable=mainfontoptions:BoldFont=texgyretermes-bold.otf,ItalicFont=texgyretermes-italic.otf,BoldItalicFont=texgyretermes-bolditalic.otf',
    '--variable=sansfont:texgyreheros-regular.otf',
    '--variable=sansfontoptions:BoldFont=texgyreheros-bold.otf,ItalicFont=texgyreheros-italic.otf,BoldItalicFont=texgyreheros-bolditalic.otf',
    '--variable=monofont:texgyrecursor-regular.otf',
    '--variable=monofontoptions:BoldFont=texgyrecursor-bold.otf,ItalicFont=texgyrecursor-italic.otf,BoldItalicFont=texgyrecursor-bolditalic.otf',
    '--variable=colorlinks:true',
    '--variable=linkcolor:teal', '--variable=urlcolor:teal',
    '--output='+str(root/(stem+'.tex')),
], check=True)
tex = root/(stem+'.tex')
text = tex.read_text(encoding='utf-8')
text = '% !TeX program = xelatex\n% UTF-8. Overleaf: choose XeLaTeX; this file is self-contained.\n% Run twice for the table of contents.\n'+text
text = text.replace('\\tableofcontents\n', '\\tableofcontents\n\\clearpage\n')
tex.write_text(text, encoding='utf-8')
source = (root/(stem+'.md')).read_text(encoding='utf-8')
for pattern, count in [(r'OW\d\d',22), (r'W\d\d',51)]:
    assert len(set(re.findall(pattern,source))) == count
    assert set(re.findall(pattern,source)) <= set(re.findall(pattern,text))
assert '\\begin{longtable}' in text and '\\end{document}' in text
print(json.dumps({'latex':str(tex),'bytes':tex.stat().st_size,'coordinateCodes':'PASS'},ensure_ascii=False))
