import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {inspectLayout} from '../julius/audit-layout.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const run=(file,args=[])=>{const p=spawnSync(process.execPath,[root+file,...args],{cwd:root,encoding:'utf8',stdio:'inherit'});if(p.status!==0)throw Error(file+' failed ('+p.status+')');};
run('tools/export-candidate.mjs',[root+'iterations/final-selected.json']);
run('tools/add-guides.mjs');
// Replace the inherited legacy timing model with results from the current
// independent geometry audit before hashing the final source.
const layout=root+'src/layout.js',raw=fs.readFileSync(layout,'utf8'),L=await import('data:text/javascript;base64,'+Buffer.from(raw).toString('base64')),report=inspectLayout(L);
const jr={params:{speed:report.speedMetersPerSecond,los:1,junction:0,deadEnd:0,blocked:0},runs:24,target:report.thresholdSeconds,pass:report.minimumSeconds>=report.thresholdSeconds,best:report.minimumSeconds,median:report.runs.map(r=>r.seconds).sort((a,b)=>a-b)[12],worst:report.maximumSeconds,legMed:[0,1,2,3].map(i=>report.runs.map(r=>r.stages[i].secondsAt1_2).sort((a,b)=>a-b)[12]),rounds:[],heat:[],sampleRoute:[]};
fs.writeFileSync(layout,raw.replace(/^export const JULIUS_REPORT = .*;$/m,'export const JULIUS_REPORT = '+JSON.stringify(jr)+';'));
run('julius/audit-layout.mjs',[layout,'--out',root+'julius/final']);
run('julius/supplementary.mjs',[layout,'--out',root+'julius/final/supplementary']);
run('julius/emergency-plan.mjs',[layout,'--out',root+'emergency-plan.json','--retain-baseline']);
fs.copyFileSync(root+'emergency-plan.json',root+'julius/final/emergency-plan.json');
run('tools/verify-constraints.mjs');
run('julius/review-final.mjs');
run('tools/math-analysis.mjs');
run('tools/build-render.mjs',report.minimumSeconds>=report.thresholdSeconds?[]:['--draft']);
run('tools/verify-render.mjs');
run('tools/finish-artifacts.mjs');
console.log('REV P pipeline complete. Publication requires independent gate PASS.');
