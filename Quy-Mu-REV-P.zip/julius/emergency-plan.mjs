import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {buildEnvironment} from './audit-layout.mjs';
const key=c=>c.join(',');
const pair=(a,b)=>[a,b].sort().join('|');
const reach=(graph,start)=>{const seen=new Set([start]),q=[start];for(let i=0;i<q.length;i++)for(const n of graph.get(q[i])??[])if(!seen.has(n)){seen.add(n);q.push(n);}return seen;};
const segment=(a,b)=>a[0]===b[0]?[a[0],Math.max(a[1],b[1]),a[0]+1,Math.max(a[1],b[1])]:[Math.max(a[0],b[0]),a[1],Math.max(a[0],b[0]),a[1]+1];

export function planEmergency(L,{maxSearchStates=500000,fixedPanels=null}={}){
  const env=buildEnvironment(L),start=env.starts[0];
  const scenarios=L.STAGES.slice(1).map((_,phase)=>{
    const closed=new Set([...L.STAGES[phase].closed,...L.STAGES[phase+1].closed].map(([a,b])=>pair(key(a),key(b))));
    // Physical graph is bidirectional: all one-way restrictions are released.
    const graph=new Map([...env.physical].map(([a,ns])=>[a,ns.filter(b=>!closed.has(pair(a,b)))]));
    const components=[],componentOf=new Map();
    for(const node of graph.keys())if(!componentOf.has(node)){const seen=reach(graph,node),index=components.length;components.push([...seen]);for(const n of seen)componentOf.set(n,index);}
    const previouslyReachable=reach(env.graphs[phase],start),required=[...new Set([...previouslyReachable].map(n=>componentOf.get(n)))];
    return {phase,graph,components,componentOf,previouslyReachable,required,gateComponent:componentOf.get(start)};
  });
  const candidates=[];
  for(const a of env.cells)for(const d of [[1,0],[0,1]]){const b=[a[0]+d[0],a[1]+d[1]],ak=key(a),bk=key(b);
    if(!env.cellMap.has(bk)||env.physical.get(ak).includes(bk))continue;
    const pairs=scenarios.map(s=>[s.componentOf.get(ak),s.componentOf.get(bk)]);if(pairs.every(([u,v])=>u===v))continue;
    candidates.push({a,b,ak,bk,segmentCells:segment(a,b),pairs});
  }
  candidates.sort((a,b)=>a.ak.localeCompare(b.ak)||a.bk.localeCompare(b.bk));
  const initial=scenarios.map(s=>s.components.map((_,i)=>i));
  const apply=(state,index)=>state.map((labels,s)=>{const[u,v]=candidates[index].pairs[s],a=labels[u],b=labels[v];if(a===b)return labels;const lo=Math.min(a,b),hi=Math.max(a,b);return labels.map(k=>k===hi?lo:k);});
  const stateKey=state=>state.map(s=>s.join(',')).join(';');
  const lowerBound=state=>Math.max(0,...scenarios.map((s,i)=>new Set(s.required.map(c=>state[i][c])).size-1));
  const goal=state=>lowerBound(state)===0;
  const branches=state=>{let best=null;for(let i=0;i<scenarios.length;i++){
    const s=scenarios[i],labels=state[i],gate=labels[s.gateComponent];
    for(const group of new Set(s.required.map(c=>labels[c]))){if(group===gate)continue;
      const options=[];for(let p=0;p<candidates.length;p++){const[a,b]=candidates[p].pairs[i];if((labels[a]===group)!==(labels[b]===group))options.push(p);}
      if(best===null||options.length<best.length)best=options;
    }
  }return best??[];};
  // A safe feasible upper bound; exact search below minimizes the UNION of
  // panels across all transitions, so a shared panel is charged only once.
  let greedy=initial,upper=[];
  while(!goal(greedy)){
    const options=branches(greedy);if(!options.length)throw Error('No stable-wall bypass solution exists for the requested transition components');
    let chosen=options[0],score=-Infinity;
    for(const p of options){const next=apply(greedy,p),gain=lowerBound(greedy)-lowerBound(next),merges=greedy.reduce((sum,s,i)=>sum+new Set(s).size-new Set(next[i]).size,0);const value=gain*100+merges;if(value>score){score=value;chosen=p;}}
    greedy=apply(greedy,chosen);upper.push(chosen);
  }
  let explored=0,aborted=false,solution=upper,optimal=false;
  for(let limit=lowerBound(initial);limit<=upper.length;limit++){
    const memo=new Map();
    function dfs(state,remaining,chosen){
      if(goal(state))return chosen;if(remaining===0||lowerBound(state)>remaining)return null;
      if(++explored>maxSearchStates){aborted=true;return null;}
      const k=stateKey(state);if((memo.get(k)??-1)>=remaining)return null;
      const options=branches(state).map(p=>({p,next:apply(state,p)})).sort((a,b)=>lowerBound(a.next)-lowerBound(b.next));
      for(const{p,next}of options){const result=dfs(next,remaining-1,[...chosen,p]);if(result)return result;if(aborted)return null;}
      memo.set(k,remaining);return null;
    }
    const found=dfs(initial,limit,[]);if(found){solution=found;optimal=true;break;}if(aborted)break;
  }
  const panels=fixedPanels??solution.map((index,i)=>{const c=candidates[index];return {id:`E${i+1}`,a:c.a,b:c.b,segmentCells:c.segmentCells,segmentMeters:c.segmentCells.map(v=>v*L.CELL),clearPanelPitchMeters:L.CELL,normalState:'closed',openForAllTransitions:true,bridgesComponentCutsAtTransitions:c.pairs.flatMap(([a,b],phase)=>a!==b?[phase]:[])};});
  function releasedGraph(graph){const g=new Map([...graph].map(([n,ns])=>[n,new Set(ns)]));for(const[a,ns]of g)for(const b of [...ns])g.get(b).add(a);for(const p of panels){g.get(key(p.a)).add(key(p.b));g.get(key(p.b)).add(key(p.a));}return new Map([...g].map(([n,ns])=>[n,[...ns]]));}
  const validation=scenarios.map(s=>{
    const during=releasedGraph(s.graph),before=releasedGraph(env.graphs[s.phase]),after=releasedGraph(env.graphs[s.phase+1]);
    const check=graph=>{const safe=reach(graph,start);return {previouslyReachableNodes:s.previouslyReachable.size,nodesWithReturn:[...s.previouslyReachable].filter(n=>safe.has(n)).length,trapped:[...s.previouslyReachable].filter(n=>!safe.has(n))};};
    const result={fromPhase:s.phase,toPhase:s.phase+1,componentsWithoutPanels:s.components.length,previouslyReachableComponents:s.required.length,beforeRotationWithReleases:check(before),duringConservativeSweep:check(during),afterRotationBeforeRelock:check(after)};
    for(const resultPart of [result.beforeRotationWithReleases,result.duringConservativeSweep,result.afterRotationBeforeRelock])assert.deepEqual(resultPart.trapped,[]);
    return result;
  });
  for(const p of panels){assert.ok(!env.physical.get(key(p.a)).includes(key(p.b)));for(const graph of env.graphs)assert.ok(!graph.get(key(p.a)).includes(key(p.b))&&!graph.get(key(p.b)).includes(key(p.a)));}
  return {status:'PASS_CONCEPT_GRAPH_WITH_RELEASES',panelCount:panels.length,minimumPanelCountProven:optimal,optimization:{method:'Iterative-deepening exact cut branching over shared component merges',exploredStates:explored,searchStateLimit:maxSearchStates,searchLimitReached:aborted,candidateStableWallPanels:candidates.length,greedyUpperBound:upper.length},panels,validation,normalGameplayConnectivityChanged:false,assumptions:['This is a conceptual graph release plan, not mechanical certification.','Before any rotation: pause pursuit; open ALL listed bypass panels; release ALL one-way restrictions; verify releases.','Keep bypasses and one-way gates released throughout the sweep and until final position is confirmed.','Occupancy sensors must prevent rotation while a person is inside any swept zone; obstruction/emergency stop must halt motion.','Both old and new closed wall positions are treated as blocked simultaneously during the conservative test.','Normal play graphs keep these panels closed; opening them during gameplay would change difficulty.','When emergency release is active, sequential gameplay access may change temporarily; restore only after the controlled transition ends.']};
}

if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const input=path.resolve(process.argv[2]??fileURLToPath(new URL('../src/layout.js',import.meta.url))),args=process.argv.slice(3),out=path.resolve(args.includes('--out')?args[args.indexOf('--out')+1]:fileURLToPath(new URL('./emergency-plan.json',import.meta.url)));
  const raw=fs.readFileSync(input),L=await import('data:text/javascript;base64,'+raw.toString('base64')),fixedPanels=args.includes('--retain-baseline')?JSON.parse(fs.readFileSync(new URL('../baseline/emergency-O.json',import.meta.url))).panels:null,report=planEmergency(L,{fixedPanels});
  if(fixedPanels){report.retainedBaselinePanels=true;report.minimumPanelCountProven=false;}
  report.sourcePath=input;report.sourceSHA256=crypto.createHash('sha256').update(raw).digest('hex');fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,panelCount:report.panelCount,minimumPanelCountProven:report.minimumPanelCountProven,panels:report.panels,explored:report.optimization.exploredStates,out},null,2));
}
