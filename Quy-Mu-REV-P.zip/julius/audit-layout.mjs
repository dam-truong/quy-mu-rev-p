import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {runBlind,DIRECTION_ORDERS} from './solver.mjs';

const SETTINGS=JSON.parse(fs.readFileSync(new URL('../config.json',import.meta.url)));
export const THRESHOLD_SECONDS=SETTINGS.thresholdSeconds;
assert.ok(Number.isFinite(THRESHOLD_SECONDS)&&THRESHOLD_SECONDS>0);
const key=c=>c.join(',');
const edge=(a,b)=>[key(a),key(b)].sort().join('|');
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const reach=(graph,start)=>{const seen=new Set([start]),q=[start];for(let i=0;i<q.length;i++)for(const n of graph.get(q[i])??[])if(!seen.has(n)){seen.add(n);q.push(n);}return seen;};
const reverse=graph=>{const r=new Map([...graph.keys()].map(k=>[k,[]]));for(const[a,ns]of graph)for(const b of ns)r.get(b).push(a);return r;};
const goalNames=['giam','canh','te','exit'];

export function buildEnvironment(L){
  assert.ok(L.CELL>0);assert.equal(L.STAGES.length,4);
  const isMaze=([x,z])=>x>=0&&x<L.GRID.cols&&z>=0&&z<L.MAZE.depth&&!Object.values(L.MAZE.roomCells).some(([a,b,c,d])=>x>=a&&x<c&&z>=b&&z<d);
  const cells=[];for(let z=0;z<L.GRID.rows;z++)for(let x=0;x<L.GRID.cols;x++)if(isMaze([x,z]))cells.push([x,z]);
  const cellMap=new Map(cells.map(c=>[key(c),c])),H=new Set(),V=new Set();
  const aligned=v=>{const f=v/L.CELL,r=Math.round(f);return Math.abs(f-r)<1e-3?r:null;};
  for(const wall of L.WALLS){const[x,z,u,v]=wall.map(aligned);if([x,z,u,v].includes(null))continue;
    if(z===v)for(let i=x;i<u;i++)H.add(`${i},${z}`);else for(let i=z;i<v;i++)V.add(`${x},${i}`);
  }
  const physical=new Map(cells.map(([x,z])=>{const ns=[];
    for(const[dx,dz]of [[0,-1],[0,1],[-1,0],[1,0]]){const n=[x+dx,z+dz];if(!isMaze(n))continue;
      if(dx&&!V.has(`${Math.max(x,n[0])},${z}`)||dz&&!H.has(`${x},${Math.max(z,n[1])}`))ns.push(key(n));
    }return [key([x,z]),ns];
  }));
  const blocked=new Set(L.ONEWAY.map(o=>`${key(o.to)}>${key(o.from)}`));
  for(const o of L.ONEWAY){assert.ok(cellMap.has(key(o.from))&&cellMap.has(key(o.to)),'One-way outside corridor');assert.ok(physical.get(key(o.from)).includes(key(o.to)),'One-way not on physical passage');}
  // Reconstruct moving closures from physical mechanism endpoints; STAGES is
  // checked against them, never trusted as the source of connectivity.
  const cellsAcross=([x,z,u,v])=>x===u?[[x-1,Math.min(z,v)],[x,Math.min(z,v)]]:[[Math.min(x,u),z-1],[Math.min(x,u),z]];
  for(const shift of L.SHIFTS){
    assert.equal(Math.hypot(shift.before[2]-shift.before[0],shift.before[3]-shift.before[1]),1);
    assert.equal(Math.hypot(shift.after[2]-shift.after[0],shift.after[3]-shift.after[1]),1);
    assert.equal(shift.before[0]===shift.before[2],shift.after[1]===shift.after[3]);
    for(const seg of [shift.before,shift.after])assert.ok([[seg[0],seg[1]],[seg[2],seg[3]]].some(p=>key(p)===key(shift.post)),'Pivot is not an endpoint');
    assert.equal(edge(...cellsAcross(shift.before)),edge(...shift.freed));assert.equal(edge(...cellsAcross(shift.after)),edge(...shift.shut));
  }
  const graphs=L.STAGES.map((stage,phase)=>{
    const expectedOpen=L.LOCKS.filter(l=>['giam','canh','te'].indexOf(l.after)<phase).map(l=>l.id);
    assert.deepEqual([...stage.open].sort(),expectedOpen.sort(),'Incorrect phase lock order');
    const mechanismPairs=[...L.LOCKS.filter(l=>!stage.open.includes(l.id)).map(l=>[l.a,l.b]),...L.SHIFTS.map(s=>cellsAcross(stage.open.includes(s.at)?s.after:s.before))];
    const closed=new Set(mechanismPairs.map(([a,b])=>edge(a,b)));
    assert.deepEqual([...closed].sort(),stage.closed.map(([a,b])=>edge(a,b)).sort(),'STAGES mismatch physical mechanism geometry');
    for(const[a,b]of mechanismPairs)assert.ok(physical.get(key(a))?.includes(key(b)),'Moving mechanism overlaps fixed wall');
    return new Map(cells.map(c=>[key(c),physical.get(key(c)).filter(n=>!closed.has(edge(c,cellMap.get(n)))&&!blocked.has(`${key(c)}>${n}`))]));
  });
  const targets=[L.MAZE.rooms.giam,L.MAZE.rooms.canh,L.MAZE.rooms.te,L.MAZE.exit].map(key),starts=[key(L.MAZE.gate),...targets.slice(0,-1)];
  const union=new Set(),phaseChecks=graphs.map((graph,phase)=>{
    const reachable=reach(graph,key(L.MAZE.gate)),toGate=reach(reverse(graph),key(L.MAZE.gate));reachable.forEach(n=>union.add(n));
    assert.ok(reachable.has(targets[phase]),`Target unreachable at phase ${phase}`);
    assert.ok(reach(graph,starts[phase]).has(targets[phase]),`Previous room cannot reach target phase ${phase}`);
    const trapped=[...reachable].filter(n=>!toGate.has(n));assert.deepEqual(trapped,[],`Cannot return to gate phase ${phase}`);
    const futureRoomsReachable=targets.slice(phase+1,3).filter(n=>reachable.has(n));assert.deepEqual(futureRoomsReachable,[],`Sequential lock bypass at phase ${phase}`);
    return {phase,target:goalNames[phase],reachableNodes:reachable.size,totalNodes:cells.length,allReachableReturnToGate:true,futureRoomsReachable};
  });
  assert.equal(union.size,cells.length,'Corridor cells permanently unreachable in every phase');
  const transitionEndpointChecks=graphs.slice(1).map((graph,i)=>{const old=reach(graphs[i],starts[0]),toGate=reach(reverse(graph),starts[0]);const trapped=[...old].filter(n=>!toGate.has(n));assert.deepEqual(trapped,[],`Old occupied node cannot return after phase change ${i}`);return {fromPhase:i,toPhase:i+1,oldReachableNodes:old.size,oldReachableNodesWithoutReturnAfterChange:trapped};});
  const conservativeSweepChecks=graphs.slice(1).map((_,i)=>{
    const closed=new Set([...L.STAGES[i].closed,...L.STAGES[i+1].closed].map(([a,b])=>edge(a,b)));
    const graph=new Map(cells.map(c=>[key(c),physical.get(key(c)).filter(n=>!closed.has(edge(c,cellMap.get(n)))&&!blocked.has(`${key(c)}>${n}`))]));
    const old=reach(graphs[i],starts[0]),toGate=reach(reverse(graph),starts[0]);return {fromPhase:i,toPhase:i+1,assumption:'All old and new closed edges block simultaneously; no emergency release assumed.',oldReachableNodesWithoutReturnDuringSweep:[...old].filter(n=>!toGate.has(n))};
  });
  function makeOracle(){let phase=0,current=starts[0];
    const show=node=>{const[x,z]=cellMap.get(node);return {id:node,x,z,labels:goalNames.filter((_,i)=>targets[i]===node&&(i!==3||phase===3))};};
    return {order:goalNames,scale:L.CELL,observe(){return {current:show(current),neighbors:graphs[phase].get(current).map(show),visibleClosedDoors:[],phase,target:goalNames[phase]};},move(next){assert.ok(graphs[phase].get(current).includes(next),`Illegal step ${current}>${next} at phase ${phase}`);current=next;return L.CELL;},complete(){if(current!==targets[phase])return false;phase++;return true;},finished(){return phase===4;}};
  }
  return {cells,cellMap,physical,graphs,targets,starts,phaseChecks,transitionEndpointChecks,conservativeSweepChecks,makeOracle};
}

export function inspectLayout(L,{permutations=24,thresholdSeconds=THRESHOLD_SECONDS}={}){
  assert.ok(permutations===4||permutations===24,'Choose 4 legacy directions or all 24 permutations');
  const env=buildEnvironment(L),runs=Array.from({length:permutations},(_,i)=>runBlind(env.makeOracle(),i));
  for(const run of runs){assert.equal(run.stages.length,4);assert.ok(Math.abs(run.meters-run.steps*L.CELL)<1e-6);for(const step of run.log)assert.ok(env.graphs[step.phase].get(step.from).includes(step.to));}
  const first4=runs.slice(0,4),best=runs.reduce((a,b)=>a.seconds<b.seconds?a:b),minimumSeconds=best.seconds;
  const shortest=env.targets.map((target,phase)=>{const graph=env.graphs[phase],start=env.starts[phase],prev=new Map([[start,null]]),q=[start];for(let i=0;i<q.length;i++){if(q[i]===target)break;for(const n of graph.get(q[i]))if(!prev.has(n)){prev.set(n,q[i]);q.push(n);}}assert.ok(prev.has(target));const route=[];for(let n=target;n!==null;n=prev.get(n))route.unshift(n);return {phase,target:goalNames[phase],steps:route.length-1,meters:(route.length-1)*L.CELL,route};});
  return {status:minimumSeconds>=thresholdSeconds?'PASS_SIMULATION_GATE':'REJECT_UNDER_THRESHOLD',thresholdSeconds,speedMetersPerSecond:1.2,addedDelaysSeconds:0,permutations,minimumSeconds,maximumSeconds:Math.max(...runs.map(r=>r.seconds)),legacy4MinimumSeconds:Math.min(...first4.map(r=>r.seconds)),extraPermutationsImproveFastestBySeconds:Math.min(...first4.map(r=>r.seconds))-minimumSeconds,fastestStrategy:best.strategy,allRunsComplete:true,geometry:{grid:L.GRID,cellMeters:L.CELL,corridorNodes:env.cells.length,oneWayDoors:L.ONEWAY.length,rotatingWalls:L.SHIFTS.length},allCorridorCellsReachableInAtLeastOnePhase:true,phaseChecks:env.phaseChecks,transitionEndpointChecks:env.transitionEndpointChecks,conservativeSweepChecks:env.conservativeSweepChecks,omniscient:{totalMeters:shortest.reduce((s,r)=>s+r.meters,0),stages:shortest},runs,limitations:['Simulation time, not human playtest time.','Same memory/frontier algorithm across all direction permutations; not a proof about every possible strategy.','Exit label is hidden until phase 3; room targets are corridor approach cells.','Memory persists across phases; no added turn, thought, waiting or puzzle time.','Endpoint connectivity is not physical sweep safety; conservative sweep findings are reported separately.']};
}

export function writeAudit(report,out,{sourceBytes,sourcePath}={}){
  fs.mkdirSync(out,{recursive:true});if(sourceBytes){fs.writeFileSync(path.join(out,'input-layout.js'),sourceBytes);report.sourceSHA256=sha(sourceBytes);}if(sourcePath)report.sourcePath=sourcePath;
  report.solverSHA256=sha(fs.readFileSync(fileURLToPath(new URL('./solver.mjs',import.meta.url))));
  for(const run of report.runs)fs.writeFileSync(path.join(out,run.strategy+'.jsonl'),run.log.map(v=>JSON.stringify(v)).join('\n')+'\n');
  const summary={...report,runs:report.runs.map(({log,...r})=>r)};fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(summary,null,2)+'\n');
  const fmt=s=>`${Math.floor(s/60)}:${(s%60).toFixed(2).padStart(5,'0')}`;
  const rows=report.runs.map(r=>`<tr><td>${r.strategy}</td><td>${r.steps}</td><td>${r.meters.toFixed(2)}</td><td>${fmt(r.seconds)}</td><td>${r.stages.map(s=>fmt(s.secondsAt1_2)).join(' / ')}</td><td><a href="${r.strategy}.jsonl">Log</a></td></tr>`).join('');
  const html=`<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>JULIUS — REV P / kiểm tra</title><style>body{background:#112d37;color:#e7e6d8;font:16px/1.6 system-ui;margin:40px auto;max-width:1200px;padding:24px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:10px;border-bottom:1px solid #46606b;text-align:left}a{color:#94dfd6}code{overflow-wrap:anywhere}.result{padding:22px;background:#42342a}h1{font-size:32px}</style><h1>JULIUS / ngưỡng ${report.thresholdSeconds/60} phút</h1><div class="result"><b>${report.status}</b><p>Lượt nhanh nhất ${fmt(report.minimumSeconds)}. ${report.permutations} hoán vị hướng; 1,2 m/s; không cộng thời gian dừng, đố hoặc cốt truyện.</p></div><p>Bốn hướng ban đầu nhanh nhất ${fmt(report.legacy4MinimumSeconds)}. Các hoán vị bổ sung giúp tìm nhanh hơn ${report.extraPermutationsImproveFastestBySeconds.toFixed(2)} giây. Giữ trí nhớ cả bốn chặng; cửa thoát ẩn tới chặng cuối.</p><table><thead><tr><th>Chiến lược</th><th>Bước</th><th>Mét</th><th>Tổng</th><th>Thời gian từng chặng</th><th>Chi tiết</th></tr></thead><tbody>${rows}</tbody></table><p>Kiểm tra khóa tuần tự, đường về cổng ở mỗi pha, sau đổi pha và toàn bộ ô hành lang có lúc tiếp cận được: đạt. Tình huống tường đang quét được ghi riêng trong report.json; không đồng nghĩa đã duyệt cơ khí.</p><p>Đây là ${report.permutations} ưu tiên hướng của cùng một thuật toán. Qua ngưỡng mô phỏng không chứng minh mọi người chơi đều mất ${report.thresholdSeconds/60} phút hoặc đạt điểm 9/10.</p><p><a href="report.json">Báo cáo đầy đủ</a> · <a href="input-layout.js">Đầu vào đã kiểm tra</a><br>SHA-256: <code>${report.sourceSHA256??'in-memory input'}</code></p></html>`;
  fs.writeFileSync(path.join(out,'REPORT.html'),html);return summary;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const args=process.argv.slice(2),fallback=fileURLToPath(new URL('../../julius-K01-rev-N/source/src/layout.js',import.meta.url));
  const proposed=fileURLToPath(new URL('../src/layout.js',import.meta.url)),source=path.resolve(args[0]&&!args[0].startsWith('--')?args[0]:(fs.existsSync(proposed)?proposed:fallback));
  const option=(name,defaultValue)=>args.includes(name)?args[args.indexOf(name)+1]:defaultValue;
  const out=path.resolve(option('--out',fileURLToPath(new URL('./latest',import.meta.url)))),count=Number(option('--permutations','24'));
  const raw=fs.readFileSync(source),L=await import('data:text/javascript;base64,'+raw.toString('base64'));
  const report=inspectLayout(L,{permutations:count});writeAudit(report,out,{sourceBytes:raw,sourcePath:source});
  console.log(JSON.stringify({status:report.status,permutations:count,minimumSeconds:report.minimumSeconds,legacy4MinimumSeconds:report.legacy4MinimumSeconds,steps:report.runs.map(r=>r.steps),sourceSHA256:report.sourceSHA256,out},null,2));
}
