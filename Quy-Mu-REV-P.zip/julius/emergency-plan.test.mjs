import test from 'node:test';
import assert from 'node:assert/strict';
import * as N from '../../julius-K01-rev-N/source/src/layout.js';
import {planEmergency} from './emergency-plan.mjs';
import {wallFollowers} from './supplementary.mjs';
test('Emergency bypasses are normally closed and all old occupied cells can return during both-pose sweep',()=>{const r=planEmergency(N);assert.equal(r.minimumPanelCountProven,true);assert.equal(r.normalGameplayConnectivityChanged,false);for(const v of r.validation)for(const part of [v.beforeRotationWithReleases,v.duringConservativeSweep,v.afterRotationBeforeRelock])assert.deepEqual(part.trapped,[]);});
test('Eight wall-followers terminate honestly in completion or a repeated finite state',()=>{const r=wallFollowers(N);assert.equal(r.runs.length,8);for(const run of r.runs){assert.ok(['COMPLETE','FINITE_STATE_LOOP'].includes(run.status));if(run.status==='FINITE_STATE_LOOP'){assert.ok(run.loop.periodSteps>0);assert.equal(run.completed,false);}else assert.equal(run.legs.length,4);}});
