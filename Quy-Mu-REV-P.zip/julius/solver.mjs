import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

export const SPEED = 1.2;
const LEGACY_ORDERS = [[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2]];
const permutations=xs=>xs.length?xs.flatMap((x,i)=>permutations(xs.filter((_,j)=>j!==i)).map(rest=>[x,...rest])):[[]];
export const DIRECTION_ORDERS=[...LEGACY_ORDERS,...permutations([0,1,2,3]).filter(order=>!LEGACY_ORDERS.some(old=>old.join()===order.join()))];
const ORDERS=DIRECTION_ORDERS;
const DIR = ['N','E','S','W'];
const id = v => String(v);
const distance = (a,b,scale) => Math.hypot(a.x-b.x,a.z-b.z)*scale;
function direction(a,b) { const dx=b.x-a.x,dz=b.z-a.z; return Math.abs(dx)>Math.abs(dz)?(dx>0?1:3):(dz>0?2:0); }
const neighborsAt=(data,n,phase)=>data.stages?.[phase]?.neighborsById?.[id(n.id)]??n.neighbors;

export function validate(data) {
  if(data.directed!==true)throw Error('Directed inspector requires directed:true');
  if (!Array.isArray(data.nodes) || !data.nodes.length) throw Error('No nodes');
  const nodes=new Map(data.nodes.map(n=>[id(n.id),n]));
  if(nodes.size!==data.nodes.length)throw Error('Duplicate node IDs');
  if(!nodes.has(id(data.start))||!nodes.has(id(data.exit)))throw Error('Missing start/exit');
  if(!(data.cellSize>0))throw Error('cellSize must be positive');
  for(const n of nodes.values()){
    if(!Number.isFinite(n.x)||!Number.isFinite(n.z)||!Array.isArray(n.neighbors))throw Error('Invalid node');
    for(const dst of n.neighbors){const b=nodes.get(id(dst));if(!b)throw Error('Unknown neighbor');
      if(!distance(n,b,data.cellSize))throw Error('Zero-distance edge');
    }
  }
  const order=[...(data.visitOrder??['giam','canh','te']),'exit'];
  const targets=order.map(t=>t==='exit'?id(data.exit):id(data.rooms.find(r=>r.id===t)?.entry));
  if(targets.some(t=>!nodes.has(t)))throw Error('Missing room entry');
  if(data.stages&&data.stages.length!==order.length)throw Error('Need one topology per objective');
  for(let phase=0;phase<order.length;phase++){
    const reverse=new Map([...nodes.keys()].map(k=>[k,[]]));
    for(const n of nodes.values())for(const dst of neighborsAt(data,n,phase)){
      const b=nodes.get(id(dst));if(!b)throw Error('Unknown stage neighbor');
      if(!distance(n,b,data.cellSize))throw Error('Zero-distance phase edge');
      reverse.get(id(dst)).push(id(n.id));
    }
    for(const reversed of [false,true]){
      const seen=new Set([id(data.start)]),work=[id(data.start)];
      for(let i=0;i<work.length;i++)for(const nb of (reversed?reverse.get(work[i]):neighborsAt(data,nodes.get(work[i]),phase).map(id)))if(!seen.has(nb)){seen.add(nb);work.push(nb);}
      if(seen.size!==nodes.size)throw Error(`Stage ${phase}: ${reversed?'some nodes cannot return to start':'start cannot reach all nodes'}`);
    }
    for(const room of data.rooms){const entry=id(room.entry),outs=neighborsAt(data,nodes.get(entry),phase).map(id),ins=reverse.get(entry);
      if(outs.length!==1||ins.length!==1||outs[0]!==ins[0])throw Error(`Room portal ${room.id} must be one bidirectional leaf`);
    }
  }
  return {nodes,order,targets};
}

// Only this environment closure can see the full map. The solver receives its
// current position and a one-edge local view; it cannot query arbitrary nodes.
export function createOracle(data){
  const {nodes,order,targets}=validate(data);let position=id(data.start),phase=0;
  const locked=key=>targets.some((t,i)=>t===key&&i>phase&&order[i]!=='exit'&&neighborsAt(data,nodes.get(t),phase).length===1);
  function publicNode(key){const n=nodes.get(key);const labels=[];
    for(let i=0;i<targets.length;i++)if(targets[i]===key)labels.push(order[i]);
    return {id:key,x:n.x,z:n.z,labels};
  }
  return {
    order:[...order],scale:data.cellSize,
    observe(){const n=nodes.get(position),adjacent=neighborsAt(data,n,phase).map(id);return {current:publicNode(position),neighbors:adjacent.filter(k=>!locked(k)).map(publicNode),visibleClosedDoors:adjacent.filter(locked).map(publicNode),phase,target:order[phase]};},
    move(destination){destination=id(destination);if(locked(destination)||!neighborsAt(data,nodes.get(position),phase).map(id).includes(destination))throw Error('Illegal move');
      const meters=distance(nodes.get(position),nodes.get(destination),data.cellSize);position=destination;return meters;},
    complete(){if(position!==targets[phase])return false;phase++;return true;},
    finished(){return phase===targets.length;}
  };
}

function shortestKnown(known,start,predicate,rank,scale){
  const costs=new Map([[start,0]]),prev=new Map(),open=[start];
  while(open.length){open.sort((a,b)=>costs.get(a)-costs.get(b));const u=open.shift();
    if(predicate(u)){const result=[u];while(prev.has(result[0]))result.unshift(prev.get(result[0]));return result;}
    const a=known.get(u); const adjacent=[...a.edges].sort((v,w)=>rank.indexOf(direction(a,known.get(v)))-rank.indexOf(direction(a,known.get(w)))||v.localeCompare(w));
    for(const v of adjacent){const cost=costs.get(u)+distance(a,known.get(v),scale);if(cost<(costs.get(v)??Infinity)-1e-8){costs.set(v,cost);prev.set(v,u);if(!open.includes(v))open.push(v);}}
  }return null;
}

export function runBlind(oracle,orderIndex=0){
  const rank=ORDERS[orderIndex],known=new Map(),visited=new Set(),remembered=new Map(),doorApproaches=new Map(),log=[],stages=[];
  let meters=0,steps=0,phaseMeters=0,phaseSteps=0,phaseNew=0,phaseJunctions=0,lastPhase=0;
  const record=n=>{if(!known.has(n.id))known.set(n.id,{...n,edges:new Set(),observed:false,confirmedPhase:-1});for(const label of n.labels)remembered.set(label,n.id);};
  while(!oracle.finished()){
    if(steps>1000000)throw Error('Inspection limit reached, not a PASS');
    const obs=oracle.observe(),cur=obs.current;record(cur);obs.neighbors.forEach(record);
    for(const door of obs.visibleClosedDoors??[]){record(door);for(const label of door.labels)doorApproaches.set(label,cur.id);}
    const kn=known.get(cur.id);kn.observed=true;kn.confirmedPhase=obs.phase;
    const now=new Set(obs.neighbors.map(n=>n.id));
    const changedEdges=[...kn.edges].filter(n=>!now.has(n));
    for(const removed of changedEdges)kn.edges.delete(removed);
    for(const n of obs.neighbors)kn.edges.add(n.id);
    if(!visited.has(cur.id)){visited.add(cur.id);phaseNew++;if(obs.neighbors.length>=3)phaseJunctions++;}
    if(oracle.complete()){
      stages.push({phase:lastPhase,target:obs.target,meters:meters-phaseMeters,steps:steps-phaseSteps,newVisitedNodes:phaseNew,newJunctions:phaseJunctions,secondsAt1_2:(meters-phaseMeters)/SPEED,knownNodesAtFinish:known.size,visitedNodesAtFinish:visited.size});
      lastPhase++;phaseMeters=meters;phaseSteps=steps;phaseNew=0;phaseJunctions=0;continue;
    }
    const target=remembered.get(obs.target);
    let route=target?shortestKnown(known,cur.id,u=>u===target,rank,oracle.scale):null;
    let reason=route?'remembered-room':'nearest-unexplored-frontier';
    if(!route&&doorApproaches.has(obs.target)){route=shortestKnown(known,cur.id,u=>u===doorApproaches.get(obs.target),rank,oracle.scale);reason='remembered-door-approach';}
    if(!route)route=shortestKnown(known,cur.id,u=>!known.get(u).observed,rank,oracle.scale);
    if(!route){route=shortestKnown(known,cur.id,u=>known.get(u).confirmedPhase!==obs.phase,rank,oracle.scale);reason='recheck-remembered-topology';}
    if(!route||route.length<2)throw Error(`No reachable frontier for ${obs.target}; invalid/incomplete run`);
    const next=route[1];
    const revisit=visited.has(next),walk=oracle.move(next);meters+=walk;steps++;
    log.push({step:steps,phase:obs.phase,target:obs.target,from:cur.id,to:next,fromXZ:[cur.x,cur.z],toXZ:[known.get(next).x,known.get(next).z],observedNeighbors:obs.neighbors.map(n=>n.id),visibleClosedDoors:(obs.visibleClosedDoors??[]).map(n=>n.id),discoveredClosures:changedEdges,reason,revisit,meters:walk,totalMeters:meters,simulatedSeconds:meters/SPEED});
  }
  return {strategy:`directed-frontier-memory-${rank.map(i=>DIR[i]).join('')}`,meters,steps,seconds:meters/SPEED,minutes:meters/SPEED/60,sensitivitySeconds:{'1.0m/s':meters,'1.2m/s':meters/1.2,'1.4m/s':meters/1.4},revisitedSteps:log.filter(r=>r.revisit).length,visitedNodes:visited.size,stages,log};
}

function omniscient(data){const {nodes,targets}=validate(data);let pos=id(data.start);const stages=[];
  for(let phase=0;phase<targets.length;phase++){const dst=targets[phase],known=new Map([...nodes].map(([k,n])=>[k,{...n,edges:new Set(neighborsAt(data,n,phase).map(id))}]));const route=shortestKnown(known,pos,u=>u===dst,ORDERS[0],data.cellSize);const length=route.slice(1).reduce((s,n,i)=>s+distance(nodes.get(route[i]),nodes.get(n),data.cellSize),0);stages.push({target:dst,meters:length,route});pos=dst;}
  return {meters:stages.reduce((s,p)=>s+p.meters,0),stages};
}

export function inspectDirect(data){
  validate(data);const runs=ORDERS.map((_,i)=>runBlind(createOracle(data),i));
  const minimum=Math.min(...runs.map(r=>r.seconds));const passed=runs.every(r=>r.seconds>=900);
  const degree=data.nodes.map(n=>neighborsAt(data,n,0).length),arcs=degree.reduce((s,d)=>s+d,0);
  const physicalEdges=new Set(data.nodes.flatMap(n=>neighborsAt(data,n,0).map(b=>[id(n.id),id(b)].sort().join('|')))),edgeCount=physicalEdges.size;
  const physicalDegree=new Map(data.nodes.map(n=>[id(n.id),new Set()]));
  for(const n of data.nodes)for(const b of neighborsAt(data,n,0)){physicalDegree.get(id(n.id)).add(id(b));physicalDegree.get(id(b)).add(id(n.id));}
  const deadEnds=[...physicalDegree.values()].filter(ns=>ns.size===1).length;
  const easySegments=runs.flatMap(r=>r.stages.filter(s=>s.secondsAt1_2<225).map(s=>({strategy:r.strategy,...s,reason:s.newVisitedNodes===0?'Đã nhớ toàn tuyến/phòng từ chặng trước; chỉ đi tới cửa đã biết.':s.newJunctions<3?'Ít giao lộ mới để lựa chọn ở chặng này.':'Chặng dưới 3 phút 45 giây trong phép thử; xem log các nhánh đã loại trừ.'})));
  return {revision:data.revision,seed:data.seed,directed:true,topology:data.stages?'phase-dependent-directed':'static-directed',status:passed?'SIMULATION_GATE_PASS':'REJECT_UNDER_15_MINUTES',thresholdSeconds:900,speedMetersPerSecond:SPEED,minimumSeconds:minimum,allRunsComplete:true,metrics:{nodes:data.nodes.length,edges:edgeCount,directedArcs:arcs,oneWaySegments:2*edgeCount-arcs,deadEnds,outDegreeOneNodes:degree.filter(d=>d===1).length,junctions:[...physicalDegree.values()].filter(ns=>ns.size>=3).length,cycleRank:edgeCount-data.nodes.length+1},omniscient:omniscient(data),runs,easySegments,limitations:['Thời gian đi bộ mô phỏng; chưa phải thời gian người thật.','Bốn ưu tiên hướng của một chiến lược nhớ bản đồ có hướng, không đại diện mọi chiến thuật.','Không tự suy ra cạnh ngược khi nhìn thấy một lối đi.','newJunctions đếm nút mới có ít nhất 3 lối ra, chưa phải số giao lộ vật lý.','Ngưỡng 15 phút không tự chứng minh độ khó 9/10.','Không tính đố, cốt truyện, quỷ, suy nghĩ, dừng hay mở cửa.']};
}

export function writeReport(report,out,sourceHash){
  fs.mkdirSync(out,{recursive:true});report.sourceSHA256=sourceHash;
  for(const run of report.runs){fs.writeFileSync(path.join(out,`${run.strategy}.jsonl`),run.log.map(l=>JSON.stringify(l)).join('\n')+'\n');}
  const summary={...report,runs:report.runs.map(({log,...r})=>r)};
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(summary,null,2)+'\n');
  const rows=report.runs.map(r=>`| ${r.strategy} | ${r.meters.toFixed(1)} | ${r.minutes.toFixed(2)} | ${r.stages.map(s=>(s.secondsAt1_2/60).toFixed(2)).join(' / ')} |`).join('\n');
  const easy=report.easySegments.map(e=>`- ${e.strategy}, chặng ${e.phase+1} (${e.target}): ${(e.secondsAt1_2/60).toFixed(2)} phút, ${e.meters.toFixed(1)} m, ${e.newVisitedNodes} ô mới, ${e.newJunctions} giao lộ mới. ${e.reason}`).join('\n');
  fs.writeFileSync(path.join(out,'REPORT.md'),`# JULIUS — ${report.revision}\n\n**${report.status}**. Lượt nhanh nhất: ${(report.minimumSeconds/60).toFixed(2)} phút mô phỏng.\n\nTốc độ 1,2 m/s; không cộng delay, câu đố hay cốt truyện. Giữ trí nhớ xuyên suốt chặng. Không nhìn bản đồ toàn phần khi chạy blind; chỉ nhìn ô hiện tại và lối kề một bước.\n\nSHA-256 đầu vào: \`${sourceHash}\`\n\n| Chiến lược | Mét | Phút | Phút từng chặng |\n|---|---:|---:|---|\n${rows}\n\nĐồ thị có ${report.metrics.nodes} nút, ${report.metrics.junctions} giao lộ, ${report.metrics.deadEnds} đầu cụt, ${report.metrics.cycleRank} chu trình độc lập. Người biết toàn bản đồ đi tối thiểu ${report.omniscient.meters.toFixed(1)} m theo đúng thứ tự.\n\n## Những chặng còn dễ\n\n${easy||'Không chặng nào dưới 3 phút 45 giây trong bốn lượt; vẫn cần kiểm tra người thật.'}\n\n## Giới hạn\n\n${report.limitations.map(s=>'- '+s).join('\n')}\n`);
  return summary;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const input=process.argv[2];if(!input)throw Error('Usage: node inspector.mjs candidate.json --out outputdir');
  const args=process.argv.slice(3),out=args.includes('--out')?args[args.indexOf('--out')+1]:path.join(path.dirname(input),'julius-output');
  const raw=fs.readFileSync(input),report=inspectDirect(JSON.parse(raw));
  writeReport(report,out,crypto.createHash('sha256').update(raw).digest('hex'));
  console.log(JSON.stringify({status:report.status,minMinutes:report.minimumSeconds/60,meters:report.runs.map(r=>r.meters),out},null,2));
}
