import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {buildEnvironment,inspectLayout} from './audit-layout.mjs';
import {simulate,restore,ranks} from '../tools/optimize.mjs';
import * as C from '../tools/core.mjs';
const root=new URL('../',import.meta.url),out=path.resolve(process.argv[2]??fileURLToPath(new URL('./final',import.meta.url)));
const snapshot=fs.readFileSync(path.join(out,'input-layout.js')),hash=crypto.createHash('sha256').update(snapshot).digest('hex');
const L=await import('data:text/javascript;base64,'+snapshot.toString('base64')),env=buildEnvironment(L);
const stored=JSON.parse(fs.readFileSync(path.join(out,'report.json'))),cfg=restore(JSON.parse(fs.readFileSync(new URL('iterations/final-selected.json',root))).cfg);
assert.equal(hash,stored.sourceSHA256);
const fresh=inspectLayout(L,{permutations:24});
const equivalence=[];
for(let phase=0;phase<4;phase++){
  const fastGraph=C.adjOf(cfg,phase);
  for(let i=0;i<C.CORR.length;i++)assert.deepEqual(fastGraph[i].map(j=>C.CORR[j].join(',')).sort(),[...env.graphs[phase].get(C.CORR[i].join(','))].sort());
}
for(let i=0;i<24;i++){
  const rank=ranks[i].map(j=>'NESW'[j]).join(''),run=fresh.runs.find(r=>r.strategy.endsWith('-'+rank)),fast=simulate(cfg,i);
  assert.ok(!fast.error);assert.equal(fast.steps,run.steps);
  const logs=fs.readFileSync(path.join(out,run.strategy+'.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
  assert.deepEqual(logs,run.log);assert.equal(stored.runs.find(r=>r.strategy===run.strategy).steps,run.steps);
  equivalence.push({rank,steps:run.steps,seconds:run.seconds,allSavedLogEntriesMatch:true,fastStepsMatch:true});
}
assert.equal(L.GUIDE_STAGES.length,4);
const cycle=['gieng','lua','kho','mieu'],guides=[];
for(let phase=0;phase<4;phase++){
  const guide=L.GUIDE_STAGES[phase],graph=env.graphs[phase],route=guide.route;
  assert.equal(guide.phase,phase);assert.equal(guide.row,phase+1);
  assert.equal(route[0],env.starts[phase]);assert.equal(route.at(-1),env.targets[phase]);assert.equal(new Set(route).size,route.length);
  let decisionIndex=0;const consumed=[];
  for(let i=0;i<route.length-1;i++){
    const at=route[i],next=route[i+1],options=graph.get(at).filter(n=>n!==route[i-1]);
    assert.ok(graph.get(at).includes(next),'Guide route uses illegal arc');
    if(options.length<2){assert.deepEqual(options,[next]);continue;}
    const d=guide.decisions[decisionIndex],expected=cycle[decisionIndex%4];
    assert.equal(d.at,at);assert.equal(d.expected,expected);assert.equal(d.correctNext,next);
    assert.deepEqual(d.choices.map(c=>c.to).sort(),[...options].sort());
    const matching=d.choices.filter(c=>c.sym===expected);assert.equal(matching.length,1);assert.equal(matching[0].to,next);
    for(const c of d.choices){
      assert.equal(c.from,at);assert.equal(c.row,phase+1);assert.equal(c.ok,c.to===next);assert.ok(cycle.includes(c.sym));
      const[x,z]=at.split(',').map(Number),[a,b]=c.to.split(',').map(Number);
      assert.ok(Math.abs(c.x-(x+.5+.28*(a-x))*L.CELL)<1e-8);assert.ok(Math.abs(c.z-(z+.5+.28*(b-z))*L.CELL)<1e-8);
      consumed.push(c);
    }
    decisionIndex++;
  }
  assert.equal(decisionIndex,guide.decisions.length);assert.deepEqual(consumed,guide.marks);
  guides.push({phase,row:phase+1,steps:route.length-1,meters:(route.length-1)*L.CELL,decisionJunctions:decisionIndex,allOutgoingOptionsMarked:true,exactlyOneExpectedSymbol:true,legalSymbolFollowerCompletes:true});
}
const emergency=JSON.parse(fs.readFileSync(path.join(out,'emergency-plan.json'))),walls=JSON.parse(fs.readFileSync(path.join(out,'supplementary','wall-followers.json')));
assert.equal(emergency.sourceSHA256,hash);assert.equal(walls.sourceSHA256,hash);
const report={status:'PASS_INDEPENDENT_REVIEW',sourceSHA256:hash,all24GraphAndSavedLogEquivalence:true,graphComparisons:85*4,equivalence,guides,guideWalkMeters:guides.reduce((a,b)=>a+b.meters,0),minimumSeconds:fresh.minimumSeconds,maximumSeconds:fresh.maximumSeconds,emergencyStatus:emergency.status,limitations:['24 direction orders use one nearest-frontier memory policy; does not prove every exploration strategy takes the configured threshold.','Walking speed and human inference can change outcomes.','Floor guides require four clearly numbered stage rows and cycle restart after each room. Correctness is from the intended guide entry, not recovery from arbitrary off-route positions.','Graph emergency release validation is a concept check, not mechanical safety certification.']};
fs.writeFileSync(path.join(out,'independent-review.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,hash,minimumSeconds:report.minimumSeconds,maximumSeconds:report.maximumSeconds,guides,guideWalkMeters:report.guideWalkMeters},null,2));
