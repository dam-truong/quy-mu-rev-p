import test from 'node:test';
import assert from 'node:assert/strict';
import * as N from '../../julius-K01-rev-N/source/src/layout.js';
import * as O from '../baseline/layout-O.js';
import {inspectLayout,buildEnvironment} from './audit-layout.mjs';
import {DIRECTION_ORDERS,runBlind} from './solver.mjs';
import {runBlind as oldBlind} from '../../quy-mu-rev-M/julius/directed-inspector.mjs';
test('Exactly 24 unique priorities retain original four first',()=>{assert.equal(DIRECTION_ORDERS.length,24);assert.equal(new Set(DIRECTION_ORDERS.map(v=>v.join())).size,24);assert.deepEqual(DIRECTION_ORDERS.slice(0,4),[[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2]]);});
test('Original N baseline and all move logs remain identical for the four primary orders',()=>{const env=buildEnvironment(N);const counts=[];for(let i=0;i<4;i++){const a=runBlind(env.makeOracle(),i),b=oldBlind(env.makeOracle(),i);assert.deepEqual(a,b);counts.push(a.steps);}assert.deepEqual(counts,[289,515,505,339]);});
test('24-order audit completes, validates locks and cannot falsely pass baseline',()=>{const r=inspectLayout(N);assert.equal(r.runs.length,24);assert.equal(r.status,'REJECT_UNDER_THRESHOLD');assert.ok(r.minimumSeconds<=r.legacy4MinimumSeconds);assert.equal(r.allCorridorCellsReachableInAtLeastOnePhase,true);r.phaseChecks.forEach(s=>assert.deepEqual(s.futureRoomsReachable,[]));r.transitionEndpointChecks.forEach(s=>assert.deepEqual(s.oldReachableNodesWithoutReturnAfterChange,[]));});
test('Invalid movement is rejected by local environment',()=>{const o=buildEnvironment(N).makeOracle();assert.throws(()=>o.move('not-a-node'),/Illegal step/);});
test('Exported stage closures cannot disagree with physical mechanism geometry',()=>{const bad={...N,STAGES:structuredClone(N.STAGES)};bad.STAGES[0].closed.pop();assert.throws(()=>buildEnvironment(bad),/STAGES mismatch/);});
test('A pivot outside rotating panel endpoints is rejected',()=>{const bad={...N,SHIFTS:structuredClone(N.SHIFTS)};bad.SHIFTS[0].post=[0,0];assert.throws(()=>buildEnvironment(bad),/Pivot is not an endpoint/);});

test('Threshold is configurable without changing trajectories',()=>{const a=inspectLayout(N,{thresholdSeconds:1}),b=inspectLayout(N,{thresholdSeconds:900});assert.equal(a.status,'PASS_SIMULATION_GATE');assert.equal(b.status,'REJECT_UNDER_THRESHOLD');assert.equal(a.minimumSeconds,b.minimumSeconds);assert.equal(b.thresholdSeconds,900);});
test('REV O passes historical 600 seconds but fails the new 900-second gate',()=>{const a=inspectLayout(O,{thresholdSeconds:600}),b=inspectLayout(O,{thresholdSeconds:900});assert.equal(a.status,'PASS_SIMULATION_GATE');assert.equal(b.status,'REJECT_UNDER_THRESHOLD');assert.ok(Math.abs(b.minimumSeconds-613.4027777777777)<1e-8);});
