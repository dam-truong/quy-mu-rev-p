import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {buildEnvironment} from './audit-layout.mjs';
const dirs=[[0,-1],[1,0],[0,1],[-1,0]],dirName=['N','E','S','W'];
export function wallFollowers(L){
  const env=buildEnvironment(L);
  const leavingRoomHeading=phase=>{const room=['giam','canh','te'][phase],cell=L.MAZE.rooms[room],door=L.DOORS.find(d=>d.id===L.MAZE.roomDoors[room]);const cx=(cell[0]+.5)*L.CELL,cz=(cell[1]+.5)*L.CELL;const towardRoom=door.axis==='z'?(door.x>cx?1:3):(door.z>cz?2:0);return(towardRoom+2)%4;};
  const runs=[];
  for(const hand of ['left','right'])for(let initialHeading=0;initialHeading<4;initialHeading++){
    let phase=0,current=env.starts[0],heading=initialHeading,steps=0;const seen=new Map(),log=[],legs=[];let last=0,status='';let loop=null;
    while(phase<4){
      if(current===env.targets[phase]){legs.push({phase,steps:steps-last,meters:(steps-last)*L.CELL});last=steps;if(phase<3)heading=leavingRoomHeading(phase);phase++;continue;}
      const state=`${phase}|${current}|${heading}`;
      if(seen.has(state)){status='FINITE_STATE_LOOP';loop={state,firstSeenAtStep:seen.get(state),repeatedAtStep:steps,periodSteps:steps-seen.get(state)};break;}seen.set(state,steps);
      const[x,z]=env.cellMap.get(current),out=env.graphs[phase].get(current),order=hand==='left'?[3,0,1,2]:[1,0,3,2];let next=null,nextHeading=null;
      for(const turn of order){const d=(heading+turn)%4,n=`${x+dirs[d][0]},${z+dirs[d][1]}`;if(out.includes(n)){next=n;nextHeading=d;break;}}
      if(next===null){status='NO_ALLOWED_OUTGOING_EDGE';break;}
      steps++;log.push({step:steps,phase,from:current,to:next,headingBefore:dirName[heading],headingAfter:dirName[nextHeading],meters:L.CELL,totalMeters:steps*L.CELL,simulatedSeconds:steps*L.CELL/1.2});current=next;heading=nextHeading;
    }
    if(phase===4)status='COMPLETE';runs.push({strategy:`wall-${hand}-${dirName[initialHeading]}`,hand,initialHeading:dirName[initialHeading],status,completed:phase===4,roomsCompleted:Math.min(phase,3),steps,meters:steps*L.CELL,seconds:steps*L.CELL/1.2,legs,loop,log});
  }
  return {purpose:'Supplementary tests only; main 24 memory/frontier acceptance is unchanged.',speedMetersPerSecond:1.2,addedDelaysSeconds:0,headingAtRoomExit:'Facing outward from the physical room door; no puzzle or interior walk time added.',loopDetection:'Exact repeated state (phase, cell, heading); objective completion is processed before checking for repetition.',completedRuns:runs.filter(r=>r.completed).length,loopingRuns:runs.filter(r=>r.status==='FINITE_STATE_LOOP').length,runs};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const input=path.resolve(process.argv[2]??fileURLToPath(new URL('../src/layout.js',import.meta.url))),args=process.argv.slice(3),out=path.resolve(args.includes('--out')?args[args.indexOf('--out')+1]:fileURLToPath(new URL('./supplementary',import.meta.url)));
  const raw=fs.readFileSync(input),L=await import('data:text/javascript;base64,'+raw.toString('base64')),r=wallFollowers(L);r.sourcePath=input;r.sourceSHA256=crypto.createHash('sha256').update(raw).digest('hex');fs.mkdirSync(out,{recursive:true});
  for(const run of r.runs)fs.writeFileSync(path.join(out,run.strategy+'.jsonl'),run.log.map(s=>JSON.stringify(s)).join('\n')+'\n');fs.writeFileSync(path.join(out,'wall-followers.json'),JSON.stringify({...r,runs:r.runs.map(({log,...v})=>v)},null,2)+'\n');
  console.log(JSON.stringify({completed:r.completedRuns,loops:r.loopingRuns,runs:r.runs.map(v=>({strategy:v.strategy,status:v.status,rooms:v.roomsCompleted,steps:v.steps}))},null,2));
}
