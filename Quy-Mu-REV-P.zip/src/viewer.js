import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import * as L from './layout.js';
import DATA from './presentation-data.json';
const $=id=>document.getElementById(id),host=$('view');
const scene=new THREE.Scene();scene.background=new THREE.Color('#14242b');
const camera=new THREE.PerspectiveCamera(40,1,.05,100);camera.position.set(16,17,19);
const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;host.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(5.5,.1,5.5);controls.enableDamping=true;
scene.add(new THREE.HemisphereLight(0xe2ebd6,0x354454,2.5));const sun=new THREE.DirectionalLight(0xffefd5,3);sun.position.set(-4,20,8);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-16,right:16,top:16,bottom:-16});scene.add(sun);
const model=new THREE.Group();scene.add(model);const fixed=new THREE.Group(),dynamic=new THREE.Group(),routes=new THREE.Group(),labels=new THREE.Group(),cues=new THREE.Group();model.add(fixed,dynamic,routes,labels,cues);
const mat=(color)=>new THREE.MeshStandardMaterial({color,roughness:.88});
const stone=mat('#879488'),floor=mat('#435154'),purple=mat('#ac7db5'),amber=mat('#d6a360'),red=mat('#ae594a');
function box(w,h,d,x,y,z,m,g=model){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;g.add(mesh);return mesh;}
const wall=(s,m,g,height=3)=>{const[x,z,a,b]=s;const mesh=box(Math.abs(a-x)+L.WALL_THICKNESS,height,Math.abs(b-z)+L.WALL_THICKNESS,(x+a)/2,height/2,(z+b)/2,m,g);mesh.userData={segmentMeters:s,height,role:g===fixed?'fixed-wall':'mechanism'};return mesh;};
const edgeSeg=(a,b)=>a[0]!==b[0]?[Math.max(a[0],b[0]),a[1],Math.max(a[0],b[0]),a[1]+1]:[a[0],Math.max(a[1],b[1]),a[0]+1,Math.max(a[1],b[1])];
box(11.3,.14,11.3,5.5,-.09,5.5,floor);
const emergencyMeshes=[],onewayMeshes=[];
for(const s of L.WALLS){let spans=[s];for(const panel of DATA.emergency.panels){const e=panel.segmentMeters,out=[];for(const w of spans){const vertical=Math.abs(w[0]-w[2])<.0001,axis=vertical?1:0,constAxis=vertical?0:1;const lo=w[axis],hi=w[axis+2],a=e[axis],b=e[axis+2];if(Math.abs(w[constAxis]-e[constAxis])<.001&&Math.abs(e[constAxis]-e[constAxis+2])<.001&&a>=lo-.001&&b<=hi+.001){if(a-lo>.001){const t=w.slice();t[axis+2]=a;out.push(t);}if(hi-b>.001){const t=w.slice();t[axis]=b;out.push(t);}}else out.push(w);}spans=out;}for(const w of spans)wall(w,stone,fixed);}
for(const p of DATA.emergency.panels){const mesh=wall(p.segmentMeters,mat('#559e83'),fixed);mesh.name=p.id+'_normally_closed_emergency_panel';emergencyMeshes.push(mesh);}
const roomColors=['#647f72','#925d56','#596e7c','#796487'];
for(const [i,r]of L.ROOMS.entries()){const[x,z,a,b]=r;box(a-x-.06,.02,b-z-.06,(x+a)/2,.01,(z+b)/2,mat(roomColors[i]));}
function label(text,x,z,color='#eff1de'){const c=document.createElement('canvas');c.width=640;c.height=96;const cx=c.getContext('2d');cx.font='bold 32px Arial';cx.fillStyle=color;cx.textAlign='center';cx.fillText(text,320,59);const tex=new THREE.CanvasTexture(c),m=new THREE.SpriteMaterial({map:tex,depthTest:false});const sp=new THREE.Sprite(m);sp.position.set(x,3.15,z);sp.scale.set(3,.45,1);labels.add(sp);return sp;}
L.ROOMS.forEach((r,i)=>label(['LÀNG / XIN ĐƯỜNG','TẾ THẦN','GIAM VỌNG ÂM','NGƯỜI CANH ẤN'][i],(r[0]+r[2])/2,(r[1]+r[3])/2));
for(const e of DATA.emergency.panels){const[x,z,a,b]=e.segmentMeters;label(e.id+' / NHẢ KHẨN',(x+a)/2,(z+b)/2,'#a8e2c0');}
for(const p of L.POI.mirrors){const m=new THREE.Mesh(new THREE.PlaneGeometry(.62,1.65),new THREE.MeshStandardMaterial({color:'#c7e2df',metalness:.72,roughness:.16,side:THREE.DoubleSide}));m.position.set(p.x,1.15,p.z);m.rotation.y=p.ry;m.name='mirror_prop';model.add(m);}
for(const p of L.POI.fakeDoors){const m=box(.65,1.95,.025,p.x,.98,p.z,mat('#624c34'));m.rotation.y=p.ry;m.name='false_door_prop';}
for(const d of L.DOORS){const width=.66,g=new THREE.Group();g.position.set(d.x,0,d.z);if(d.axis==='z')g.rotation.y=Math.PI/2;model.add(g);box(.05,2.2,.05,-width/2,1.1,0,amber,g);box(.05,2.2,.05,width/2,1.1,0,amber,g);box(width+.05,.06,.05,0,2.2,0,amber,g);}
for(const o of L.ONEWAY){const [a,b]=[o.from,o.to],x=(a[0]+b[0]+1)/2*L.CELL,z=(a[1]+b[1]+1)/2*L.CELL;const v=new THREE.Vector3(b[0]-a[0],0,b[1]-a[1]);const arrow=new THREE.ArrowHelper(v,new THREE.Vector3(x-v.x*.23,.11,z-v.z*.23),.46,0xf4bc71,.14,.14);model.add(arrow);const s=edgeSeg(a,b).map(t=>t*L.CELL);onewayMeshes.push(wall(s,new THREE.MeshStandardMaterial({color:'#b88653',transparent:true,opacity:.34}),model,1.95));}
// Props in room interiors only; maze corridors remain clear.
for(const [i,[x,z,a,b]]of L.ROOMS.entries()){if(i===0){const w=new THREE.Mesh(new THREE.CylinderGeometry(.42,.47,.6,24),stone);w.position.set(x+1.4,.3,z+1.2);model.add(w);}else{box(.8,.65,.4,(x+a)/2,.33,z+.55,mat('#503c2c'));}}
const marker=new THREE.Mesh(new THREE.SphereGeometry(.14,16,12),new THREE.MeshBasicMaterial({color:'#ffe28b'}));marker.position.set((L.MAZE.gate[0]+.5)*L.CELL,.28,(L.MAZE.gate[1]+.5)*L.CELL);model.add(marker);
let phase=0,cut=true,showSolution=false,showCues=false,playing=false,runIndex=DATA.runs.findIndex(r=>r.seconds===DATA.report.minimumSeconds),logStep=0;
function clear(group){while(group.children.length){const o=group.children.pop();o.parent=null;o.geometry?.dispose();}}
function line(points,color,width=1){if(points.length<2)return;const geom=new THREE.BufferGeometry().setFromPoints(points.map(([x,z])=>new THREE.Vector3((x+.5)*L.CELL,.08,(z+.5)*L.CELL)));routes.add(new THREE.Line(geom,new THREE.LineBasicMaterial({color,linewidth:width})));}
function drawRoutes(){clear(routes);if(showSolution){line(DATA.report.omniscient.stages[phase].route.map(k=>k.split(',').map(Number)),'#9ed9bd');}const run=DATA.runs[runIndex],steps=run.log.slice(0,logStep).filter(s=>s.phase===phase);if(steps.length)line([steps[0].fromXZ,...steps.map(s=>s.toXZ)],'#ffcf82');}
function drawCues(){clear(cues);if(!showCues)return;for(const m of L.GUIDE_STAGES[phase].marks){const c=document.createElement('canvas');c.width=c.height=128;const cx=c.getContext('2d');cx.fillStyle='#173a36';cx.fillRect(0,0,128,128);cx.strokeStyle='#b5cba2';cx.lineWidth=4;cx.strokeRect(5,5,118,118);cx.fillStyle='#e7e4b9';cx.font='bold 35px Arial';cx.textAlign='center';cx.fillText({gieng:'GIẾNG',lua:'RUỘNG',kho:'KHO',mieu:'MIẾU'}[m.sym],64,76);const tex=new THREE.CanvasTexture(c),mesh=new THREE.Mesh(new THREE.PlaneGeometry(.24,.24),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}));mesh.rotation.x=-Math.PI/2;mesh.position.set(m.x,.06,m.z);cues.add(mesh);}}
let transition=null;
function setPhase(s){phase=s;transition=null;clear(dynamic);emergencyMeshes.forEach(m=>m.visible=true);onewayMeshes.forEach(m=>m.visible=true);
 for(const lock of L.LOCKS)if(!L.STAGES[s].open.includes(lock.id)){const m=wall(edgeSeg(lock.a,lock.b).map(v=>v*L.CELL),purple,dynamic);m.name=lock.id;m.userData.role='lock';}
 for(const shift of L.SHIFTS){const seg=(L.STAGES[s].open.includes(shift.at)?shift.after:shift.before).map(v=>v*L.CELL);const m=wall(seg,purple,dynamic);m.name=shift.id;m.userData.role='rotating-wall';}
 const exit=L.DOORS.find(d=>d.id==='C06');if(s<3){const m=wall([exit.x,exit.z-L.CELL/2,exit.x,exit.z+L.CELL/2],red,dynamic);m.name='C06';m.userData.role='exit-closure';}
 fixed.scale.y=dynamic.scale.y=cut?.32:1;$('cut').classList.toggle('on',cut);document.querySelectorAll('[data-stage]').forEach(b=>b.classList.toggle('on',+b.dataset.stage===s));$('phase-note').textContent=L.STAGES[s].label;drawRoutes();drawCues();}
function sweepAt(from,to,t){setPhase(from);emergencyMeshes.forEach(m=>m.visible=false);onewayMeshes.forEach(m=>m.visible=false);
 for(const sh of L.SHIFTS){const active=L.STAGES[from].open.includes(sh.at)!==L.STAGES[to].open.includes(sh.at);if(!active)continue;
  const old=dynamic.getObjectByName(sh.id);dynamic.remove(old);old.geometry.dispose();
  const angle=seg=>{const endpoint=seg[0]===sh.post[0]&&seg[1]===sh.post[1]?seg.slice(2):seg.slice(0,2);return Math.atan2(endpoint[1]-sh.post[1],endpoint[0]-sh.post[0]);};
  const a=angle(L.STAGES[from].open.includes(sh.at)?sh.after:sh.before),b=angle(L.STAGES[to].open.includes(sh.at)?sh.after:sh.before);let delta=b-a;while(delta>Math.PI)delta-=2*Math.PI;while(delta< -Math.PI)delta+=2*Math.PI;const theta=a+delta*t;
  const mesh=box(L.CELL+L.WALL_THICKNESS,3,L.WALL_THICKNESS,sh.post[0]*L.CELL+Math.cos(theta)*L.CELL/2,1.5,sh.post[1]*L.CELL+Math.sin(theta)*L.CELL/2,purple,dynamic);mesh.rotation.y=-theta;mesh.name=sh.id;mesh.userData={role:'rotating-wall',sweepFraction:t,pivot:sh.post};
 }
 $('phase-note').textContent=`Minh họa S${from} → S${to}: đã mở E1 và nhả cửa một chiều; vùng quét phải trống.`;
}
const sweepButton=document.createElement('button');sweepButton.id='sweep';sweepButton.textContent='Xem tường xoay + nhả khẩn';$('phase-note').after(sweepButton);sweepButton.onclick=()=>{playing=false;const from=phase<2?phase:0,to=from+1;transition={from,to,start:performance.now()};};
const time=s=>Math.floor(Math.round(s)/60)+':'+String(Math.round(s)%60).padStart(2,'0');
DATA.runs.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=r.strategy.split('-').at(-1)+' · '+time(r.seconds);$('run').appendChild(o);});$('run').value=runIndex;
function updateLog(){const r=DATA.runs[runIndex];$('scrub').max=r.log.length;logStep=Math.min(logStep,r.log.length);$('scrub').value=logStep;const rec=r.log[Math.max(0,logStep-1)],at=logStep?rec.toXZ:L.MAZE.gate;marker.position.set((at[0]+.5)*L.CELL,.28,(at[1]+.5)*L.CELL);setPhase(logStep?rec.phase:0);$('log-note').textContent=`Bước ${logStep}/${r.log.length} · ${time(logStep*L.CELL/1.2)} · ${(logStep*L.CELL).toFixed(1)} m`;}
$('run').onchange=()=>{runIndex=+$('run').value;logStep=0;playing=false;updateLog();};$('scrub').oninput=()=>{logStep=+$('scrub').value;playing=false;updateLog();};$('play').onclick=()=>{if(logStep>=DATA.runs[runIndex].log.length)logStep=0;playing=!playing;};
document.querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>{playing=false;logStep=0;setPhase(+b.dataset.stage);});
$('cut').onclick=()=>{cut=!cut;$('cut').classList.toggle('on',cut);setPhase(phase);};$('spin').onclick=()=>{controls.autoRotate=!controls.autoRotate;$('spin').classList.toggle('on',controls.autoRotate);};$('route').onclick=()=>{showSolution=!showSolution;$('route').classList.toggle('on',showSolution);drawRoutes();};$('cues').onclick=()=>{showCues=!showCues;$('cues').classList.toggle('on',showCues);drawCues();};$('labels').onclick=()=>labels.visible=!labels.visible;
$('plan').onclick=()=>{camera.fov=40;camera.updateProjectionMatrix();camera.position.set(5.5,22,5.501);controls.target.set(5.5,0,5.5);};$('eye').onclick=()=>{cut=false;setPhase(0);labels.visible=false;controls.autoRotate=false;camera.fov=70;camera.updateProjectionMatrix();const [x,z]=L.MAZE.gate,[nx,nz]=L.GUIDE_STAGES[0].route[1].split(',').map(Number);camera.position.set((x+.5)*L.CELL,1.6,(z+.5)*L.CELL);controls.target.set(camera.position.x+2*(nx-x),1.6,camera.position.z+2*(nz-z));controls.update();};$('orbit').onclick=()=>{camera.fov=40;camera.updateProjectionMatrix();camera.position.set(16,17,19);controls.target.set(5.5,.1,5.5);};
function download(data,name,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
$('capture').onclick=()=>{const a=document.createElement('a');a.href=renderer.domElement.toDataURL('image/png');a.download='Quy-Mu-REV-P.png';a.click();};
async function glb(){const old=cut;cut=false;setPhase(phase);const hidden=[routes,labels,cues,marker];hidden.forEach(o=>o.visible=false);const out=await new GLTFExporter().parseAsync(model,{binary:true});hidden.forEach(o=>o.visible=true);cut=old;setPhase(phase);return out;}
$('export').onclick=async()=>download(await glb(),`Quy-Mu-REV-P-S${phase}.glb`,'model/gltf-binary');
$('result').textContent=`${DATA.report.minimumSeconds>=DATA.report.thresholdSeconds?'ĐẠT 24/24':'CHƯA ĐẠT '+DATA.report.thresholdSeconds+' GIÂY'} · nhanh nhất ${time(DATA.report.minimumSeconds)}`;$('doors').textContent=L.ONEWAY.length;$('steps').textContent=Math.min(...DATA.runs.map(r=>r.steps));
function resize(){camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);}window.addEventListener('resize',resize);resize();updateLog();
let last=0;renderer.setAnimationLoop(t=>{controls.update();if(transition){const tr=transition,f=Math.min(1,(t-tr.start)/4000);sweepAt(tr.from,tr.to,f);if(f<1)transition=tr;else setPhase(tr.to);}if(playing&&t-last>40){last=t;logStep++;updateLog();if(logStep>=DATA.runs[runIndex].log.length)playing=false;}renderer.render(scene,camera);});
window.MAZE_API={setPhase,sweepAt,glb,renderer,model,scene,camera,controls,groups:{fixed,dynamic,routes,labels,cues},emergencyMeshes,onewayMeshes,counts:{walls:L.WALLS.length,oneway:L.ONEWAY.length,shifts:L.SHIFTS.length},setView:(v)=>$(v).click(),setCut:v=>{cut=v;setPhase(phase);},report:DATA.report};
$('loading').remove();
