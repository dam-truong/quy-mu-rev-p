# REV P

PASS_SIMULATION_GATE: minimum 616.46 seconds / threshold 600.

Open HUONG-DAN.html or model-360.html locally. No deployment unless the independent gate passes. REV O is unchanged.

Rebuild existing selected candidate: node tools/pipeline.mjs

New bounded search: node tools/search-local.mjs (overwrites iterations; preserve the current selected candidate before searching). Configuration: config.json. Search budget: 40 seconds for rings 0–2, 90 seconds for remaining rings, at most 60,000 proposals per ring; deterministic PRNG but wall-clock termination varies by machine.

Three-wall shape constraint: remove at least two of three aligned vertical segments and add at least one transverse fixed segment in the original region. Reposition only existing mechanisms; room doors, widths and E1 remain fixed.

The 24 bot orders retain memory across phases and add no delays. Independent audit has no dependency on optimizer graph generation.

Hướng dẫn tự làm: [HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.md](HUONG-DAN-THI-CONG-VA-CO-CHE-CUA-REV-P.md). Bảng tọa độ sinh lại bằng node tools/build-construction-guide.mjs.

GitHub Pages: https://dam-truong.github.io/quy-mu-rev-p/
